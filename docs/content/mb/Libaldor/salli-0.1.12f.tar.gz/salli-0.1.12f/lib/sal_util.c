/****************************** sal_util.c *********************************
 * Copyright (c) Swiss Federal Polytechnic Institute Zurich, 1994-97       *
 * Copyright (c) Manuel Bronstein 1994-2000                                *
 * Copyright (c) INRIA 1998, Version 29-10-98                              *
 * Logiciel Salli �INRIA 1998, dans sa version du 29/10/1998               *
 ***************************************************************************/

#include <stdio.h>

long lungetc(long c, FILE *stream) { return((long) ungetc((int) c, stream)); }

#include <sys/time.h>

/* returns a time-based seed for the random number generator */
long randomSeed()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);        /* supported by most O/S */
	return(tv.tv_usec - tv.tv_sec); /* some minimal shuffling */
}

/* gcc defines 'sun' on sunos, that platform is missing powf */
#ifdef sun
#include <math.h>

float powf(x, y)
float x, y;
{
	return((float) pow((double) x, (double) y));
}
#endif
