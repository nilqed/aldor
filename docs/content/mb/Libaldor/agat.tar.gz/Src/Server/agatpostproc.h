#ifndef AGATPOSTPROC_H
#define AGATPOSTPROC_H
#include "agat.h"

/**************************************************************** Prototypes */


/* print a Value to stdout */
void *initPrint(HashTable * pht);

void printValue(char **anames, Value * v);

void printValues(char **anames, int arity, Value ** av);

void sleepOne(void *p, int arity, Value ** av);

/***********************************************************************/
void initPostProcFunc(void);

/************************************************************ End Prototypes */

#endif
