#include "agat.h"

#define ENLARG_RAT 0.1
#define EnlargePlot(x,y) ((x)+ENLARG_RAT*((x)-(y)))

#define X_AXE 1
#define Y_AXE 2
#define SW_AXE(axe,x,y) (((axe)==X_AXE)?(x):(y))
#define XTICKS_MAXSTEP 10

#define SamePt(xa,ya,xb,yb,eps) ((Abs((xa)-(xb))<(eps))&&((Abs((ya)-(yb))<(eps))))
/*
 * int SamePt(double xa,double ya,double xb,double yb,double eps) { return
 * ((Abs((xa)-(xb))<eps)&&(Abs((ya)-(yb))<eps)); }
 */

#define MatrixScreenToRealX(pp,x) ((((x)-(pp)->xm)/(pp)->scalex)+(pp)->minx)
#define MatrixScreenToRealY(pp,y) ((((-y)+(pp)->ysz-(pp)->ym)/(pp)->scaley)+(pp)->miny)

#define MINUS_HALF -0.5
#define ADD_HALF    0.5


/**************************************************************** Prototypes */

static void drawMatrix(Matrix * pp, Window win, int i, int j, int col, double val);
static void drawMatrixGrid(Matrix * pp, Window win, int i, int j, int col, double val);
static void matrixResize(Matrix * pp, int x, int y);
static void matrixCoord(Matrix * pp, int x, int y, int rx, int ry, Window win, int First);
static void matrixZoom(Matrix * pp, int x1, int y1, int x2, int y2);
static void matrixPS(Matrix * pp, int x, int y);
static Matrix *initMatrixAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, Boolean grid, Boolean colored, Boolean prop, char *name);
static void findAxe(Matrix * pp, int *pve, int axe);
static void plotXTicks(Matrix * pp, int posAxe);
static void plotYTicks(Matrix * pp, int posAxe);
static void plotOneAxe(Matrix * pp, int axe);
static void plotAxes(Matrix * pp);
static void matrixRefresh(Matrix * pp);

/******************************************************************** Bodies */


double
MatrixRealToScreenX(Matrix * pp, double x)
{
    return (((x) - (pp)->minx) * (pp)->scalex + (pp)->xm);
}


double
MatrixRealToScreenY(Matrix * pp, double y)
{
    if (!pp->ps)
	return ((pp)->ysz - (pp)->ym - ((y) - (pp)->miny) * (pp)->scaley);
    else
	return ((pp)->ym + ((y) - (pp)->miny) * (pp)->scaley);
}


int
retCol(Matrix * pp, int col)
{
    if (!pp->colored)
	return 0;
    else {
	if ((col >= NB_MAX_COLOR) || (col < 0)) {
	    fprintf(stderr, "MatrixCol: Color value must be between 0 and 15\n");
	    fprintf(stderr, " Display with color 0 (see Resources)\n");
	    return 0;
	}
	else
	    return col;
    }
}


static void
drawMatrix(Matrix * pp, Window win, int i, int j, int col, double val)
{
    int uli, ulj, lri, lrj;
    int bgcol;
    double prop;

    uli = MatrixRealToScreenX(pp, i + MINUS_HALF);
    ulj = MatrixRealToScreenY(pp, j + ADD_HALF);
    lri = MatrixRealToScreenX(pp, i + ADD_HALF);
    lrj = MatrixRealToScreenY(pp, j + MINUS_HALF);

    bgcol = retCol(pp, col);
    if (pp->propor) {
	prop = (val / pp->maxVal);
	agatFillRectangle((AnyClassOp *) pp, win, pp->backGc, uli, ulj, lri - uli, lrj - ulj);
    }
    else
	prop = 1;
    agatFillRectangle((AnyClassOp *) pp, win, pp->drawGcs[bgcol], uli, ulj + (lrj - ulj) - (int) rint((lrj - ulj) * prop), lri - uli, (int) rint((lrj - ulj) * prop));
}


static void
drawMatrixGrid(Matrix * pp, Window win, int i, int j, int col, double val)
{
    int uli, ulj, lri, lrj;
    int bgcol;
    double prop;

    uli = MatrixRealToScreenX(pp, i + MINUS_HALF);
    ulj = MatrixRealToScreenY(pp, j + ADD_HALF);
    lri = MatrixRealToScreenX(pp, i + ADD_HALF);
    lrj = MatrixRealToScreenY(pp, j + MINUS_HALF);

    bgcol = retCol(pp, col);
    if (pp->propor) {
	prop = (val / pp->maxVal);
	agatFillRectangle((AnyClassOp *) pp, win, pp->backGc, uli, ulj, lri - uli, lrj - ulj);
    }
    else
	prop = 1;

    agatFillRectangle((AnyClassOp *) pp, win, pp->drawGcs[bgcol], uli, ulj + (lrj - ulj) - (int) rint((lrj - ulj) * prop), lri - uli, (int) rint((lrj - ulj) * prop));
    agatDrawRectangle((AnyClassOp *) pp, win, pp->drawGcs[1], uli, ulj, lri - uli, lrj - ulj);
}


static void
matrixResize(Matrix * pp, int x, int y)
{
    int vx, vy;
    int i, first;
    double maxx, maxy, minx, miny;
    sList *psl = NULL;

    if (x <= 0)
	x = 1;
    if (y <= 0)
	y = 1;
    pp->xsz = x;
    pp->ysz = y;
    pp->xusz = x - pp->xm * 2;
    pp->yusz = y - pp->ym * 2;
    /* recompute extrema */
    if (alIsElt(pp->al)) {
	psl = alLook(pp->al, alFirstElt(pp->al), psl);
	vx = alFirstElt(pp->al);
	vy = psl->j;
	minx = vx;
	maxx = vx;
	miny = vy;
	maxy = vy;
	psl = NULL;
	for (i = (int) floor(pp->minx + 1); i <= (int) floor(pp->maxx); i++) {
	    do {
		psl = alLook(pp->al, i, psl);
		if (psl != NULL) {
		    vx = i;
		    vy = psl->j;
		    if (vx > maxx)
			maxx = vx;
		    else if (vx < minx)
			minx = vx;
		    if (vy > maxy)
			maxy = vy;
		    else if (vy < miny)
			miny = vy;
		}
	    } while (psl != NULL);
	}
	pp->maxx = maxx + ADD_HALF;
	pp->minx = minx + MINUS_HALF;
	pp->maxy = maxy + ADD_HALF;
	pp->miny = miny + MINUS_HALF;

	XFreePixmap(pp->dpy, pp->pixmap);
	pp->pixmap = XCreatePixmap(pp->dpy, pp->win, x, y, DefaultDepth(pp->dpy, DefaultScreen(pp->dpy)));
    }
}


static void
matrixCoord(Matrix * pp, int x, int y, int rx, int ry, Window win, int First)
{
#define MARG_H 5
#define MARG_W 10
#define MARG_PT_X 10
#define MARG_PT_Y 10

    char tmp[100];
    static int size = 0;
    XEvent event_return;
    double di, dj;
    sList *cell;

    di = MatrixScreenToRealX(pp, x);
    dj = MatrixScreenToRealY(pp, y);
    if ((!pp->colored) && (!pp->propor))
	sprintf(tmp, "I : %d  J : %d", (int) rint(di), (int) rint(dj));
    else {
	cell = alLookElt(pp->al, (int) rint(di), (int) rint(dj));
	if (cell != NULL) {
	    if ((pp->colored) && (!pp->propor))
		sprintf(tmp, "I : %d  J : %d  Color : %d", (int) rint(di), (int) rint(dj), cell->col);
	    else if ((!pp->colored) && (pp->propor))
		sprintf(tmp, "I : %d  J : %d  Val : %f", (int) rint(di), (int) rint(dj), cell->val);
	}
	else
	    sprintf(tmp, "I : %d  J : %d  No Value", (int) rint(di), (int) rint(dj));
    }

    XSynchronize(pp->dpy, True);
    XMoveWindow(pp->dpy, win, rx + MARG_PT_X, ry + MARG_PT_Y);
    if (size != strlen(tmp) || First) {
	XResizeWindow(pp->dpy, win, MARG_W + strlen(tmp) * pp->fontWidth,
		      pp->fontHeight + MARG_H * 2);
	XWindowEvent(pp->dpy, win, ExposureMask, &event_return);
    }
    size = strlen(tmp);
    XClearWindow(pp->dpy, win);
    agatDrawString((AnyClassOp *) pp, win, pp->textGc, MARG_W, MARG_H + pp->fontHeight, tmp, strlen(tmp));
    XFlush(pp->dpy);
    XSynchronize(pp->dpy, False);
}


static void
matrixZoom(Matrix * pp, int x1, int y1, int x2, int y2)
{
    Matrix *newpp;
    RDataBase initRDB;

    newpp = (Matrix *) UZalloc(sizeof(Matrix));
    *newpp = *pp;
    newpp->type = ZOOM_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen("zoom") + 1));
    strcpy(pp->name, "zoom");
    newpp->minx = MatrixScreenToRealX(pp, x1);
    newpp->maxy = MatrixScreenToRealY(pp, y1);
    newpp->maxx = MatrixScreenToRealX(pp, x2);
    newpp->miny = MatrixScreenToRealY(pp, y2);
    extractDB(0, NULL, pp->dpy, "zoom", &initRDB);
    newpp->xsz = initRDB.xsz;
    newpp->ysz = initRDB.ysz;
    newpp->xm = initRDB.xm;
    newpp->ym = initRDB.ym;
    newpp->xusz = newpp->xsz - newpp->xm * 2;
    newpp->yusz = newpp->ysz - newpp->ym * 2;

    createFirstWindow(&newpp->dpy, &newpp->win, &newpp->pixmap, newpp->xsz, newpp->ysz, &initRDB);
    addXwin(newpp->dpy, newpp->win, ZOOM_WINDOW, newpp->refresh, newpp->resize,
	  newpp->coord, newpp->szoom, newpp->zoom, NULL, newpp->pps, newpp);
    XStoreName(newpp->dpy, newpp->win, "zoom");
    mapWindow(newpp->dpy, newpp->win, &initRDB);
}


static void
matrixPS(Matrix * pp, int x, int y)
{
    RDataBase initRDB;
    int tabCol[NB_MAX_COLOR + 3];
    char *buffer = NULL, *file[255];
    int i;

    extractDB(0, NULL, pp->dpy, buffer, &initRDB);	/* ?? */
    pp->ps = True;
    XFetchName(pp->dpy, pp->win, file);
    if (*file != NULL) {
	pp->fps = fopen(*file, "w");
	if (pp->fps != NULL) {
	    headPs(pp->fps, (AnyClassOp *) pp);

	    pp->tabRGB = (RGB *) UZalloc(sizeof(RGB) * (NB_MAX_COLOR + 3));	/* +Back,Text,Mark */
	    tabCol[0] = initRDB.fg;
	    tabCol[1] = initRDB.bg;
	    tabCol[2] = initRDB.markcolor;
	    for (i = 3; i < (NB_MAX_COLOR + 3); i++)
		tabCol[i] = initRDB.tabColor[i - 3];

	    x2psColors((AnyClassOp *) pp, tabCol, pp->tabRGB, (NB_MAX_COLOR + 3));

	    (*(pp->refresh)) (pp);
	    tailPs(pp->fps);
	    fclose(pp->fps);
	}
	else
	    fprintf(stderr, "Can't open file !\n");
    }
    pp->ps = False;
}


static Matrix *initMatrixAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, Boolean grid, Boolean colored, Boolean prop, char *name) {
    Matrix *pp;
    InitPar *pip;
    Display *dpy;
    char *buffer;
    RDataBase initRDB;

    dpy = openDisplayOnlyOne();
    pp = (Matrix *) UZalloc(sizeof(Matrix));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    pp->type = MATRIX_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(pp->name, buffer);
    pp->iconified = False;		/* ?? */
    pp->killed = False;
    pp->ps = False;
    pp->xsz = initRDB.xsz;
    pp->ysz = initRDB.ysz;
    pp->xm = initRDB.xm;
    pp->ym = initRDB.xm;
    pp->xusz = pp->xsz - pp->xm * 2;
    pp->yusz = pp->ysz - pp->ym * 2;
    createFirstWindow(&pp->dpy, &pp->win, &pp->pixmap, pp->xsz, pp->ysz, &initRDB);

    pp->backGc = createBackGc(pp->dpy, pp->win, initRDB.bg);
    pp->textGc = createTextGc(pp->dpy, pp->win, initRDB.font, initRDB.fg,
			      &pp->fontWidth, &pp->fontHeight);
    pp->font = (char *) UZalloc(sizeof(char) * (strlen(initRDB.font) + 1));
    strcpy(pp->font, initRDB.font);
    addXwin(pp->dpy, pp->win, pp->type, ref, res, coord, szoom, zoom, NULL, pps, pp);
    appNameClass(pp->dpy, pp->win);
    XStoreName(pp->dpy, pp->win, buffer);
    pp->drawGcs = createGcs(pp->dpy, pp->win, initRDB.tabColor, 15);
    pp->al = alCreate();
    pp->nbpt = 0;
    pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
    pp->scalex = pp->scaley = 1.0;
    pp->minVal = 0;
    pp->maxVal = 0;
    pp->colored = colored;
    pp->propor = prop;
    pp->firstValue = True;
    pp->grid = grid;
    pp->draw = draw;
    pp->resize = res;
    pp->refresh = ref;
    pp->coord = coord;
    pp->szoom = szoom;
    pp->zoom = zoom;
    pp->pps = pps;
    pp->doAxe = doAxe;
    mapWindow(pp->dpy, pp->win, &initRDB);
    if (pp->iconified) {
	XIconifyWindow(pp->dpy, pp->win, DefaultScreen(dpy));
	XFlush(pp->dpy);
    }
    return pp;
}


void *
initMatrix(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, False, False, False, False, "matrix");
}

void *
initMatrixAxe(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, True, False, False, False, "matrix");
}

void *
initMatrixGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, False, True, False, False, "matrix");
}

void *
initMatrixAxeGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, True, True, False, False, "matrix");
}

/****************************************************************************/
void *
initMatrixcol(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, False, False, True, False, "matrixcol");
}

void *
initMatrixcolAxe(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, True, False, True, False, "matrixcol");
}

void *
initMatrixcolGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, False, True, True, False, "matrixcol");
}

void *
initMatrixcolAxeGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, True, True, True, False, "matrixcol");
}

/****************************************************************************/
void *
initMatrixval(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, False, False, False, True, "matrixval");
}

void *
initMatrixvalAxe(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrix, matrixCoord, selectRect, matrixZoom, matrixPS, True, False, False, True, "matrixval");
}

void *
initMatrixvalGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, False, True, False, True, "matrixval");
}

void *
initMatrixvalAxeGrid(HashTable * pht)
{
    return initMatrixAux(pht, matrixRefresh, matrixResize, drawMatrixGrid, matrixCoord, selectRect, matrixZoom, matrixPS, True, True, False, True, "matrixval");
}


static void
findAxe(Matrix * pp, int *pve, int axe)
{
    double minv, maxv, scalev;
    double v;

    if (axe == Y_AXE) {
	minv = pp->minx;
	maxv = pp->maxx;
	scalev = pp->scalex;
    }
    else {
	minv = pp->miny;
	maxv = pp->maxy;
	scalev = pp->scaley;
    }
    v = Min(Max(minv, 0.0), maxv);
    if (axe == Y_AXE) {
	v = MatrixRealToScreenX(pp, v);
	*pve = (int) Min(pp->xsz, Max(0, v));
    }
    else {
	v = MatrixRealToScreenY(pp, v);
	*pve = (int) Min(pp->ysz, Max(0, v));
    }
}


static void
plotXTicks(Matrix * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbTotCar, nbLabCar, maxc, tmp;
    double *aTicks;
    char **aLabs;
    Bool reduced = False;

    nbTicks = buildXTicksLabs(pp->xsz, pp->fontWidth, pp->minx, pp->maxx,
			      XTICKS_HRATIO, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	x = MatrixRealToScreenX(pp, aTicks[i]);
	if (posAxe < (pp->fontHeight + 2)) {
	    /* put labels under X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe - 1, x, posAxe + XMATRIX_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe + (pp->fontHeight + 2), aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* put labels over X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe + 1, x, posAxe - XMATRIX_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe - 2, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotYTicks(Matrix * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbLabCar;
    double *aTicks;
    char **aLabs;

    nbTicks = buildYTicksLabs(pp->xsz, pp->ysz, pp->fontHeight, pp->fontWidth,
			      pp->miny, pp->maxy, YTICKS_NB_CARMIN,
		  YTICKS_VRATIO, YTICKS_HRATIO, &nbLabCar, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	y = MatrixRealToScreenY(pp, aTicks[i]);
	if ((pp->xsz - posAxe) < (pp->fontWidth * (nbLabCar + 1))) {
	    /* axe is near the right bordre of window */
	    /* so plot ticks and labels to the left of axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + 1, y, posAxe - XMATRIX_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - (pp->fontWidth * (strlen(aLabs[i]) + 1)), y, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* all is right */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - 1, y, posAxe + XMATRIX_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + (pp->fontWidth), y, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotOneAxe(Matrix * pp, int axe)
{
    int posAxe;

    if ((pp->minx == pp->maxx) || (pp->miny == pp->maxy))
	return;
    findAxe(pp, &posAxe, axe);
    if (axe == Y_AXE) {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe, 0, posAxe, pp->ysz);
	plotYTicks(pp, posAxe);
    }
    else {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, 0, posAxe, pp->xsz, posAxe);
	plotXTicks(pp, posAxe);
    }
}


static void
plotAxes(Matrix * pp)
{
    plotOneAxe(pp, X_AXE);
    plotOneAxe(pp, Y_AXE);
}


static void
matrixRefresh(Matrix * pp)
{
    sList *psl;
    int i;

    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz, pp->ysz);
    if (pp->firstValue) {
	if (pp->maxx == pp->minx)
	    pp->maxx += 1e-100;
	if (pp->maxy == pp->miny)
	    pp->maxy += 1e-100;
	pp->firstValue = False;
    }

    pp->scalex = ((double) pp->xusz) / (pp->maxx - pp->minx);
    pp->scaley = ((double) pp->yusz) / (pp->maxy - pp->miny);

    psl = NULL;
    for (i = (int) floor(pp->minx + 1); i <= (int) floor(pp->maxx); i++) {
	do {
	    psl = alLook(pp->al, i, psl);
	    if (psl != NULL)
		pp->draw(pp, pp->pixmap, i, psl->j, psl->col, psl->val);
	} while (psl != NULL);
    }

    if (pp->doAxe)
	plotAxes(pp);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz + 1, pp->ysz + 1, 0, 0);
	XFlush(pp->dpy);
    }
}


void
matrix(Matrix * pp, Value * i, Value * j)
{
    double ulx, uly, lrx, lry;
    Value *vulx, *vuly, *vlrx, *vlry;
    Boolean ref = False;
    int ii, ij;

    ii = (int) valToDouble(i);
    ij = (int) valToDouble(j);

    if (pp->firstValue) {
	pp->minx = ii + MINUS_HALF;
	pp->maxx = ii + ADD_HALF;
	pp->miny = ij + MINUS_HALF;
	pp->maxy = ij + ADD_HALF;
	ref = True;
    }
    else {
	if (ii < pp->minx) {
	    pp->minx = EnlargePlot(ii, pp->maxx) + MINUS_HALF;
	    ref = True;
	}
	if (ii > pp->maxx) {
	    pp->maxx = EnlargePlot(ii, pp->minx) + ADD_HALF;
	    ref = True;
	}
	if (ij < pp->miny) {
	    pp->miny = EnlargePlot(ij, pp->maxy) + MINUS_HALF;
	    ref = True;
	}
	if (ij > pp->maxy) {
	    pp->maxy = EnlargePlot(ij, pp->miny) + ADD_HALF;
	    ref = True;
	}
    }
    pp->nbpt++;

    alAdd(pp->al, ii, ij, -1, 0.0);

    pp->i = ii;
    pp->j = ij;
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp, pp->win, pp->i, pp->j, -1, 0);
	    XFlush(pp->dpy);
	}
    }
}


void
matrixCol(Matrix * pp, Value * i, Value * j, Value * Val)
{
    double ulx, uly, lrx, lry;
    Value *vulx, *vuly, *vlrx, *vlry;
    Boolean ref = False;
    int ii, ij;

    ii = (int) valToDouble(i);
    ij = (int) valToDouble(j);

    if (pp->firstValue) {
	pp->minx = ii + MINUS_HALF;
	pp->maxx = ii + ADD_HALF;
	pp->miny = ij + MINUS_HALF;
	pp->maxy = ij + ADD_HALF;
	ref = True;
    }
    else {
	if (ii < pp->minx) {
	    pp->minx = EnlargePlot(ii, pp->maxx) + MINUS_HALF;
	    ref = True;
	}
	if (ii > pp->maxx) {
	    pp->maxx = EnlargePlot(ii, pp->minx) + ADD_HALF;
	    ref = True;
	}
	if (ij < pp->miny) {
	    pp->miny = EnlargePlot(ij, pp->maxy) + MINUS_HALF;
	    ref = True;
	}
	if (ij > pp->maxy) {
	    pp->maxy = EnlargePlot(ij, pp->miny) + ADD_HALF;
	    ref = True;
	}
    }
    pp->nbpt++;

    alAdd(pp->al, ii, ij, (int) valToDouble(Val), 0);

    pp->i = ii;
    pp->j = ij;
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp, pp->win, pp->i, pp->j, (int) valToDouble(Val), 0);
	    XFlush(pp->dpy);
	}
    }
}


void
matrixVal(Matrix * pp, Value * i, Value * j, Value * Val)
{
    double ulx, uly, lrx, lry;
    Value *vulx, *vuly, *vlrx, *vlry;
    Boolean ref = False;
    int ii, ij;
    double dv;

    ii = (int) valToDouble(i);
    ij = (int) valToDouble(j);
    dv = valToDouble(Val);

    if (pp->firstValue) {
	pp->minx = ii + MINUS_HALF;
	pp->maxx = ii + ADD_HALF;
	pp->miny = ij + MINUS_HALF;
	pp->maxy = ij + ADD_HALF;
	pp->minVal = dv;
	pp->maxVal = dv;
	ref = True;
    }
    else {
	if (ii < pp->minx) {
	    pp->minx = EnlargePlot(ii, pp->maxx) + MINUS_HALF;
	    ref = True;
	}
	if (ii > pp->maxx) {
	    pp->maxx = EnlargePlot(ii, pp->minx) + ADD_HALF;
	    ref = True;
	}
	if (ij < pp->miny) {
	    pp->miny = EnlargePlot(ij, pp->maxy) + MINUS_HALF;
	    ref = True;
	}
	if (ij > pp->maxy) {
	    pp->maxy = EnlargePlot(ij, pp->miny) + ADD_HALF;
	    ref = True;
	}
	if (dv > pp->maxVal) {
	    pp->maxVal = dv;
	    ref = True;
	}
	if (dv < pp->minVal) {
	    pp->minVal = dv;
	}
    }
    pp->nbpt++;

    alAdd(pp->al, ii, ij, -1, valToDouble(Val));

    pp->i = ii;
    pp->j = ij;
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp, pp->win, pp->i, pp->j, -1, valToDouble(Val));
	    XFlush(pp->dpy);
	}
    }
}


void
matrixRestart(Matrix * pp, Value * i, Value * j, Value * reInit)
{
    if (evalBool(reInit)) {
/*	qDel(pp->qv, qNbElts(pp->qv), unAllocValue);*/
	pp->nbpt = 0;
	pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
	pp->scalex = pp->scaley = 1.0;
	pp->firstValue = True;
    }
    unAllocValue(reInit);
    matrix(pp, i, j);
}
