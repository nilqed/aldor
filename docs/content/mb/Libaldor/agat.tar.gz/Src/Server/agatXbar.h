#ifndef AGATXBAR_H
#define AGATXBAR_H
#include "agat.h"

#define XBAR_MULT_VSZ 0.025

#define YTICKS_NB_CARMIN 8
/* what part of the screen must be covered by y labels */
/* YTICKS_VRATIO == 5 -> 1/5 of screen height is used for label print */
/* YTICKS_HRATIO == 8 -> 1/8 of screen widht is  used for label print */
#define YTICKS_VRATIO 4
#define YTICKS_HRATIO 8

#define XBAR_MULT_SCROLL 0.1

typedef struct ThinBar {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;				/* To respect AnyClass */
    RGB *tabRGB;
    int fontHeight, fontWidth;
    int xsz, ysz;
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    int arity;
    int curx;
    int totBar;
    Queue *qv;
    double maxy, miny, scaley;
    Boolean doAxe;
    void (*draw) ();
    void (*resize) ();
    void (*refresh) ();
    void (*coord) ();
    void (*szoom) ();
    void (*zoom) ();
    void (*pps) ();
}       ThinBar;


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
double ThinBarRealToScreenY(ThinBar * pp, double y);

double ThinBarRealToScreenHY(ThinBar * ptb, double d);

void *initThinbar(HashTable * pht);

void *initThinbarAxe(HashTable * pht);

void *initPlotbar(HashTable * pht);

void *initPlotbarAxe(HashTable * pht);

void thinbar(ThinBar * ptb, int arity, Value ** av);

void *initRatThinBarAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), char *name);

void *initRatThinbar(HashTable * pht);

void ratThinbar(ThinBar * ptb, int arity, Value ** av);

/************************************************************ End Prototypes */


#endif
