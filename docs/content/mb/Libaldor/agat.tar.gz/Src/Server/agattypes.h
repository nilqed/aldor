#ifndef AGATTYPES_H
#define AGATTYPES_H
#include "agat.h"


/* VarNode Type */
#define VNT_NOTYPE 0
#define VNT_CST    1
#define VNT_PAT    2
#define VNT_REG    3

/* Expression Node Types */
#define ENT_VAL 1
#define ENT_VAR 2
#define ENT_OP  3

/* ACtion Types */
#define ACT_EXPR  1
#define ACT_IFTE  2
#define ACT_ASGN  3
#define ACT_NULL  4

/* Construct Types */
#define CT_MAP    1
#define CT_CMACR  2

/* Def Types */
#define DT_CONST      1
#define DT_STREAM     2
#define DT_MACRO      3
#define DT_EXTSTREAM  4
#define DT_POSTPROC   5

/* Value Types used in the Expression Nodes */
#define VT_NOTYPE  0
#define VT_BOOL    1
#define VT_CHAR    2
#define VT_SHORT   3
#define VT_INT     4
#define VT_LONG    5
#define VT_UCHAR   6
#define VT_USHORT  7
#define VT_UINT    8
#define VT_ULONG   9
#define VT_FLOAT  10
#define VT_DOUBLE 11
/* 'A' stands for Array */
#define VT_A_BOOL    21
#define VT_A_CHAR    22
#define VT_A_UCHAR   23
#define VT_A_SHORT   24
#define VT_A_USHORT  25
#define VT_A_INT     26
#define VT_A_UINT    27
#define VT_A_LONG    28
#define VT_A_ULONG   29
#define VT_A_FLOAT   30
#define VT_A_DOUBLE  31

/* types of synchronization avaiable for post-processing-functions */
#define ST_BLOCKING     1
#define ST_NONBLOCKING  2

/* State Types */
#define ST_NO_STATE               0
#define ST_NO_VALUE               1
#define ST_FIRST_NEW_VALUE        2
#define ST_NEW_VALUE              3
#define ST_NO_NEW_VALUE           4
#define ST_NO_NEW_VALUE_BUT_ONE   5

/* bit patterns used during evaluation to match input-stream-states         */
/* PAT_? are used in complementof MASK_?                                    */
/* given a input-state each start-pattern is checked to choose wich         */
/* actions to start.                                                        */
/* input-state is masked with MASK_?. if it's equal to PAT_? then           */
/* test is succesfull and pattern match input-state.                        */
/* each PAT_? or MASK_? is 2 bits long:                                     */
/* right-most bit mean that at most one value has been put on this stream */
/* left bit mean that a new value is waiting in the input-stream          */
/* for instance :                                                           */
/* PAT_NEW_VALUE = 0000 0010 (=2) a new value must be here                */
/* MASK_NEW_VALUE= 0000 0001 (=1) no matter if there's an old value or not */
#define PAT_NO_VALUE               0
#define MASK_NO_VALUE              0
#define PAT_FIRST_NEW_VALUE        2
#define MASK_FIRST_NEW_VALUE       0
#define PAT_NEW_VALUE              2
#define MASK_NEW_VALUE             1
#define PAT_NO_NEW_VALUE           0
#define MASK_NO_NEW_VALUE          1
#define PAT_NO_NEW_VALUE_BUT_ONE   1
#define MASK_NO_NEW_VALUE_BUT_ONE  0
/* the two bit masks used in upper define ... (they must be coherent with) */
#define PAT_BIT_NEW_VALUE          2
#define PAT_BIT_AT_LEAST_ONE_OLD   1



/* The predefined infix functions */
#define OPEQUAL   "EQUAL"
#define OPNEQUA   "NEQUA"
#define OPGT      "GT"
#define OPLT      "LT"
#define OPGTOEQ   "GTOEQ"
#define OPLTOEQ   "LTOEQ"
#define OPPLUS    "PLUS"
#define OPMINUS   "MINUS"
#define OPMULT    "MULT"
#define OPDIV     "DIV"
#define OPMINUS_U "MINUS_U"

/* Class Type of Graphic Operator */
#define CT_BAR 1
#define CT_BOX 2
#define CT_PLOT 3


/* use this arity for postprocessing functions with variable arity */
/* beware: these functions must match a diferent prototype than    */
/* constant arity functions                                        */
#define VAR_ARITY -1

/* define the maximum arity for variable arity post processing functions */
#define MAX_VAR_ARITY 15

/* the maximum length for a flux name */
#define FN_MAXLEN 1024


/* Type of Windows */
#define PLOT_WINDOW       1
#define BOX_WINDOW        2
#define HISTO_WINDOW      3
#define MATRIX_WINDOW     4
#define THINBAR_WINDOW    5
#define RATTHINBAR_WINDOW 6
#define ZOOM_WINDOW       7
#define PLOT3D_WINDOW     8


/* used for multi-types values */
typedef struct Value {
    union {				/* really an union becoz this struct
					 * is very frequently used */
	int i;
	unsigned char uc;
	long l;
	float f;
	double d;
	void *a;
	void *pt;
    }     v;
    Byte t;
}     Value;





/* types used for the synaxic analysis of .agt files */
/* some are used to buid a First-raw-pass tree */
/* the others are for a more clever one which is used */
/* during the processing of stream */

/* to acces value of different Variable Nodes */
typedef struct VarNode {
    Byte t;				/* a stream-value a register or a
					 * constant ? */
    Queue *pq;				/* the queue to use for
					 * input-stream-value  */
    Value **ppv;			/* to retrive the value of this
					 * register    */
    Value *pv;				/* value of this constant                   */
}       VarNode;


/* FA for First Analysis */
/* All these structures are used to build the first syntaxic tree of */
/* an Agat stream-processing-file */

typedef struct FAOp {
    int arity;
    char *opName;
    List *opl;				/* build during sema-check, used
					 * during evalExpr */
    struct FAExpNode **sons;
}    FAOp;


typedef struct FAExpNode {
    int lgn;
    char *file;
    Byte t;
    Value *pv;				/* value */
    FAOp *po;				/* operator (or function) */
    char *varName;			/* var */
    VarNode *pvn;			/* to access variable value */
    struct FAExpNode *next;		/* for lists of expressions
					 * (parameters) */
}         FAExpNode;


typedef struct FAName {
    int lgn;
    char *file;
    char *n;
    struct FAName *next;
}      FAName;

typedef struct FAReg {
    int lgn;
    char *file;
    char *regName;
    FAExpNode *pen;
    struct FAReg *next;
}     FAReg;


typedef struct FAPattern {
    int lgn;
    char *file;
    Byte state;
    char *name;
    struct FAPattern *next;
}         FAPattern;


typedef struct FAAction {
    int lgn;
    char *file;
    Byte t;
    char *regName;			/* assign */
    FAExpNode *e;			/* assign & ifte & expr */
    struct FAAction *thenA, *elseA;	/* ifte */
    struct FAAction *next;
}        FAAction;


typedef struct FAClause {
    int lgn;
    char *file;
    FAPattern *lp;
    FAAction *la;
    struct FAClause *next;
}        FAClause;


typedef struct FAConstruct {
    int lgn;
    char *file;
    Byte t;
    FAReg *lr;				/* map */
    FAClause *lc;			/* map */
    FAName *lf;				/* map & callmacro */
    char *name;				/* callmacro */
    int nbArg;				/* map & callmacro */
}           FAConstruct;


typedef struct FADef {
    int lgn;
    char *file;
    Byte t;
    char *name;				/* defmacro & defconst & defstream
					 * &defpostproc */
    FAName *lf;				/* defmacro & defpostproc */
    FAConstruct *pc;			/* defmacro & defstream */
    FAExpNode *pen;			/* defconst */
    Value *pv;				/* defconst after evaluation */
    int aProxInd;			/* evaluation order (computed during
					 * compileGraph) */
    struct FADef *next;
}     FADef;





typedef struct IncDesc {
    int lgn;
    char *file;
    Boolean done;
    char *name;
}       IncDesc;

typedef struct ConstDesc {
    int lgn;
    char *file;
    char *name;
    FAName *lnu;
    FADef *pd;
    Boolean cycle;
}         ConstDesc;

typedef struct MacroDesc {
    int lgn;
    char *file;
    char *name;
    FAConstruct *pc;
    int nbArg;
}         MacroDesc;

typedef struct StreamDesc {
    int lgn;
    char *file;
    char *name;
    FADef *pd;
}          StreamDesc;

typedef struct FuncDesc {
    int lgn;
    char *file;
    char *name;
}        FuncDesc;



typedef struct PostProc {
    char *name;
    int arity;
    Byte synchType;
    void *(*pfi) ();
    void (*pf) ();
}        PostProc;



typedef struct FuncProto {
    char *n;
    int arity;
    Byte pt;
    Byte rt;
    void (*pf) ();
}         FuncProto;


typedef struct ExtStream {
    char *n;
    int indProx;
}         ExtStream;

typedef struct Action {
    char *file;
    int lgn;
    Byte t;
    Value **preg;			/* which register to assign (if
					 * needed) */
    FAExpNode *e;			/* expression used in assign & ifte &
					 * expr */
    struct Action **thenA, **elseA;	/* ifte */
}      Action;

typedef struct InitPar {
    char *name;
    void *pe;
}       InitPar;

/* Prox for PRocessing bOX */
typedef struct Prox {
    Boolean activated;			/* is this Prox to be run? */
    FADef *pd;				/* the old First Analysis Definition */
    Value **areg;			/* array of (local) registers */
    int nbsucc;				/* number of successor */
    int csucc;				/* current number of successors (used
					 * during asucc filling) */
    int *asucc;				/* array of sucessor in the stream
					 * dependencies graph */
    int *asn;				/* "  to find which stack to use for
					 * each sucessor (for output) */
    int nbpred;				/* number of stream in */
    Queue **ainput;			/* array of queues used to buffer the
					 * values of input-streams */
    Byte *astate;			/* state of each input-stream */
    int nbpat;				/* number of patterns */
    Byte **apat;			/* array of patterns (a pattern is an
					 * array of bytes) */
    Byte **amask;			/* array of masks */
    Action ***aapact;			/* array of array of actions (each
					 * pattern start a set of actions) */
    Boolean initDone;			/* init of function of post
					 * processing */
    PostProc *ppp;			/* descriptor for function of post
					 * processing */
    void *cd;				/* call data for function of post
					 * processing */
}    Prox;



typedef struct Xwin {
    Display *dpy;
    Window win;
    Window winc;			/* Window to display coordonates */
    int type;
    void (*fref) (void *);		/* refresh-function */
    void (*fres) (void *, int, int);	/* resize-function */
    void (*fcoo) (void *, int, int, int, int, Window, int);	/* coord-function */
    void (*fzos) (struct Xwin *, int, int);	/* selection zoom function */
    void (*fzoo) (void *, int, int, int, int);	/* zoom function */
    void (*fm3d) (void *);		/* 3D move function. only for 3D op */
    void (*fpps) (void *, int, int);
    void *pe;				/* some datas usefull for refresh &
					 * resize functions */
}    Xwin;

#endif
