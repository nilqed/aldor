#ifndef AGATFUNC_H
#define AGATFUNC_H
#include "agat.h"

/* the maximum arity of operators (or functions) used in expressions */
#define MAX_ARITY 5

/**************************************************************** Prototypes */


/**********************************************************************/
void initFunc(void);

/************************************************************ End Prototypes */

#endif
