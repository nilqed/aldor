#ifndef AGATPROCESS_H
#define AGATPROCESS_H
#include "agat.h"

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
void evalWarning(char *file, int lgn, char *msg);

/* static */
void castValue(Value * pv, int newType);

/* store the number of the stream which produce this value */
Value *convertVal(Value * pv, int numStream, double d);

double valToDouble(Value * pv);

Boolean evalBool(Value * pv);

/* static */
FuncProto *checkParameters(List * opl, Value ** av, int arity);

/* static */
void castParameters(int newType, Value ** av, int arity);

/* static */
Value *applyFunc(FuncProto * pfp, Value ** av, int arity);

/* static */
Value *evalOp(FAExpNode * pen);

/* static */
Value *evalVar(FAExpNode * pen);

Value *evalExpr(FAExpNode * pen);

void evalDefConsts(List * lcd);

/* static */
Value *evalAction(Action * pa);

/* static */
Value *evalActions(Action ** aa);

/* static */
Boolean testPatMatch(unsigned char *ps, unsigned char *pp, unsigned char *pm, int nbb);

/* static */
void refreshState(unsigned char *ps, unsigned char *pp, unsigned char *pm, int nbb, Queue ** aq);

/* static */
Value *evalProx(Prox * pp);

/* static */
Value *newValue(Prox * pp, int i);

void *initParKey(InitPar * pip);

InitPar *buildInitPar(char *name, void *pe);

/* static */
void callInit(Prox * pp);

Boolean checkPPCParams(Prox * pp);

/* static */
void ppCall(Prox * pp);

/* static */
void postProcessCall(Prox * pp);

void giveValueToSuccs(Prox * pp, Value * pv);

void runProx(void);

/************************************************************ End Prototypes */


#endif
