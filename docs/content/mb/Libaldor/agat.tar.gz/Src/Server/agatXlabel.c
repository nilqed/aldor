/*
 * Nice Numbers for Graph Labels by Paul Heckbert from "Graphics Gems",
 * Academic Press, 1990 Paul Heckbert	2 Dec 88
 */
#include "agat.h"

/**************************************************************** Prototypes */

/*
 * nicenum: find a "nice" number approximately equal to x. Round the number
 * if round=1, take ceiling if round=0
 */
static double nicenum(double x, int round);
static void findLabel(double x, double d, int nbcar, char *pLab);

/******************************************************************** Bodies */


/*
 * nicenum: find a "nice" number approximately equal to x. Round the number
 * if round=1, take ceiling if round=0
 */

static double
nicenum(double x, int round)
{
    int expv;				/* exponent of x */
    double f;				/* fractional part of x */
    double nf;				/* nice, rounded fraction */

    expv = floor(log10(x));
    f = x / pow(10., (double) expv);	/* between 1 and 10 */
    if (round)
	if (f < 1.5)
	    nf = 1.;
	else if (f < 3.)
	    nf = 2.;
	else if (f < 7.)
	    nf = 5.;
	else
	    nf = 10.;
    else if (f <= 1.)
	nf = 1.;
    else if (f <= 2.)
	nf = 2.;
    else if (f <= 5.)
	nf = 5.;
    else
	nf = 10.;
    return nf * pow(10., (double) expv);
}

void
findTicks(double min, double max, int *nbTicks, double **aTicks)
{
    double d;
    double graphmin;
    double inter, range, x;
    int i, tmpnbTicks;

    if ((*nbTicks) == 0)
	return;
    if (min > max)
	USwap(min, max, double);

    if (min == max) {
	for (i = 0; i < (*nbTicks); i++)
	    (*aTicks)[i] = min;
	return;
    }

    inter = nicenum((max - min) / (UForceNonZero((*nbTicks - 1), 1)), 1);
    graphmin = floor(min / inter) * inter;
    *nbTicks += (int) (((max - min) - (inter * ((*nbTicks) - 1))) / inter);
    *nbTicks += ((*nbTicks) % 2 == 0) ? 1 : 0;
    if (*nbTicks < 1)
	*nbTicks = 1;
    *aTicks = (double *) URealloc(*aTicks, sizeof(double) * (*nbTicks));
    x = graphmin;
    for (i = 0; i < (*nbTicks); i++) {
	(*aTicks)[i] = x;
	x += inter;
    }
}

static void
findLabel(double x, double d, int nbcar, char *pLab)
{
    int nfrac, extrac;
    char str[6], tmp[MAX_CHAR_TMP];

    if (d > 0.0) {
	nfrac = Max(-floor(log10(d)), 0);
	sprintf(str, "%%.%df", nfrac);
	sprintf(tmp, str, x);
	if (strlen(tmp) > nbcar) {
	    /* to avoid truncated numbers                */
	    /* use E notation instead of fixed point one */
	    extrac = 5;			/* 0 . E  and 2 exposant digits */
	    if (x < 0)
		extrac++;
	    if (fabs(log10((fabs(x)))) > 99)
		extrac++;		/* one more digit for exposant */
	    sprintf(str, "%%.%dg", ((nbcar - extrac) >= 0) ? (nbcar - extrac) : 0);
	    sprintf(tmp, str, x);
	}
    }
    else {
	/* no range so can't know about the number of digits to use */
	/* so put the maximum number of digits                      */
	extrac = 5;			/* 0 . E  and 2 exposant digits */
	if (x < 0)
	    extrac++;
	if (fabs(log10((fabs(x)))) > 99)
	    extrac++;			/* one more digit for exposant */
	sprintf(str, "%%.%dg", Max(nbcar - extrac, 1));
	sprintf(tmp, str, x);
    }
    strncpy(pLab, tmp, nbcar);
    pLab[nbcar] = '\0';
}


void
findLabels(int nbTicks, int nbcar, double *aTicks, char **aLabs)
{
    int i, j, nbcrange, nbcnumb, extrac = 0;
    double d, range;

    if (nbTicks == 0)
	return;
    range = aTicks[nbTicks - 1] - aTicks[0];
    if (range > 0) {
	d = nicenum(range / (nbTicks - 1), 1);
	nbcrange = floor(log10(d));	/* nb of char for range */
	if (aTicks[0] != 0.0)
	    nbcnumb = floor(log10(fabs(aTicks[0])));	/* nbchar for number */
	else
	    nbcnumb = 1;
	/* count the number of extra chars to print this number */
	if (aTicks[0] < 0)
	    extrac++;			/* there's a - sign */
	if (nbcnumb < 0)
	    extrac++;			/* there's a 0 before the . */
	if (nbcrange <= 0)
	    extrac++;			/* there's a decimal . */
	if (nbcnumb - nbcrange + extrac < nbcar) {
	    /* ok for normal labels */
	    for (i = 0; i < nbTicks; i++) {
		findLabel(aTicks[i], d, nbcar, aLabs[i]);
	    }
	}
	else {
	    /* can't write number + range on nbcar chars */
	    /* so use a strange label like               */
	    /* 3.12159 ,&1e-10, &2e-10, ...              */
	    findLabel(aTicks[0], d, nbcar, aLabs[0]);
	    for (i = 1; i < nbTicks; i++) {
		findLabel(aTicks[i] - aTicks[0], 0.0, nbcar - 1, aLabs[i]);
		for (j = nbcar - 1; j > 0; j--)
		    aLabs[i][j] = aLabs[i][j - 1];
		aLabs[i][0] = '&';
		aLabs[i][nbcar] = '\0';
	    }
	}
    }
    else {
	/* no range... do something to avoid crash */
	d = 0.0;
	findLabel(aTicks[0], d, nbcar, aLabs[0]);
	for (i = 1; i < nbTicks - 1; i++) {
	    strncpy(aLabs[i], "...", nbcar);
	    aLabs[i][nbcar] = '\0';
	}
	strncpy(aLabs[nbTicks - 1], "+0", nbcar);
	aLabs[nbTicks - 1][nbcar] = '\0';
    }
}


int
buildXTicksLabs(int xsz, int fontWidth, double minx, double maxx,
		double hRatio, double **aTicks, char ***aLabs)
{
    int nbTicks, i, j, nbTotCar, nbLabCar, maxc, tmp;
    Bool reduced = False;

    nbTicks = ((xsz / fontWidth) / hRatio) / 6;
    nbTotCar = (xsz / fontWidth) / hRatio;

    nbLabCar = (nbTicks > 0) ? (nbTotCar / nbTicks) : 0;
    (*aTicks) = (double *) UZalloc(sizeof(double) * nbTicks);
    findTicks(minx, maxx, &nbTicks, aTicks);

    (*aLabs) = (char **) UZalloc(nbTicks * (sizeof(char *) + (nbLabCar + 1)));
    for (j = 0; j < nbTicks; j++)
	(*aLabs)[j] = (char *) ((*aLabs) + nbTicks) + j * (nbLabCar + 1);

    findLabels(nbTicks, nbLabCar, *aTicks, *aLabs);
    return nbTicks;
}

int
buildYTicksLabs(int xsz, int ysz, int fontHeight, int fontWidth,
	     double miny, double maxy, int nbCarMin, int vRatio, int hRatio,
		int *nbLabCar, double **aTicks, char ***aLabs)
{
    int nbTicks, i;

    nbTicks = (ysz / fontHeight) / vRatio;
    *nbLabCar = (xsz / fontWidth) / hRatio;
    if (*nbLabCar < nbCarMin)
	*nbLabCar = nbCarMin;

    (*aTicks) = (double *) UZalloc(sizeof(double) * nbTicks);
    findTicks(miny, maxy, &nbTicks, aTicks);
    if (nbTicks <= 0)			/* findTicks seems to have a bug :( */
	nbTicks = 1;
    (*aLabs) = (char **) UZalloc(nbTicks * (sizeof(char *) + ((*nbLabCar) + 1)));
    for (i = 0; i < nbTicks; i++)
	(*aLabs)[i] = (char *) ((*aLabs) + nbTicks) + i * ((*nbLabCar) + 1);

    findLabels(nbTicks, *nbLabCar, *aTicks, *aLabs);
    return nbTicks;
}
