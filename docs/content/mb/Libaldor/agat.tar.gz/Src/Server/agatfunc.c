#include "agat.h"

/**************************************************************** Prototypes */

/* initFunc()                        */
static long max2i(long int a, long int b);
static long max3i(long int a, long int b, long int c);
static long max4i(long int a, long int b, long int c, long int d);
static double max2f(double a, double b);
static double max3f(double a, double b, double c);
static double max4f(double a, double b, double c, double d);
static long min2i(long int a, long int b);
static long min3i(long int a, long int b, long int c);
static long min4i(long int a, long int b, long int c, long int d);
static double min2f(double a, double b);
static double min3f(double a, double b, double c);
static double min4f(double a, double b, double c, double d);
static double sgnf(double a, double b);
static long sgni(long int a);
static long oddi(long int a);
static long lmostdigit(long int a);
static long rmostdigit(long int a);
static long nbdigit(long int a);
static double agatRand(double m);

/* standard infix functions interfaces */
static long eqi(long int a, long int b);
static long eqf(double a, double b);
static long neqi(long int a, long int b);
static long neqf(double a, double b);
static long gti(long int a, long int b);
static long gtf(double a, double b);
static long lti(long int a, long int b);
static long ltf(double a, double b);
static long gtei(long int a, long int b);
static long gtef(double a, double b);
static long ltei(long int a, long int b);
static long ltef(double a, double b);
static long addi(long int a, long int b);
static double addf(double a, double b);
static long subi(long int a, long int b);
static double subf(double a, double b);
static long multi(long int a, long int b);
static double multf(double a, double b);
static double divi(long int a, long int b);
static double divf(double a, double b);
static long umini(long int a);
static double uminf(double a);

/******************************************************************** Bodies */

/* code of custom functions          */
/* you may add yours ...             */
/* provided you add their prototypes */
/* using addFunc (see bellow in      */
/* initFunc()                        */

static long
max2i(long int a, long int b)
{
    return Max(a, b);
}

static long
max3i(long int a, long int b, long int c)
{
    return Max(a, Max(b, c));
}

static long
max4i(long int a, long int b, long int c, long int d)
{
    return Max(Max(a, b), Max(c, d));
}

static double
max2f(double a, double b)
{
    return Max(a, b);
}

static double
max3f(double a, double b, double c)
{
    return Max(a, Max(b, c));
}

static double
max4f(double a, double b, double c, double d)
{
    return Max(Max(a, b), Max(c, d));
}


static long
min2i(long int a, long int b)
{
    return Min(a, b);
}

static long
min3i(long int a, long int b, long int c)
{
    return Min(a, Min(b, c));
}

static long
min4i(long int a, long int b, long int c, long int d)
{
    return Min(Min(a, b), Min(c, d));
}

static double
min2f(double a, double b)
{
    return Min(a, b);
}

static double
min3f(double a, double b, double c)
{
    return Min(a, Min(b, c));
}

static double
min4f(double a, double b, double c, double d)
{
    return Min(Min(a, b), Min(c, d));
}

static double
sgnf(double a, double b)
{
    if (a == 0.0)
	return 0.0;
    return (a > 0) ? 1.0 : -1.0;
}

static long
sgni(long int a)
{
    if (a == 0)
	return 0;
    return (a > 0) ? 1 : -1;
}

static long
oddi(long int a)
{
    return a & 1;
}


static long
lmostdigit(long int a)
{
    int r;

    r = a;
    while ((a /= 10) > 0)
	r = a;
    return r;
}

static long
rmostdigit(long int a)
{
    return a % 10;
}

static long
nbdigit(long int a)
{
    int nb = 1;

    while ((a /= 10) > 0)
	nb++;
    return nb;
}

static double
agatRand(double m)
{
    static init = False;
    void srand48(long);
    double drand48();

    if (init == False) {
	srand48((long) m);
	init = True;
    }
    return drand48() * m;
}


/* standard infix functions interfaces */



static long
eqi(long int a, long int b)
{
    return a == b;
}

static long
eqf(double a, double b)
{
    return a == b;
}

static long
neqi(long int a, long int b)
{
    return a != b;
}

static long
neqf(double a, double b)
{
    return a != b;
}

static long
gti(long int a, long int b)
{
    return a > b;
}

static long
gtf(double a, double b)
{
    return a > b;
}

static long
lti(long int a, long int b)
{
    return a < b;
}

static long
ltf(double a, double b)
{
    return a < b;
}

static long
gtei(long int a, long int b)
{
    return a >= b;
}

static long
gtef(double a, double b)
{
    return a >= b;
}

static long
ltei(long int a, long int b)
{
    return a <= b;
}

static long
ltef(double a, double b)
{
    return a <= b;
}

static long
addi(long int a, long int b)
{
    return a + b;
}

static double
addf(double a, double b)
{
    return a + b;
}

static long
subi(long int a, long int b)
{
    return a - b;
}

static double
subf(double a, double b)
{
    return a - b;
}

static long
multi(long int a, long int b)
{
    return a * b;
}

static double
multf(double a, double b)
{
    return a * b;
}

static double
divi(long int a, long int b)
{
    return (double) a / (double) b;
}

static double
divf(double a, double b)
{
    return a / b;
}

static long
umini(long int a)
{
    return -a;
}

static double
uminf(double a)
{
    return -a;
}






/**********************************************************************/
/* look at that if you want to add some new function in Agat language */
/**********************************************************************/

void
initFunc(void)
{
    /* predifined infix functions */
    addFunc("EQUAL", 2, VT_LONG, VT_LONG, (GenericFunc) eqi);
    addFunc("EQUAL", 2, VT_DOUBLE, VT_LONG, (GenericFunc) eqf);
    addFunc("NEQUA", 2, VT_LONG, VT_LONG, (GenericFunc) neqi);
    addFunc("NEQUA", 2, VT_DOUBLE, VT_LONG, (GenericFunc) neqf);
    addFunc("GT", 2, VT_LONG, VT_LONG, (GenericFunc) gti);
    addFunc("GT", 2, VT_DOUBLE, VT_LONG, (GenericFunc) gtf);
    addFunc("LT", 2, VT_LONG, VT_LONG, (GenericFunc) lti);
    addFunc("LT", 2, VT_DOUBLE, VT_LONG, (GenericFunc) ltf);
    addFunc("GTOEQ", 2, VT_LONG, VT_LONG, (GenericFunc) gtei);
    addFunc("GTOEQ", 2, VT_DOUBLE, VT_LONG, (GenericFunc) gtef);
    addFunc("LTOEQ", 2, VT_LONG, VT_LONG, (GenericFunc) ltei);
    addFunc("LTOEQ", 2, VT_DOUBLE, VT_LONG, (GenericFunc) ltef);
    addFunc("PLUS", 2, VT_LONG, VT_LONG, (GenericFunc) addi);
    addFunc("PLUS", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) addf);
    addFunc("MINUS", 2, VT_LONG, VT_LONG, (GenericFunc) subi);
    addFunc("MINUS", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) subf);
    addFunc("MULT", 2, VT_LONG, VT_LONG, (GenericFunc) multi);
    addFunc("MULT", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) multf);
    addFunc("DIV", 2, VT_LONG, VT_DOUBLE, (GenericFunc) divi);
    addFunc("DIV", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) divf);
    addFunc("MINUS_U", 1, VT_LONG, VT_LONG, (GenericFunc) umini);
    addFunc("MINUS_U", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) uminf);

    /* standard prefix functions */
    addFunc("acos", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) acos);
    addFunc("asin", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) asin);
    addFunc("atan", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) atan);
    addFunc("atan2", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) atan2);
    addFunc("ceil", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) ceil);
    addFunc("cos", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) cos);
    addFunc("cosh", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) cosh);
    addFunc("exp", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) exp);
    addFunc("fabs", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) fabs);
    addFunc("floor", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) floor);
    addFunc("fmod", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) fmod);
    addFunc("log", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) log);
    addFunc("log10", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) log10);
    addFunc("pow", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) pow);
    addFunc("sin", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) sin);
    addFunc("sinh", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) sinh);
    addFunc("sqrt", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) sqrt);
    addFunc("tan", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) tan);
    addFunc("tanh", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) tanh);

    /* added prefix functions                                 */
    /* add your function prototypes here                      */
    /* and put the corresponding code at the top of this file */

    /* addFunc add your function to the syntax                */
    /* addFunc( "name", arity, parType, retType, function)    */
    /* name   : the name to use in .agt sources               */
    /* arity  : the arity of this function                    */
    /* parType: type of parameters (all parameters must       */
    /* have the same type. Actually only two                  */
    /* types are suported: VT_LONG (long) and                 */
    /* VT_DOUBLE (double)                                     */
    /* retType : type of returned value. Actually only        */
    /* two types are suported: VT_LONG (long)                 */
    /* and VT_DOUBLE (double)                                 */
    /* function: pointer on the function code to use          */

    addFunc("abs", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) fabs);
    addFunc("max", 2, VT_LONG, VT_LONG, (GenericFunc) max2i);
    addFunc("max", 3, VT_LONG, VT_LONG, (GenericFunc) max3i);
    addFunc("max", 4, VT_LONG, VT_LONG, (GenericFunc) max4i);
    addFunc("max", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) max2f);
    addFunc("max", 3, VT_DOUBLE, VT_DOUBLE, (GenericFunc) max3f);
    addFunc("max", 4, VT_DOUBLE, VT_DOUBLE, (GenericFunc) max4f);
    addFunc("min", 2, VT_LONG, VT_LONG, (GenericFunc) min2i);
    addFunc("min", 3, VT_LONG, VT_LONG, (GenericFunc) min3i);
    addFunc("min", 4, VT_LONG, VT_LONG, (GenericFunc) min4i);
    addFunc("min", 2, VT_DOUBLE, VT_DOUBLE, (GenericFunc) min2f);
    addFunc("min", 3, VT_DOUBLE, VT_DOUBLE, (GenericFunc) min3f);
    addFunc("min", 4, VT_DOUBLE, VT_DOUBLE, (GenericFunc) min4f);
    addFunc("sgn", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) sgnf);
    addFunc("sgn", 1, VT_LONG, VT_LONG, (GenericFunc) sgni);
    addFunc("odd", 1, VT_LONG, VT_LONG, (GenericFunc) oddi);
    addFunc("lmostdigit", 1, VT_LONG, VT_LONG, (GenericFunc) lmostdigit);
    addFunc("rmostdigit", 1, VT_LONG, VT_LONG, (GenericFunc) rmostdigit);
    addFunc("nbdigit", 1, VT_LONG, VT_LONG, (GenericFunc) nbdigit);
    addFunc("rand", 1, VT_DOUBLE, VT_DOUBLE, (GenericFunc) agatRand);
}
