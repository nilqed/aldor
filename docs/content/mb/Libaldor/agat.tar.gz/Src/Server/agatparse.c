#include "agat.h"

/* global vars */
char *curFile = NULL;
int curLgn = 1;
int nbError = 0;


/**************************************************************** Prototypes */


/******************************************************************** Bodies */

Value *
bvInt(char *s)
{
    Value *pv;

    pv = allocValue();
    pv->t = VT_INT;
    pv->v.i = atoi(s);
    return pv;
}

Value *
bvFloat(char *s)
{
    double nb;
    int expl, mantl, nbl;
    char *c;
    Value *pv;

    if ((c = strrchr(s, 'e')) || (c = strrchr(s, 'E'))) {
	expl = strlen(c);
	nbl = strlen(s);
	mantl = nbl - expl;
	c++;
	s[mantl] = '\0';
	nb = (atof(s)) * pow(10.0, atof(c));
    }
    else
	nb = atof(s);
    pv = allocValue();
    pv->t = VT_DOUBLE;
    pv->v.d = nb;
    return pv;
}

Value *
bvBool(int b)
{
    Value *pv;

    pv = allocValue();
    pv->t = VT_BOOL;
    pv->v.uc = (Byte) b;
    return pv;
}

char *
keepIdent(char *s)
{
    return UStrDup(s);
}



FAOp *
dupFAOp(FAOp * opo)
{
    FAOp *po;
    int i;

    if (opo == NULL)
	return (FAOp *) NULL;
    po = (FAOp *) UZalloc(sizeof(FAOp));
    po->arity = opo->arity;
    po->opName = opo->opName;
    po->sons = (FAExpNode **) UZalloc(po->arity * sizeof(FAExpNode *));
    for (i = 0; i < po->arity; i++)
	po->sons[i] = dupFAExpNode(opo->sons[i]);
    po->opl = NULL;
    return po;
}

FAExpNode *
allocFAExpNode(void)
{
    FAExpNode *pen;

    pen = (FAExpNode *) UCalloc(1, sizeof(FAExpNode));
    pen->t = 0;
    pen->lgn = curLgn;
    pen->file = curFile;
    pen->pv = (Value *) NULL;
    pen->po = (FAOp *) NULL;
    pen->varName = (char *) NULL;
    pen->pvn = NULL;
    pen->next = (FAExpNode *) NULL;
    return pen;
}

FAExpNode *
dupFAExpNode(FAExpNode * open)
{
    FAExpNode *pen;

    if (open == NULL)
	return (FAExpNode *) NULL;

    pen = (FAExpNode *) UCalloc(1, sizeof(FAExpNode));
    pen->t = open->t;
    pen->lgn = open->lgn;
    pen->file = open->file;
    if (open->pv != NULL)
	pen->pv = dupValue(open->pv);
    else
	pen->pv = NULL;
    pen->po = dupFAOp(open->po);
    pen->varName = open->varName;
    pen->pvn = NULL;
    pen->next = NULL;
    return pen;
}


FAExpNode *
benValue(Value * pv)
{
    FAExpNode *pen;

    pen = allocFAExpNode();
    pen->t = ENT_VAL;
    pen->pv = pv;
    return pen;
}


FAExpNode *
benVar(char *varName)
{
    FAExpNode *pen;

    pen = allocFAExpNode();
    pen->t = ENT_VAR;
    pen->varName = varName;
    return pen;
}


FAExpNode *
benFuncUn(char *op, FAExpNode * s)
{
    FAExpNode *pen;

    pen = allocFAExpNode();
    pen->t = ENT_OP;
    pen->po = (FAOp *) UZalloc(sizeof(FAOp));
    pen->po->arity = 1;
    pen->po->opName = UStrDup(op);
    pen->po->sons = (FAExpNode **) UZalloc(1 * sizeof(FAExpNode *));
    pen->po->sons[0] = s;
    pen->po->opl = NULL;
    return pen;
}

FAExpNode *
benFuncBin(char *op, FAExpNode * ls, FAExpNode * rs)
{
    FAExpNode *pen;

    pen = allocFAExpNode();
    pen->t = ENT_OP;
    pen->po = (FAOp *) UZalloc(sizeof(FAOp));
    pen->po->arity = 2;
    pen->po->opName = UStrDup(op);
    pen->po->sons = (FAExpNode **) UZalloc(2 * sizeof(FAExpNode *));
    pen->po->sons[0] = ls;
    pen->po->sons[1] = rs;
    pen->po->opl = NULL;
    return pen;
}

FAExpNode *
benFuncTern(char *op, FAExpNode * ls, FAExpNode * ms, FAExpNode * rs)
{
    FAExpNode *pen;

    pen = allocFAExpNode();
    pen->t = ENT_OP;
    pen->po = (FAOp *) UZalloc(sizeof(FAOp));
    pen->po->arity = 3;
    pen->po->opName = UStrDup(op);
    pen->po->sons = (FAExpNode **) UZalloc(3 * sizeof(FAExpNode *));
    pen->po->sons[0] = ls;
    pen->po->sons[1] = ms;
    pen->po->sons[2] = rs;
    pen->po->opl = NULL;
    return pen;
}


FAExpNode *
benFuncCall(char *nameOp, FAExpNode * pNode)
{
    FAExpNode *pen;

    if (pNode == (FAExpNode *) NULL) {
	pen = allocFAExpNode();
	pen->t = ENT_OP;
	pen->po = (FAOp *) UZalloc(sizeof(FAOp));
	pen->po->arity = 0;
	pen->po->sons = NULL;
	pen->po->opl = NULL;
	pen->next = (FAExpNode *) NULL;
    }
    else
	pen = pNode;
    pen->po->opName = UStrDup(nameOp);

    return pen;
}

FAExpNode *
benArgList(FAExpNode * pNewExpNode, FAExpNode * pFuncCallNode)
{
    FAExpNode *pen;

    if (pFuncCallNode == (FAExpNode *) NULL) {
	pen = allocFAExpNode();
	pen->t = ENT_OP;
	pen->po = (FAOp *) UZalloc(sizeof(FAOp));
	pen->po->arity = 1;
	pen->po->sons = (FAExpNode **) UZalloc(sizeof(FAExpNode *));
	pen->po->sons[0] = pNewExpNode;
	pen->po->opl = NULL;
	pen->next = (FAExpNode *) NULL;
    }
    else {
	pen = pFuncCallNode;
	pen->po->arity++;
	pen->po->sons = (FAExpNode **) URealloc(pen->po->sons, pen->po->arity * sizeof(FAExpNode *));
	pen->po->sons[pen->po->arity - 1] = pNewExpNode;
    }
    return pen;
}

FAAction *
bAction(int t, char *n, FAExpNode * e, FAAction * ta, FAAction * ea)
{
    FAAction *pa;

    pa = (FAAction *) UZalloc(sizeof(FAAction));
    pa->lgn = curLgn;
    pa->file = curFile;
    pa->t = t;
    pa->regName = n;
    pa->e = e;
    pa->thenA = ta;
    pa->elseA = ea;
    pa->next = (FAAction *) NULL;
    return pa;
}

FAAction *
dupActions(FAAction * la)
{
    FAAction *pa;

    if (la == NULL)
	return (FAAction *) NULL;
    pa = (FAAction *) UZalloc(sizeof(FAAction));
    pa->lgn = la->lgn;
    pa->file = la->file;
    pa->t = la->t;
    pa->regName = la->regName;
    pa->e = dupFAExpNode(la->e);
    pa->thenA = dupActions(la->thenA);
    pa->elseA = dupActions(la->elseA);
    pa->next = dupActions(la->next);
    return pa;
}


FAPattern *
bPattern(char *n, unsigned char s)
{
    FAPattern *pp;

    pp = (FAPattern *) UZalloc(sizeof(FAPattern));
    pp->lgn = curLgn;
    pp->file = curFile;
    pp->name = n;
    if (s != ST_NO_STATE)
	pp->state = s;
    else
	pp->state = ST_NEW_VALUE;
    pp->next = (FAPattern *) NULL;
    return pp;
}

FAClause *
bClause(FAPattern * lp, FAAction * la)
{
    FAClause *pc;

    pc = (FAClause *) UZalloc(sizeof(FAClause));
    pc->lgn = curLgn;
    pc->file = curFile;
    pc->lp = lp;
    pc->la = la;
    pc->next = (FAClause *) NULL;
    return pc;
}

FAClause *
dupClauses(FAClause * lc)
{
    FAClause *pc;

    if (lc == NULL)
	return (FAClause *) NULL;
    pc = (FAClause *) UZalloc(sizeof(FAClause));
    pc->lgn = lc->lgn;
    pc->file = lc->file;
    /* lp: only for reading */
    pc->lp = lc->lp;
    pc->la = dupActions(lc->la);
    pc->next = dupClauses(lc->next);
    return pc;
}



FAReg *
bReg(char *n, FAExpNode * pen)
{
    FAReg *pr;

    pr = (FAReg *) UZalloc(sizeof(FAReg));
    pr->lgn = curLgn;
    pr->file = curFile;
    pr->regName = n;
    pr->pen = pen;
    pr->next = (FAReg *) NULL;
    return pr;
}

FAName *
bName(char *n)
{
    FAName *pn;

    pn = (FAName *) UZalloc(sizeof(FAName));
    pn->lgn = curLgn;
    pn->file = curFile;
    pn->n = n;
    pn->next = (FAName *) NULL;
    return pn;
}


FADef *
bDef(int t, char *name, FAName * lf, FAConstruct * pc, FAExpNode * pen)
{
    FADef *pd;

    pd = (FADef *) UZalloc(sizeof(FADef));
    pd->lgn = curLgn;
    pd->file = curFile;
    pd->t = t;
    pd->name = name;
    pd->lf = lf;
    pd->pc = pc;
    pd->pen = pen;
    pd->aProxInd = 0;
    pd->next = (FADef *) NULL;
    return pd;
}

FAConstruct *
bConstruct(int t, FAReg * lr, FAClause * lc, FAName * lf)
{
    FAConstruct *pc;

    pc = (FAConstruct *) UZalloc(sizeof(FAConstruct));
    pc->lgn = curLgn;
    pc->file = curFile;
    pc->t = t;
    pc->lr = lr;
    pc->lc = lc;
    pc->lf = lf;
    pc->name = NULL;
    pc->nbArg = nbFANames(pc->lf);
    return pc;
}

FAConstruct *
dupConstruct(FAConstruct * opc)
{
    FAConstruct *pc;

    pc = (FAConstruct *) UZalloc(sizeof(FAConstruct));
    pc->lgn = opc->lgn;
    pc->file = opc->file;
    pc->t = opc->t;
    /* no matter if register list is not duplicated (only for reading) */
    pc->lr = opc->lr;
    pc->lc = dupClauses(opc->lc);
    /* only for reading */
    pc->lf = opc->lf;
    pc->name = NULL;
    pc->nbArg = opc->nbArg;
    return pc;
}

/***************************/
/* utilities for debugging */
/***************************/

void
displayValue(Value * pv)
{
#ifdef DEBUG
    if (pv == NULL) {
	printf("NULL Value ");
	return;
    }
    switch (pv->t) {
    case VT_BOOL:{
        printf("%10d ", pv->v.uc, "BOOL");
        break;
    }
    case VT_UCHAR:{
        printf("%10d ", pv->v.uc, "UCHAR");
        break;
    }
    case VT_INT:{
        printf("%10d ", pv->v.i, "INT");
        break;
    }
    case VT_LONG:{
        printf("%10d ", pv->v.l, "LONG");
        break;
    }
    case VT_FLOAT:{
        printf("%10f", pv->v.f, "FLOAT");
	    break;
    }
    case VT_DOUBLE:{
        printf("%10f", pv->v.d, "DOUBLE");
        break;
    }
    default:{
        UIError("agat server", "%s %d", "displayValue: unknown VT_?", pv->t);
    }
    }
#endif
}

void
displayFAExpTree(FAExpNode * pen)
{
    int i;

    switch (pen->t) {
    case ENT_VAL:{
	    displayValue(pen->pv);
	    break;
	}
    case ENT_VAR:{
	    printf("%s", pen->varName);
	    break;
	}
    case ENT_OP:{
	    printf("%s(", pen->po->opName);
	    UIndent("+");
	    for (i = 0; i < pen->po->arity; i++) {
		displayFAExpTree(pen->po->sons[i]);
		if (i < pen->po->arity - 1)
		    printf(", ");
	    }
	    UIndent("-");
	    printf(")");
	    break;
	}
    default:{
	    UIError("agat server", "%s %d", "displayFAExpTree: unknown ENT_?", pen->t);
	    break;
	}
    }
}

void
displayFAExpressions(FAExpNode * pen)
{
    while (pen != (FAExpNode *) NULL) {
	displayFAExpTree(pen);
	pen = pen->next;
	if (pen != (FAExpNode *) NULL)
	    printf(", ");
    }
}

void
displayFAAction(FAAction * pa)
{
    while (pa != (FAAction *) NULL) {
	switch (pa->t) {
	    case ACT_ASGN:{
		printf("%s=", pa->regName);
		UIndent("+");
		displayFAExpTree(pa->e);
		UIndent("-");
		break;
	    }
	case ACT_EXPR:{
		displayFAExpTree(pa->e);
		break;
	    }
	case ACT_IFTE:{
		printf("if ");
		UIndent("+");
		displayFAExpTree(pa->e);
		UIndent("-p");
		printf("then");
		UIndent("+p");
		displayFAAction(pa->thenA);
		UIndent("-p");
		if (pa->elseA != (FAAction *) NULL) {
		    printf("else");
		    UIndent("+p");
		    displayFAAction(pa->elseA);
		    UIndent("-p");
		}
		printf("endif");
		break;
	    }
	case ACT_NULL:{
		printf("null ");
		break;
	} default:{
		UIError("agat server", "%s %d", "displayFAAction: unknown ACT_?", pa->t);
		break;
	    }
	}
	pa = pa->next;
	if (pa != NULL) {
	    printf(",");
	    UIndent("p");
	}
    }
}


void
displayFAPattern(FAPattern * pp)
{
    while (pp != (FAPattern *) NULL) {
	if (pp->name != (char *) NULL)
	    printf("%s", pp->name);

	switch (pp->state) {
	case ST_NO_VALUE:{
		printf("#");
		break;
	    }
	case ST_FIRST_NEW_VALUE:{
		printf("^");
		break;
	    }
	case ST_NEW_VALUE:{
		if (pp->name == NULL)
		    printf("_");
		break;
	    }
	case ST_NO_NEW_VALUE:{
		printf("*");
		break;
	    }
	case ST_NO_NEW_VALUE_BUT_ONE:{
		printf("+");
		break;
	    }
	default:{
		UIError("agat server", "%s %d", "displayFAPattern: unknown ST_?", pp->state);
		break;
	    }
	}
	pp = pp->next;
	if (pp != (FAPattern *) NULL)
	    printf(", ");
    }
}


void
displayFAClause(FAClause * pc)
{
    while (pc != (FAClause *) NULL) {
	displayFAPattern(pc->lp);
	printf("-> ");
	UIndent("+p");
	displayFAAction(pc->la);
	UIndent("-");
	pc = pc->next;
	if (pc != (FAClause *) NULL)
	    UIndent("p");
    }
}

void
displayFAName(FAName * lf)
{
    while (lf != (FAName *) NULL) {
	printf("%s", lf->n);
	lf = lf->next;
	if (lf != (FAName *) NULL)
	    printf(", ");
    }
}

void
displayFAReg(FAReg * pr)
{
    if (pr == (FAReg *) NULL)
	return;

    printf("{");
    while (pr != (FAReg *) NULL) {
	printf("%s ", pr->regName);
	if (pr->pen != (FAExpNode *) NULL) {
	    printf("= ");
	    displayFAExpTree(pr->pen);
	}
	pr = pr->next;
	if (pr != (FAReg *) NULL)
	    printf(", ");
    }
    printf("}");
}

void
displayFAConstruct(FAConstruct * pc)
{
    switch (pc->t) {
	case CT_MAP:{
	    printf("map");
	    displayFAReg(pc->lr);
	    UIndent("+p");
	    printf("(");
	    displayFAClause(pc->lc);
	    UIndent("p");
	    printf(") ");
	    displayFAName(pc->lf);
	    printf(";");
	    UIndent("-");
	    break;
	}
    case CT_CMACR:{
	    printf("%s(", pc->name);
	    displayFAName(pc->lf);
	    printf(");");
	    break;
	}
    default:{
	    UIError("agat server", "%s %d", "displayFAConstruct: unknown CT_?", pc->t);
	    break;
	}
    }
}

void
displayFADef(FADef * pd)
{
    while (pd != (FADef *) NULL) {
	switch (pd->t) {
	    case DT_CONST:{
		printf("let %s", pd->name);
		printf("=");
		displayFAExpTree(pd->pen);
		printf(";");
		break;
	    }
	case DT_STREAM:{
		printf("let %s", pd->name);
		printf("=");
		displayFAConstruct(pd->pc);
		break;
	    }
	case DT_MACRO:{
		printf("let %s", pd->name);
		printf("( ");
		displayFAName(pd->lf);
		printf(") = ");
		displayFAConstruct(pd->pc);
		break;
	    }
	case DT_POSTPROC:{
		printf("%s(", pd->name);
		displayFAName(pd->lf);
		printf(")\n");
		break;
	    }
	default:{
		UIError("agat server", "%s %d", "displayFADef: unknown DT_?", pd->t);
		break;
	    }
	}

	pd = pd->next;
	if (pd != (FADef *) NULL)
	    UIndent("p");
    }
}


char *
typeToStr(int t)
{
    switch (t) {
	case VT_NOTYPE:
	return "every-type";
    case VT_BOOL:
	return "bool";
    case VT_INT:
	return "int";
    case VT_LONG:
	return "long";
    case VT_FLOAT:
	return "float";
    case VT_DOUBLE:
	return "double";
    default:
	return "unknown type";
    }
}
