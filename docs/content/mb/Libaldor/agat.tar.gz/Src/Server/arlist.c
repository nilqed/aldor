#include "agat.h"


#define AL_STARTSZ 10
#define AL_INCSZ   10

/**************************************************************** Prototypes */


/******************************************************************** Bodies */


sList *
slCreate(int j, int col, double val)
{
    sList *psl;

    psl = (sList *) UZalloc(sizeof(sList));
    psl->j = j;
    psl->col = col;
    psl->val = val;
    psl->next = NULL;
    return psl;
}


sList *
slAdd(sList ** psl, int j, int col, double val)
{
    sList *currCell = *psl;
    sList *predCell = NULL;
    sList *newCell;

    if ((*psl) == NULL) {
	(*psl) = slCreate(j, col, val);
    }
    else {
	while ((currCell->next != NULL) && (currCell->j < j)) {
	    predCell = currCell;
	    currCell = currCell->next;
	}
	if (currCell->j == j) {
	    currCell->col = col;
	    currCell->val = val;
	}
	else {
	    newCell = slCreate(j, col, val);
	    if ((predCell == NULL) && (currCell->j > j)) {	/* ins in head */
		newCell->next = currCell;
		(*psl) = newCell;
	    }
	    else {
		if ((currCell->next == NULL) && (currCell->j < j)) {
		    currCell->next = newCell;
		    newCell->next = NULL;
		}
		else {
		    newCell->next = currCell;
		    predCell->next = newCell;
		}
	    }
	}
    }
    return (*psl);
}


ArrayList *
alCreate(void)
{
    ArrayList *pal;

    pal = (ArrayList *) UZalloc(sizeof(ArrayList));
    pal->aimin = AL_STARTSZ / 2;
    pal->sz = AL_STARTSZ;
    pal->oneElt = False;
    pal->al = (void **) UCalloc(pal->sz, sizeof(void *));
    return pal;
}


void
alAdd(ArrayList * pal, int i, int j, int col, double val)
{
    int ai, asz;
    sList *l;
    sList *newCell;
    void **altmp;

    if (!alIsCreate(pal)) {
	fprintf(stderr, " Agat: Struct ArrayList not created !\n");
	exit(1);
    }
    if (pal->oneElt == False) {
	pal->rimin = i;
	pal->rimax = i;
	pal->oneElt = True;
    }
    ai = i - pal->rimin + pal->aimin;
    if ((ai < 0) || (ai >= pal->sz)) {
	/* Realloc to have more place */
	if (ai >= pal->sz) {
	    asz = ai - pal->sz + (float) pal->sz * 0.1 + AL_INCSZ;
	    pal->al = (void **) UReallocMsg(pal->al, (pal->sz + asz) * sizeof(void *), "Array List can't grow");
	    memset(&pal->al[pal->sz], '\0', asz * sizeof(void *));
	    pal->rimax = i;
	    pal->sz += asz;
	    ai = i - pal->rimin + pal->aimin;
	}
	else {
	    asz = abs(i - pal->rimin) + (float) pal->sz * 0.1 + AL_INCSZ;
	    altmp = (void **) UZallocMsg((pal->sz + asz) * sizeof(void *), "Array List can't grow");
	    memcpy(&altmp[asz], &pal->al[0], (pal->sz * sizeof(void *)));
	    memset(&altmp[0], '\0', asz * sizeof(void *));
	    free(pal->al);
	    pal->al = altmp;
	    pal->aimin = asz - abs(i - pal->rimin) + 1;
	    pal->rimin = i;
	    pal->sz += asz;
	    ai = i - pal->rimin + pal->aimin;
	}
    }
    /* There's a place to put the new value */
    l = (sList *) pal->al[ai];
    slAdd(&l, j, col, val);
    pal->al[ai] = l;
    if (i < pal->rimin)
	pal->rimin = i;
    if (i > pal->rimax)
	pal->rimax = i;
    if (ai < pal->aimin)
	pal->aimin = ai;
}


sList *
alLook(ArrayList * pal, int i, sList * psl)
{
    int ai;

    ai = i - pal->rimin + pal->aimin;
    if (psl == NULL)
	if ((ai < 0) || (ai >= pal->sz))
	    return (sList *) NULL;
	else
	    return (sList *) pal->al[ai];
    else
	return psl->next;
}


sList *
alLookElt(ArrayList * pal, int i, int j)
{
    sList *curr;
    int ai;

    ai = i - pal->rimin + pal->aimin;
    curr = pal->al[ai];
    while ((curr != NULL) && (curr->j != j))
	curr = curr->next;
    return curr;
}


int
alFirstElt(ArrayList * pal)
{
    if (alIsCreate(pal))
	return pal->rimin;
}


Boolean
alIsCreate(ArrayList * pal)
{
    return (pal != NULL);
}


Boolean
alIsElt(ArrayList * pal)
{
    if (alIsCreate(pal))
	return (pal->oneElt);
}
