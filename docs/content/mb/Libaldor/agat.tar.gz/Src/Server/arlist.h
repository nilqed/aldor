#ifndef ARLIST_H
#define ARLIST_H
#include "agat.h"

typedef struct sList {
    int j;
    int col;				/* Color */
    double val;				/* Value */
    struct sList *next;
}     sList;


typedef struct ArrayList {
    int sz;				/* Size of array */
    int aimin;				/* array min and max index */
    int rimin, rimax;			/* real  min and max index */
    Boolean oneElt;			/* There's one element in the struct
					 * ro not */
    void **al;				/* the elements of array */
}         ArrayList;


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
sList *slCreate(int j, int col, double val);

sList *slAdd(sList ** psl, int j, int col, double val);

ArrayList *alCreate(void);

void alAdd(ArrayList * pal, int i, int j, int col, double val);

sList *alLook(ArrayList * pal, int i, sList * psl);

sList *alLookElt(ArrayList * pal, int i, int j);

int alFirstElt(ArrayList * pal);

Boolean alIsCreate(ArrayList * pal);

Boolean alIsElt(ArrayList * pal);

/************************************************************ End Prototypes */


#endif
