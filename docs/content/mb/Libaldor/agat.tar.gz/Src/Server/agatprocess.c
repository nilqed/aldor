#include "agat.h"


/**************************************************************** Prototypes */


/******************************************************************** Bodies */

void
evalWarning(char *file, int lgn, char *msg)
{
    if (silentWarn)
	return;
    if ((file != NULL) && (lgn != 0))
	fprintf(stderr, "%s:%d: warning: %s\n", file, lgn, msg);
    else if (file != NULL)
	fprintf(stderr, "%s: warning: %s\n", file, msg);
    else
	fprintf(stderr, "warning: %s\n", msg);
}

 /* static */ void
castValue(Value * pv, int newType)
{
    switch (pv->t) {
	case VT_INT:{
	    switch (newType) {
		case VT_LONG:{
		    pv->v.l = pv->v.i;
		    break;
		}
	    case VT_DOUBLE:{
		    pv->v.d = pv->v.i;
		    break;
		}
	    }
	    break;
	}
    case VT_LONG:{
	    switch (newType) {
	    case VT_DOUBLE:{
		    pv->v.d = pv->v.l;
		    break;
		}
	    }
	    break;
	}
    case VT_BOOL:
    case VT_UCHAR:{
	    switch (newType) {
	    case VT_LONG:{
		    pv->v.l = pv->v.uc;
		    break;
		}
	    case VT_DOUBLE:{
		    pv->v.d = pv->v.uc;
		    break;
		}
	    }
	    break;
	}
    case VT_FLOAT:{
	    switch (newType) {
	    case VT_LONG:{
		    pv->v.l = pv->v.f;
		    break;
		}
	    case VT_DOUBLE:{
		    pv->v.d = pv->v.f;
		    break;
		}
	    }
	    break;
	}
    case VT_DOUBLE:{
	    switch (newType) {
	    case VT_LONG:{
		    pv->v.l = pv->v.d;
		    break;
		}
	    }
	    break;
	}
    }
    pv->t = newType;
}


/* convert the Value struct to a bit diffrent struct.      */
/* (but use the same memory for speed)                     */
/* the only type is double so the 't' field is used to     */
/* store the number of the stream which produce this value */
Value *
convertVal(Value * pv, int numStream, double d)
{
    pv->t = numStream;
    pv->v.d = d;
    return pv;
}

double
valToDouble(Value * pv)
{
    if (pv == NULL) {
	UIError("agat server", "%s", "valToDouble: NULL value ");
	return 0.0;
    }
    switch (pv->t) {
    case VT_BOOL:{
	    return (double) pv->v.uc;
	}
    case VT_UCHAR:{
	    return (double) pv->v.uc;
	}
    case VT_INT:{
	    return (double) pv->v.i;
	}
    case VT_LONG:{
	    return (double) pv->v.l;
	}
    case VT_FLOAT:{
	    return (double) pv->v.f;
	}
    case VT_DOUBLE:{
	    return (double) pv->v.d;
	}
    default:{
	    UIError("agat server", "%s %d", "valToDouble: unknown VT_?", pv->t);
	}
    }
}


Boolean
evalBool(Value * pv)
{
    switch (pv->t) {
    case VT_INT:
	return pv->v.i;
    case VT_LONG:
	return pv->v.l;
    case VT_BOOL:
    case VT_UCHAR:
	return pv->v.uc;
    case VT_FLOAT:
	return (pv->v.f != 0.0);
    case VT_DOUBLE:
	return (pv->v.d != 0.0);
    default:
	return False;
    }
}

 /* static */ FuncProto *
checkParameters(List * opl, Value ** av, int arity)
{
    int i, maxType = VT_NOTYPE;
    FuncProto *pfp, *pfBig = NULL, *pfSmall = NULL;

    for (i = 0; i < arity; i++)
	maxType = Max(maxType, av[i]->t);
    for (i = 0; i < lNbElts(opl); i++) {
	pfp = (FuncProto *) lLookNth(opl, i);
	if (pfp->pt == maxType)
	    return pfp;
	else if (pfp->pt > maxType)
	    pfBig = pfp;
	else
	    pfSmall = pfp;
    }
    if (pfBig)
	return pfBig;
    if (pfSmall)
	return pfSmall;
    pfp = (FuncProto *) lLookNth(opl, 0);
    UIError("agat server", "Bad parameter%s for function %s. %s don`t match prototypes"
	    ,NBTOSS(arity), pfp->n, typeToStr(maxType));
}


 /* static */ void
castParameters(int newType, Value ** av, int arity)
{
    int i;

    for (i = 0; i < arity; i++)
	if (newType != av[i]->t)
	    castValue(av[i], newType);
}

 /* static */ Value *
applyFunc(FuncProto * pfp, Value ** av, int arity)
{
    Value *pv;

    pv = allocValue();
    switch (pfp->rt) {
    case VT_LONG:{
	    pv->t = VT_LONG;
	    switch (pfp->pt) {
	    case VT_LONG:{
		    switch (arity) {
		    case 1:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l);
			    break;
			}
		    case 2:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l);
			    break;
			}
		    case 3:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l);
			    break;
			}
		    case 4:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l);
			    break;
			}
		    case 5:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l, av[4]->v.l);
			    break;
			}
		    case 6:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l, av[4]->v.l, av[5]->v.l);
			    break;
			}
		    case 0:{
			    pv->v.l = ((long (*) ()) *pfp->pf) ();
			    break;
			}
		    default:{
			    UIError("agat server", "%s", "not compiled for so much parameters %d ... look at function applyFunc", arity);
			}
		    }
		    break;
		}
	    case VT_DOUBLE:{
		    switch (arity) {
		    case 1:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d);
			    break;
			}
		    case 2:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d);
			    break;
			}
		    case 3:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d);
			    break;
			}
		    case 4:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d);
			    break;
			}
		    case 5:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d, av[4]->v.d);
			    break;
			}
		    case 6:{
			    pv->v.l = ((long (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d, av[4]->v.d, av[5]->v.d);
			    break;
			}
		    case 0:{
			    pv->v.l = ((long (*) ()) *pfp->pf) ();
			    break;
			}
		    default:{
			    UIError("agat server", "not compiled for so much parameters %d ... look at function applyFunc", arity);
			}
		    }
		    break;
		}
	    }
	    break;
	}
    case VT_DOUBLE:{
	    pv->t = VT_DOUBLE;
	    switch (pfp->pt) {
	    case VT_LONG:{
		    switch (arity) {
		    case 1:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l);
			    break;
			}
		    case 2:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l);
			    break;
			}
		    case 3:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l);
			    break;
			}
		    case 4:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l);
			    break;
			}
		    case 5:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l, av[4]->v.l);
			    break;
			}
		    case 6:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.l, av[1]->v.l, av[2]->v.l, av[3]->v.l, av[4]->v.l, av[5]->v.l);
			    break;
			}
		    case 0:{
			    pv->v.d = ((double (*) ()) *pfp->pf) ();
			    break;
			}
		    default:{
			    UIError("agat server", "bad number of parameters %d ... look at function applyFunc", arity);
			}
		    }
		    break;
		}
	    case VT_DOUBLE:{
		    switch (arity) {
		    case 1:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d);
			    break;
			}
		    case 2:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d);
			    break;
			}
		    case 3:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d);
			    break;
			}
		    case 4:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d);
			    break;
			}
		    case 5:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d, av[4]->v.d);
			    break;
			}
		    case 6:{
			    pv->v.d = ((double (*) ()) *pfp->pf) (av[0]->v.d, av[1]->v.d, av[2]->v.d, av[3]->v.d, av[4]->v.d, av[5]->v.d);
			    break;
			}
		    case 0:{
			    pv->v.d = ((double (*) ()) *pfp->pf) ();
			    break;
			}
		    default:{
			    UIError("agat server", "bad number of parameters %d ... look at function applyFunc", arity);
			}
		    }
		    break;
		}
	    }
	}
    }
    return pv;
}



 /* static */ Value *
evalOp(FAExpNode * pen)
{
    Value *av[MAX_ARITY];
    FuncProto *pfp;
    Value *res;

    int i;

    for (i = 0; i < pen->po->arity; i++) {
	av[i] = evalExpr(pen->po->sons[i]);
    }
    pfp = checkParameters(pen->po->opl, av, pen->po->arity);
    castParameters(pfp->pt, av, pen->po->arity);
    res = applyFunc(pfp, av, pen->po->arity);
    unAllocValueArray(av, pen->po->arity);
    return res;
}



 /* static */ Value *
evalVar(FAExpNode * pen)
{
    switch (pen->pvn->t) {
	case VNT_PAT:{
	    return dupValue((Value *) qLook(pen->pvn->pq));
	    break;
	}
    case VNT_REG:{
	    return dupValue(*pen->pvn->ppv);
	}
    case VNT_CST:{
	    if (pen->pvn->pv)
		return dupValue(pen->pvn->pv);
	    else {
		ConstDesc *pcd;

		/* this constant has never been accessed thru this expression */
		/* find it's value by looking into htConst */
		pcd = htSearchKey(htConst, pen->varName);
		if (!pcd)
		    UIError("agat server", "%s %s", "evalVar: undefined constant!", pen->varName);
		pen->pvn->pv = dupValue(pcd->pd->pv);
		return pen->pvn->pv;
	    }
	    break;
	}
    default:{
	    UIError("agat server", "%s %d", "evalVar: unknown VNT_?", pen->pvn->t);
	}
    }
}



Value *
evalExpr(FAExpNode * pen)
{
    switch (pen->t) {
	case ENT_OP:{
	    return evalOp(pen);
	    break;
	}
    case ENT_VAR:{
	    return evalVar(pen);
	    break;
	}
    case ENT_VAL:{
	    return dupValue(pen->pv);
	    break;
	}
    default:{
	    UIError("agat server", "%s %d", "evalExpr: unknown ENT_?", pen->t);
	}
    }
}


void
evalDefConsts(List * lcd)
{
    FADef *pd;
    Value *pv;
    int i;

    for (i = 0; i < lNbElts(lcd); i++) {
	pd = lLookNth(lcd, i);
	pv = evalExpr(pd->pen);
	pd->pv = pv;
    }
}




 /* static */ Value *
evalAction(Action * pa)
{
    Value *pv;
    Boolean et;

    switch (pa->t) {
    case ACT_EXPR:{
	    return evalExpr(pa->e);
	}
    case ACT_IFTE:{
	    pv = evalExpr(pa->e);
	    if (!compTypes(pv->t, VT_BOOL)) {
		char tmp[MAX_CHAR_TMP];

		sprintf(tmp, "uncompatible type for test expression (%s found).", typeToStr(pv->t));
		evalWarning(pa->file, pa->lgn, tmp);
		et = False;
	    }
	    else
		et = evalBool(pv);
	    unAllocValue(pv);
	    if (et == True)
		return evalActions(pa->thenA);
	    else
		return evalActions(pa->elseA);
	}
    case ACT_ASGN:{
	    pv = evalExpr(pa->e);
	    unAllocValue(*pa->preg);
	    *pa->preg = pv;
	    return dupValue(pv);
	}
    case ACT_NULL:
	return (Value *) NULL;
    default:{
	    UIError("agat server", "%s %d", "evalAction: unknown ACT_?", pa->t);
	}
    }
}


 /* static */ Value *
evalActions(Action ** aa)
{
    int i = 0;
    Value *pv = NULL;

    while (aa[i] != NULL) {
	pv = evalAction(aa[i]);
	i++;
	if (aa[i] != NULL)
	    unAllocValue(pv);
    }
    return pv;
}


 /* static */ Boolean
testPatMatch(unsigned char *ps, unsigned char *pp, unsigned char *pm, int nbb)
{
    int i;

    /* check if patterns are matching input-states */
    for (i = 0; i < nbb; i++)
	if ((ps[i] & pm[i]) != pp[i])
	    return False;
    return True;
}

 /* static */ void
refreshState(unsigned char *ps, unsigned char *pp, unsigned char *pm, int nbb, Queue ** aq)
{
    int i;
    Value *pv;

    /* modify input-state. new values are now old-ones   */
    /* and empty streams now have at least one old value */
    for (i = 0; i < nbb; i++)
	if (ps[i] & PAT_BIT_NEW_VALUE) {
	    if (qNbElts(aq[i]) > 1) {
		/* this old value is no longer used, a new one is in queue */
		pv = qGet(aq[i]);
		unAllocValue(pv);
	    }
	    else {
		/* no more new value in the queue */
		ps[i] &= ~PAT_BIT_NEW_VALUE;
	    }
	    /*
	     * this meen that at least one value is in queue. old or new no
	     * matter
	     */
	    ps[i] |= PAT_BIT_AT_LEAST_ONE_OLD;
	}
}

 /* static */ Value *
evalProx(Prox * pp)
{
    int i;
    Value *pv;

    pp->activated = False;
    for (i = 0; i < pp->nbpat; i++) {
	if (testPatMatch(pp->astate, pp->apat[i], pp->amask[i], pp->nbpred) == True) {
	    pv = evalActions(pp->aapact[i]);
	    refreshState(pp->astate, pp->apat[i], pp->amask[i], pp->nbpred, pp->ainput);
	    return pv;
	    break;
	}
    }
    return (Value *) NULL;
}

 /* static */ Value *
newValue(Prox * pp, int i)
{
    Byte *ps;

    ps = &(pp->astate[i]);
    if (*ps & PAT_BIT_NEW_VALUE) {
	*ps &= ~PAT_BIT_NEW_VALUE;
	return (Value *) qGet(pp->ainput[i]);
    }
    else {
	return (Value *) NULL;
    }
}

void *
initParKey(InitPar * pip)
{
    return pip->name;
}

InitPar *
buildInitPar(char *name, void *pe)
{
    InitPar *pip;

    pip = (InitPar *) UZalloc(sizeof(InitPar));
    pip->name = name;
    pip->pe = pe;
    return pip;
}


/* here you can add more info for your init functions           */
/* just add an InitPar struct to the HashTable                  */
/* an InitPar is a name and a void *                            */
/* give your info a name, give a pointer on this info           */
/* and you can retrieve it in your init function with this name */
/* using the getParByName                                       */
 /* static */ void
callInit(Prox * pp)
{
    HashTable *pht;
    InitPar *pip;
    int *pi;
    char **pn;
    int i;
    FAName *lf;

    pht = htCreate(10, initParKey, ordString, nullFunc, hashString, printString);
    pi = (int *) UZalloc(sizeof(int));
    *pi = pp->nbpred;
    pip = buildInitPar("arity", pi);
    htInsert(pht, pip, False);
    pn = (char **) UZalloc((pp->nbpred + 1) * sizeof(char *));
    pn[pp->nbpred] = NULL;
    lf = pp->pd->lf;
    for (i = 0; i < pp->nbpred; i++) {
	pn[i] = UStrDup(lf->n);
	lf = lf->next;
    }
    pip = buildInitPar("parNames", pn);
    htInsert(pht, pip, False);
    pp->cd = (*(pp->ppp->pfi)) (pht);
    pp->initDone = True;
}

Boolean
checkPPCParams(Prox * pp)
{
    int i;

    if (pp->ppp->synchType == ST_NONBLOCKING)
	return True;
    if (pp->ppp->synchType == ST_BLOCKING) {
	for (i = 0; i < pp->nbpred; i++) {
	    if (!(pp->astate[i] & PAT_BIT_NEW_VALUE))
		return False;
	}
	return True;
    }
    UIError("agat server", "%s %d", "checkPPCParams: unknown ST_?", pp->ppp->synchType);
    return False;
}


 /* static */ void
ppCall(Prox * pp)
{
    switch (pp->ppp->arity) {
	case VAR_ARITY:{
	    Value *av[MAX_VAR_ARITY];
	    int i;

	    for (i = 0; i < pp->nbpred; i++) {
		av[i] = newValue(pp, i);
	    }
	    (*(pp->ppp->pf)) (pp->cd, pp->nbpred, av);
	    break;
	}
    case 0:{
	    (*(pp->ppp->pf)) ();
	    break;
	}
    case 1:{
	    (*(pp->ppp->pf)) (pp->cd, newValue(pp, 0));
	    break;
	}
    case 2:{
	    (*(pp->ppp->pf)) (pp->cd, newValue(pp, 0), newValue(pp, 1));
	    break;
	}
    case 3:{
	    (*(pp->ppp->pf)) (pp->cd, newValue(pp, 0), newValue(pp, 1), newValue(pp, 2));
	    break;
	}
    case 4:{
	    (*(pp->ppp->pf)) (pp->cd, newValue(pp, 0), newValue(pp, 1), newValue(pp, 2), newValue(pp, 3));
	    break;
	}
    case 5:{
	    (*(pp->ppp->pf)) (pp->cd, newValue(pp, 0), newValue(pp, 1), newValue(pp, 2), newValue(pp, 3), newValue(pp, 4));
	    break;
	}
    default:{
	    UIError("agat server", "not compiled for so much parameters %d ... look at function ppCall", pp->nbpred);
	}
    }
}

 /* static */ void
postProcessCall(Prox * pp)
{
    pp->activated = False;
    if (pp->initDone == False)
	callInit(pp);
    if (checkPPCParams(pp))
	ppCall(pp);
}

void
giveValueToSuccs(Prox * pp, Value * pv)
{
    Value *pov;				/* Old Value */
    int i;
    Byte *state;
    Queue *pq;

    if (pv == NULL)
	return;
    for (i = 0; i < pp->nbsucc; i++) {
	state = &aProx[pp->asucc[i]]->astate[pp->asn[i]];
	pq = aProx[pp->asucc[i]]->ainput[pp->asn[i]];
	aProx[pp->asucc[i]]->activated = True;
	if (!(*state & PAT_BIT_NEW_VALUE)) {
	    /* this old value is no longer used, a new one is coming */
	    pov = qGet(pq);
	    unAllocValue(pov);
	    *state |= PAT_BIT_NEW_VALUE;
	}
	qAdd(pq, dupValue(pv));
    }
    unAllocValue(pv);
}


void
runProx(void)
{
    Value *pv;
    Prox *pp;
    int i;

    for (i = 0; i < nbProx; i++) {
	if (aProx[i]->activated) {
	    pp = aProx[i];
	    if (pp->pd->t == DT_POSTPROC) {
		postProcessCall(pp);
	    }
	    else if ((pp->pd->t == DT_STREAM) || (pp->pd->t == DT_EXTSTREAM)) {
		pv = evalProx(pp);
		/*
		 * a NULL_ACTION or a bad pattern state will return NULL as
		 * result
		 */
		if (pv != NULL)
		    giveValueToSuccs(pp, pv);
	    }
	}
    }
}
