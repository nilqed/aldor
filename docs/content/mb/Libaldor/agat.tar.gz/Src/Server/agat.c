#include "agat.h"

typedef struct DescSid {
    char *name;				/* name of this stream */
    char type;				/* type  " */
    int indprox;			/* index of associated Prox in aProx */
}       DescSid;

static int portNum;			/* TCP/IP port number for connection
					 * to server */
static int lineFromAlgo;		/* id of line used to receive data
					 * from algo */
static DescSid *aDescSid = (DescSid *) NULL;
static Bools replay = False;
static HashTable *htKnownStream;
static char *sfn = NULL;		/* Script File Name */
static char *dfn = NULL;		/* Dump File Name */
static char *rfn = NULL;		/* Replay File Name */
static char *sspeed = NULL;		/* Speed */
static FILE *df;
static float timeStep = 1.0;
static Bools maxSpeed = False;


int globalArgc;
char **globalArgv;


/**************************************************************** Prototypes */

static void getEnvParams(char **psfn, char **pdfn, char **prfn);
static void parseParams(int *pargc, char ***pargv, char **psfn, char **pdfn, char **prfn, char **pss, Bools * pmaxSpeed);
static void usage(void);
static void completeParams(int argc, char **argv, char **psfn, char **pdfn, char **prfn);
static void checkLineError(int errCode, char *errMsg);
static void startReplay(char *rfn, FILE ** pdf);
static void startAlgo(int argc, char **argv, char *dfn);
static void setEnvVars(char *dfn, Bools play, int port);
static int getNewValueFromFile(FILE * df);
static Value *getNewValueFF(FILE * df, ValueType type);
static long getWaitTimeFromFile(FILE * df);
static Value *getNewSingleValueFF(FILE * df, ValueType vtype);
static int getNewValueFromAlgo(void);
static Value *getNewValueFA(MsgHeader * pMsg);
static Value *getNewSingleValueFA(MsgHeader * pMsg, ValueType vtype, int sid);
static void storeNewStreamNameFromAlgo(MsgHeader * pMsg, int len);
static void checkNewStream(char *name, ValueType type);
static void addNewName(char *name, ValueType type, int ip);
static void checkSameType(MsgHeader * pMsg);
static void *keyDescSid(DescSid * pd);
static void *keyXwin(Xwin * pxw);

/******************************************************************** Bodies */



int
main(int argc, char **argv, char **env)
{
    fd_set inputFds;
    int xfd;
    Display *dpy;

    globalArgc = argc;
    globalArgv = argv;
    getEnvParams(&sfn, &dfn, &rfn);
    lIncludePath = lCreate(keySame, ordString, free, printString);
    lAdd(lIncludePath, (void *) ".");

    parseParams(&argc, &argv, &sfn, &dfn, &rfn, &sspeed, &maxSpeed);
    if (sspeed != NULL) {
	if (maxSpeed == True)
	    UIWarning("agat server", "Speed option -s discarded. MaxSpeed option -m used instead.");
	timeStep = 100.0 / atoi(sspeed);
    }
    completeParams(argc, argv, &sfn, &dfn, &rfn);
    if (!replay) {
	while (USInit(portNum, "agatServer")) {
	    fprintf(stderr, "Agat Server: Failed to bind to port %d\n", portNum);
	    portNum++;
	    fprintf(stderr, "             Trying on port %d\n", portNum);
	}
    }
    setEnvVars(dfn, (sfn != NULL) ? True : False, portNum);
    htKnownStream = htCreate(HT_KNOWNSTREAM_SZ, keyDescSid, ordString, nullFunc, hashString, printString);
    htXwin = htCreate(HT_XWIN_SZ, keyXwin, ordInt, nullFunc, hashInt, printInt);

    if (replay)
	startReplay(rfn, &df);
    else
	startAlgo(argc, argv, dfn);

    compileFile(sfn);

    if (replay)
	playReplay();
    else
	playAlgo();


    /* when algo or replay is finished... keep watching XEvents */
    dpy = openDisplayOnlyOne();
    xfd = XConnectionNumber(dpy);
    FD_ZERO(&inputFds);
    FD_SET(xfd, &inputFds);
    while (1) {
	checkXEvents();
	/* block until event */
	if (URestartSelect(xfd + 1,
			   (fd_set *) & inputFds,
			   (fd_set *) NULL,
			   (fd_set *) NULL,
			   (struct timeval *) NULL) < 0) {
	}
    }
    return 0;
}

void
playReplay(void)
{
    Bools t = Ok;
    long wt;				/* waiting time during replay */

    while (1) {
	t = getNewValueFromFile(df);
	wt = getWaitTimeFromFile(df);
	/* wait a bit (as recorded) */
	if (!maxSpeed) {
	    struct timeval time;

	    wt = timeStep * wt;
	    time.tv_sec = wt / 1000;
	    time.tv_usec = (wt % 1000) * 1000;
	    select(0, NULL, NULL, NULL, &time);
	}
	if (t != Ok)
	    break;
	runProx();
	checkXEvents();
    }
    if (rfn != NULL)
	printf("\n\nAgat: End of replay for %s\n", rfn);
    else
	printf("\n\nAgat: End of process\n");
}

void
playAlgo(void)
{
    int t;

    while (1) {
	t = getNewValueFromAlgo();
	if (t < 0)		/* error */
	    break;
	if (t > 0)		/* some message */
	    runProx();
	checkXEvents();
    }
    if (globalArgv[0] != NULL)
	printf("\n\nAgat: End of %s\n", globalArgv[0]);
    else
	printf("\n\nAgat: End of process\n");
}

static void
getEnvParams(char **psfn, char **pdfn, char **prfn)
{
    char tmp[MAX_CHAR_TMP], *s;

    sprintf(tmp, "%s%s", AGAT_ENV, "script");
    *psfn = getenv(tmp);

    sprintf(tmp, "%s%s", AGAT_ENV, "port");
    s = getenv(tmp);
    if ((!s) || (!(portNum = atoi(s))))
	portNum = DEFAULT_PORT;
}

static void
parseParams(int *pargc, char ***pargv, char **psfn, char **pdfn, char **prfn, char **pss, Bools * pmaxSpeed)
{
    Bools agtParams = True;
    Bools fSet = False;
    char *pathComp;

    (*pargc)--;				/* forget the name of the command */
    (*pargv)++;
    if (*pargc == 0)
	usage();
    while ((agtParams == True) && (*pargc != 0)) {
	if ((**pargv)[0] != '-') {
	    agtParams = False;
	}
	else {
	    switch ((**pargv)[1]) {
	    case 'f':{
		    if (fSet == True) {
			UIWarning("agat server", "%s %s", WM_OPTMULTDEF, "-f");
			UIWarning("agat server", "%s %s", WM_USING, *psfn);
		    }
		    else if (*psfn != NULL) {
			UIWarning("agat server", "%s %s", WM_ENVARSET, "-f");
			if (UGetStringParam(pargc, pargv, psfn) != Ok)
			    usage();
			UIWarning("agat server", "%s %s", WM_USING, *psfn);
		    }
		    else if (UGetStringParam(pargc, pargv, psfn) != Ok) {
			usage();
		    }
		    fSet = True;
		    break;
		}
	    case 'd':{
		    if (*pdfn != NULL) {
			UIWarning("agat server", "%s %s", WM_OPTMULTDEF, "-d");
			UIWarning("agat server", "%s %s", WM_USING, *pdfn);
		    }
		    else if (UGetStringParam(pargc, pargv, pdfn) != Ok) {
			usage();
		    }
		    break;
		}
	    case 'r':{
		    if (*prfn != NULL) {
			UIWarning("agat server", "%s %s", WM_OPTMULTDEF, "-r");
			UIWarning("agat server", "%s %s", WM_USING, *prfn);
		    }
		    else if (UGetStringParam(pargc, pargv, prfn) != Ok) {
			usage();
		    }
		    replay = True;
		    break;
		}
	    case 's':{
		    if (*pss != NULL) {
			UIWarning("agat server", "%s %s", WM_OPTMULTDEF, "-s");
			UIWarning("agat server", "%s %s", WM_USING, *pss);
		    }
		    else if (UGetStringParam(pargc, pargv, pss) != Ok) {
			usage();
		    }
		    break;
		}
	    case 'I':{
		    if (UGetStringParam(pargc, pargv, &pathComp) != Ok) {
			usage();
		    }
		    lAdd(lIncludePath, pathComp);
		    break;
		}
	    case 'm':{
		    *pmaxSpeed = True;
		    (*pargc)--;
		    (*pargv)++;
		    break;
		}
	    case 'w':{
		    silentWarn = True;
		    (*pargc)--;
		    (*pargv)++;
		    break;
		}
	    default:{
		    usage();
		    break;
		}
	    }
	}
    }
}


static void
usage(void)
{
    fprintf(stderr, "agat [-f scriptname] [-d dumpfilename] [-r replayfilename] [-s speed] [-m] [-w] [cmd] [parameters of cmd]\n");
    fprintf(stderr, "     scriptname    : name of the .agt file to use for animation\n");
    fprintf(stderr, "     dumpfilename  : name of the file to use for animation storage\n");
    fprintf(stderr, "     replayfilename: name of the file to use for animation replay\n");
    fprintf(stderr, "     speed         : an integer to use as speed ratio during replay\n                     (100 = normal speed)\n");
    fprintf(stderr, "     -m            : replay animation with maximum speed\n");
    fprintf(stderr, "     -w            : supress warnings\n");
    fprintf(stderr, "     cmd           : name of the executable command to animate\n");
    fprintf(stderr, "     parameters of : all the parameters of the cmd \n");
    exit(1);
}



static void
completeParams(int argc, char **argv, char **psfn, char **pdfn, char **prfn)
{
    if ((*prfn != NULL) && (argc != 0)) {
	UIWarning("agat server", "%s %s", WM_REPLFNUNUSED, argv[0]);
	free(*prfn);
	*prfn = NULL;
	replay = False;
    }
    if ((*prfn != NULL) && (*pdfn != NULL)) {
	UIWarning("agat server", "%s %s", WM_REPLFANDDMPFN, *prfn);
	free(*pdfn);
	*pdfn = NULL;
    }
    if ((*prfn == NULL) && (argc == 0)) {
	UIError("agat server", "%s", ER_NOANIM);
    }
    if ((*psfn == NULL) && (((argc != 0) && (*pdfn == NULL)) || (*prfn != NULL))) {
	UIError("agat server", "%s", ER_NOSFN);
    }
}


static void
checkLineError(int errCode, char *errMsg)
{
    if (errCode) {
	UIError("server: ", "%s", errMsg);
	UExit(errCode);
    }
}

static void
startReplay(char *rfn, FILE ** pdf)
{
    *pdf = UCompressedFOpen(rfn, "r");
    if (*pdf == NULL) {
	UIError("agat server", "%s %s %s", ER_CANTOPENFILE, rfn, " (the replay file)");
    }
}


static void
startAlgo(int argc, char **argv, char *dfn)
{
    pid_t pid;

    if ((pid = fork()) == 0) {
	execvp(argv[0], argv);
    }
    if (pid < 0)
	UIError("agat server", "%s %s", ER_CANTEXECUTEALGO, argv[0]);
    USWaitForNewLine(&lineFromAlgo);
}


static void
setEnvVars(char *dfn, Bools play, int port)
{
    char tmp[MAX_CHAR_TMP];

    if (dfn != NULL) {
	sprintf(tmp, "%s%s=%s", AGAT_ENV, "dump", dfn);
	putenv(UStrDup(tmp));
    }
    else {
	sprintf(tmp, "%s%s=%s", AGAT_ENV, "dump", "");
	putenv(UStrDup(tmp));
    }

    if (play) {
	sprintf(tmp, "%s%s=%s", AGAT_ENV, "play", "ok");
	putenv(UStrDup(tmp));
    }
    else {
	sprintf(tmp, "%s%s=%s", AGAT_ENV, "play", "");
	putenv(UStrDup(tmp));
    }
    sprintf(tmp, "%s%s=%s", AGAT_ENV, "running", "ok");
    putenv(UStrDup(tmp));
    sprintf(tmp, "%s%s=%d", AGAT_ENV, "port", port);
    putenv(UStrDup(tmp));

}


static int
getNewValueFromFile(FILE * df)
{
    char fn[FN_MAXLEN], *name;
    DescSid *pd;
    Value *pv;
    int type;
    int indProx, fs;

    fs = fscanf(df, "%s %d ", fn, &type);
    if ((fs == EOF) || (fs < 2))
	return Err;
    /* Is it the first reference to this Stream */
    if ((pd = htSearchKey(htKnownStream, fn)) == NULL) {
	name = UStrDup(fn);
	checkNewStream(name, (Byte) type);
	pd = htSearchKey(htKnownStream, name);
    }
    pv = getNewValueFF(df, (Byte) type);
    if (pv != NULL) {
	if ((indProx = pd->indprox) >= 0) {
	    /* check if this stream is part of evaluation graph */
	    /* a stream can be send by algorithm and no be used */
	    giveValueToSuccs(aProx[indProx], pv);
	}
    }
    return Ok;
}

static Value *
getNewValueFF(FILE * df, ValueType type)
{
    return getNewSingleValueFF(df, type);
}


static long
getWaitTimeFromFile(FILE * df)
{
    long wt;

    if (fscanf(df, "%d", &wt) != 1)
	return 0;
    return wt;
}


static Value *
getNewSingleValueFF(FILE * df, ValueType vtype)
{
    Value *pv;
    long i;
    float f;
    double d;

    pv = allocValue();
    switch (vtype) {
    case VTYP_INT:{
	    if (fscanf(df, "%d", &i) != 1)
		return (Value *) NULL;
	    pv->v.i = (int) i;
	    pv->t = VT_INT;
	    return pv;
	    break;
	}
    case VTYP_LONG:{
	    if (fscanf(df, "%d", &i) != 1)
		return (Value *) NULL;
	    pv->v.l = (long) i;
	    pv->t = VT_LONG;
	    return pv;
	    break;
	}
    case VTYP_FLOAT:{
	    if (fscanf(df, "%f", &f) != 1)
		return (Value *) NULL;
	    pv->v.f = (float) f;
	    pv->t = VT_FLOAT;
	    return pv;
	    break;
	}
    case VTYP_DOUBLE:{
	    if (fscanf(df, "%lf", &d) != 1)
		return (Value *) NULL;
	    pv->v.d = (double) d;
	    pv->t = VT_DOUBLE;
	    return pv;
	    break;
	}
    default:{
	    UIWarning("agat server", "%s %d", ERS_UNKNOWN_VTYP, vtype);
	    return (Value *) NULL;
	}
    }
}




static int
getNewValueFromAlgo(void)
{
    MsgHeader *pMsg;
    int indProx, len, norb = 0;
    int stat;
    Value *pv;
    struct timeval timeout;

    timeout.tv_sec = 0;
    timeout.tv_usec = 250000; /*1/4s*/

    if (USWaitForMsg(lineFromAlgo, &timeout) <= 0)
	return stat;		/* error or no message */
    if ((stat = USGetNextMsg(lineFromAlgo, (Byte **) & pMsg, &len)) < 0)
	return stat;

    if (pMsg->sid == 0) {
	storeNewStreamNameFromAlgo(pMsg, len);
	/* wait for a new Msg to get value */
	checkLineError(USGetNextMsg(lineFromAlgo, (Byte **) & pMsg, &len),
		       "get message failed.");
    }

    pv = getNewValueFA(pMsg);
    if (pv != NULL) {
	if ((indProx = aDescSid[pMsg->sid].indprox) >= 0) {
	    /* check if this stream is part of evaluation graph */
	    /* a stream can be send by algorithm and no be used */
	    giveValueToSuccs(aProx[indProx], pv);
	}
    }
    return 1;
}


static Value *
getNewValueFA(MsgHeader * pMsg)
{
    checkSameType(pMsg);
    return getNewSingleValueFA(pMsg, pMsg->type, pMsg->sid);
}


static Value *
getNewSingleValueFA(MsgHeader * pMsg, ValueType vtype, int sid)
{
    Value *pv;

    pv = allocValue();
    switch (vtype) {
    case VTYP_INT:{
	    memcpy(&pv->v.i, ((char *) pMsg) + sizeof(MsgHeader), sizeof(int));
	    pv->t = VT_INT;
	    return pv;
	    break;
	}
    case VTYP_LONG:{
	    memcpy(&pv->v.l, ((char *) pMsg) + sizeof(MsgHeader), sizeof(long));
	    pv->t = VT_LONG;
	    return pv;
	    break;
	}
    case VTYP_FLOAT:{
	    memcpy(&pv->v.f, ((char *) pMsg) + sizeof(MsgHeader), sizeof(float));
	    pv->t = VT_FLOAT;
	    return pv;
	    break;
	}
    case VTYP_DOUBLE:{
	    memcpy(&pv->v.d, ((char *) pMsg) + sizeof(MsgHeader), sizeof(double));
	    pv->t = VT_DOUBLE;
	    return pv;
	    break;
	}
    default:{
	    UIWarning("agat server", "%s %d", ERS_UNKNOWN_VTYP, vtype);
	    return (Value *) NULL;
	}
    }
}



static void
storeNewStreamNameFromAlgo(MsgHeader * pMsg, int len)
{
    char *name;

    name = UStrDup(((char *) pMsg) + sizeof(MsgHeader));
    checkNewStream(name, pMsg->type);
}

static void
checkNewStream(char *name, ValueType type)
{
    ExtStream *pes;
    int indprox;

    /* Is this Stream a good one?                        */
    /* (used in the .agt file which is beeing processed) */
    if ((pes = htSearchKey(htExtStream, name)) == NULL) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp, "incoming data on stream %s will be ignored (unknown stream)", name);
	evalWarning((char *) NULL, 0, tmp);
	indprox = -1;
    }
    else
	indprox = pes->indProx;
    addNewName(name, type, indprox);
}


static void
addNewName(char *name, ValueType type, int ip)
{
    static int aDescSidSz = 0;
    static int nbDescSid = 0;

    if (nbDescSid >= aDescSidSz - 1) {
	if (aDescSid == (DescSid *) NULL) {
	    aDescSidSz += RM_CHKZ_DESCSID;
	    aDescSid = (DescSid *) malloc(sizeof(DescSid) * aDescSidSz);
	    nbDescSid = 1;
	    /* the first sid is 1 to distinguish no-sid==0 and first-sid==1 */
	}
	else {
	    aDescSidSz += RM_CHKZ_DESCSID;
	    aDescSid = (DescSid *) realloc(aDescSid, sizeof(DescSid) * aDescSidSz);
	}
    }
    aDescSid[nbDescSid].name = name;
    aDescSid[nbDescSid].type = type;
    aDescSid[nbDescSid].indprox = ip;
    htInsert(htKnownStream, &aDescSid[nbDescSid], False);
    nbDescSid++;
}


static void
checkSameType(MsgHeader * pMsg)
{
    if ((int) aDescSid[pMsg->sid].type != (int) pMsg->type)
	UIWarning("agat server", "%s %s", WN_CHANGEDMETYPE, aDescSid[pMsg->sid].name);
}


static void *
keyDescSid(DescSid * pd)
{
    return pd->name;
}

static void *
keyXwin(Xwin * pxw)
{
    return &pxw->win;
}
