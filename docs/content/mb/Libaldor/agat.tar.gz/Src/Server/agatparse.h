#ifndef AGATPARSE_H
#define AGATPARSE_H

#include "agat.h"


/* error msgs */
#define ER_LEX_BADCAR  "Strange character during parsing: "
#define ER_YACC_SYNTAX "Syntax error near word: "


/* some globaly used vars */

extern char *curFile;
extern int curLgn;

/* extern unsigned char    yytext[]; */
extern int nbError;


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
Value *bvInt(char *s);

Value *bvFloat(char *s);

Value *bvBool(int b);

char *keepIdent(char *s);

FAOp *dupFAOp(FAOp * opo);

FAExpNode *allocFAExpNode(void);

FAExpNode *dupFAExpNode(FAExpNode * open);

FAExpNode *benValue(Value * pv);

FAExpNode *benVar(char *varName);

FAExpNode *benFuncUn(char *op, FAExpNode * s);

FAExpNode *benFuncBin(char *op, FAExpNode * ls, FAExpNode * rs);

FAExpNode *benFuncTern(char *op, FAExpNode * ls, FAExpNode * ms, FAExpNode * rs);

FAExpNode *benFuncCall(char *nameOp, FAExpNode * pNode);

FAExpNode *benArgList(FAExpNode * pNewExpNode, FAExpNode * pFuncCallNode);

FAAction *bAction(int t, char *n, FAExpNode * e, FAAction * ta, FAAction * ea);

FAAction *dupActions(FAAction * la);

FAPattern *bPattern(char *n, unsigned char s);

FAClause *bClause(FAPattern * lp, FAAction * la);

FAClause *dupClauses(FAClause * lc);

FAReg *bReg(char *n, FAExpNode * pen);

FAName *bName(char *n);

FADef *bDef(int t, char *name, FAName * lf, FAConstruct * pc, FAExpNode * pen);

FAConstruct *bConstruct(int t, FAReg * lr, FAClause * lc, FAName * lf);

FAConstruct *dupConstruct(FAConstruct * opc);

/***************************/
void displayValue(Value * pv);

void displayFAExpTree(FAExpNode * pen);

void displayFAExpressions(FAExpNode * pen);

void displayFAAction(FAAction * pa);

void displayFAPattern(FAPattern * pp);

void displayFAClause(FAClause * pc);

void displayFAName(FAName * lf);

void displayFAReg(FAReg * pr);

void displayFAConstruct(FAConstruct * pc);

void displayFADef(FADef * pd);

char *typeToStr(int t);

/************************************************************ End Prototypes */

#endif
