#ifndef AGATXGEN3D_H
#define AGATXGEN3D_H

#include "agat.h"


typedef struct AnyClassOp3D {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;
    RGB *tabRGB;			/* array of RGB values of the colors
					 * to draw in PS */
    int fontHeight, fontWidth;
    int xsz, ysz;			/* window size */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    View vw;
    void (*refresh) ();
    Boolean firstValue;			/* is this the first point ? */
    Boolean doAxe;			/* must we do the axes ? */
    double minx, maxx, miny, maxy, minz, maxz;	/* values extrema */
}            AnyClassOp3D;



/**************************************************************** Prototypes */


/* */
void printMat(Matrix4 * m);

void printVect(Vector3 * v);

void printPoint(Vector3 * p);

void moveMouse3D(AnyClassOp3D * pp, View * vw);

/***************************************************************************\
|*   Functions for matrix computation                                      *|
\***************************************************************************/
void evaluateVOM(Point3 * vrp, Vector3 * vpn, Vector3 * vup, Matrix4 * vom);

/* Clip planes */
void evaluateVMM(double umin, double umax, double vmin, double vmax, int projectionType, Point3 * prp, double fpd, double bpd, Matrix4 * vmm);

/* We specify the NPC viewport */
void evaluateMVV3DV(double xvmin, double xvmax, double yvmin, double yvmax, double zvmin, double zvmax, Matrix4 * mvv3dv);

void evaluateViewRepresentation(View * vw, AnyClassOp3D * pp, Point3 * vrp, Vector3 * vup, int evom, int evmm, int emvv);

void init3D(View * vw, double xmin, double xmax, double ymin, double ymax, double zmin, double zmax, Point3 * vrp, Point3 * vup);

void ChangeBb(View * vw, double xmin, double xmax, double ymin, double ymax, double zmin, double zmax);

int pointInWindow(AnyClassOp3D * pp, Point3 * pt);

void moveVRP(AnyClassOp3D * pp);

/************************************************************ End Prototypes */


#endif
