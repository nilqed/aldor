#include "agat.h"


/**************************************************************** Prototypes */


/******************************************************************** Bodies */

Matrix4 *
matBallRot(double cos_theta, double sin_theta, Point3 * n, Matrix4 * rm)
{
    rm->elt[0][0] = cos_theta + (n->x * n->x) * (1 - cos_theta);
    rm->elt[0][1] = n->x * n->y * (1 - cos_theta) - n->z * sin_theta;
    rm->elt[0][2] = n->x * n->z * (1 - cos_theta) + n->y * sin_theta;
    rm->elt[0][3] = 0.0;

    rm->elt[1][0] = n->y * n->x * (1 - cos_theta) + n->z * sin_theta;
    rm->elt[1][1] = cos_theta + (n->y * n->y) * (1 - cos_theta);
    rm->elt[1][2] = n->y * n->z * (1 - cos_theta) - n->x * sin_theta;
    rm->elt[1][3] = 0.0;

    rm->elt[2][0] = n->z * n->x * (1 - cos_theta) - n->y * sin_theta;
    rm->elt[2][1] = n->z * n->y * (1 - cos_theta) + n->x * sin_theta;
    rm->elt[2][2] = cos_theta + (n->z * n->z) * (1 - cos_theta);
    rm->elt[2][3] = 0.0;

    rm->elt[3][0] = 0.0;
    rm->elt[3][1] = 0.0;
    rm->elt[3][2] = 0.0;
    rm->elt[3][3] = 1.0;
    return (rm);
}


void
ModifyView(View * vw, int dx, int dy, Matrix4 * matRet)
{
    Point3 n;
    double Tx, Ty, Tz, dr, denom, cos_theta, sin_theta;
    Matrix4 matrix3D, tmpMat, transToOrigin, rMat;
    double radius = 100.0;


    /*
     * Example of interactive method: apply rolling ball to object's
     * orientation as long as mouse Button1 is held down.
     */
    /* Obtain current object position from its frame. */
    /*
     * Tx = (vw->mRot).elt[0][3]; Ty = (vw->mRot).elt[1][3]; Tz =
     * (vw->mRot).elt[2][3];
     */

    /*
     * Compute the rolling ball axis and angle from the incremental mouse
     * displacements (dx,dy) and compute corresponding rotation matrix RMat.
     * See text for full form of Rmat returned by Make3DRot. NOTE: For window
     * systems using a left-handed screen coordinate system, the formula
     * (-dy,dx,0) given in the text for the rotation axis direction must be
     * changed to (+dy,dx,0) to give the desired effect! We explicitly use
     * this coordinate system in the example code because so many systems
     * possess this reversal.
     */
    dr = sqrt(dx * dx + dy * dy);
    denom = sqrt(radius * radius + dr * dr);
    cos_theta = radius / denom;
    sin_theta = dr / denom;
    n.x = 0.0;				/* n.z = ... */
    n.y = ((double) (dy)) / dr;		/* n.x = ... (dy *//* Change sign for
					 * right-handed coord system. */
    n.z = ((double) (dx)) / dr;		/* n.y = ... (dx */

    matBallRot(cos_theta, sin_theta, &n, matRet /* &rMat */ );

    /* Translate current object frame to origin. */
    /* V3MatTranslate(&transToOrigin, -Tx, -Ty, -Tz); */
    /* V3MatMul(&transToOrigin, &(vw->mRot), &matrix3D); */

    /* Rotate about origin. */
    /* V3MatMul(&rMat, &matrix3D, &tmpMat); */

    /* Translate rotated temporary frame back to original object position. */
    /* V3MatTranslate(&transToOrigin, Tx, Ty, Tz); */
    /* V3MatMul(&transToOrigin, &tmpMat, &matrix3D); */

    /* Install new frame in object */
/*    V3MatCopy(&rMat, matRet);*/
}
