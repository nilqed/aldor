#ifndef AGATBUILD_H
#define AGATBUILD_H

#include "agat.h"




extern Prox **aProx;
extern int nbProx;
extern HashTable *htExtStream;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
Value *allocValue(void);

void unAllocValue(Value * pv);

void unAllocValueArray(Value ** av, int nbv);

Value *dupValue(Value * pv);

/* static */
FADef *addExternStreamAux(FAName * lf, FADef * lnd);

/* static */
void addExternStream(FADef * ld);

/* static */
void *keyConstDef(FADef * pd);

List *findConstEvalOrder(FADef * ldef);

void computeConsts(FADef * ldef);

void *keyStreamDef(FADef * pd);

/* static */
void addArcs(OGraph * gdep, FAName * lf, FADef * pd, HashTable * htStreamDef);

List *orderGraph(FADef * ldef, HashTable * htStreamDef);

int streamNametoNb(char *n, FAName * ln);

int regNametoNb(char *n, FAReg * lr);

int patNametoNb(char *n, FAPattern * lp);

/* static */
void completeVarNode(FAExpNode * pe, FAPattern * lp, FADef * pd);

HashTable *buildHTGraph(FADef * ldef);

/* static */
int nbReg(FAReg * lr);

/* static */
int nbClause(FAClause * lc);

/* static */
void buildPattern(FAPattern * lp, unsigned char **pap, unsigned char **pam);

Action *FAAtoA(FAAction * pfaa, FAReg * lr, FAPattern * lp, FADef * pd);

/* static */
Action **buildAAction(FAAction * lfaa, FAReg * lr, FAPattern * lp, FADef * pd);

/* static */
void initStreamProx(FADef * pd, Prox * pp);

/* static */
void initPostProcProx(FADef * pd, Prox * pp);

/* static */
Prox *buildProx(FADef * pd, int indprox);

/* static */
void buildAllProx(FADef * ldef, List * evalOrder, HashTable * htStreamDef);

/* static */
void incNbSucc(FAName * pn, HashTable * htStreamDef);

/* static */
void addSuccs(FAName * pn, int succ, HashTable * htStreamDef);

/* static */
void fillAllProxSucc(HashTable * htStreamDef);

ExtStream *buildExtStream(char *n, int i);

void *extStreamKey(ExtStream * pes);

HashTable *buildHTExternStream(void);

/* static */
void initRegisters(void);

/* after this function all must be ready for animation */
void compileGraph(FADef * ldef);

void compileFile(char *fname);

/************************************************************ End Prototypes */

#endif
