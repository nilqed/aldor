#ifndef AGATXDRAW_H
#define AGATXDRAW_H
#include "agat.h"

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
RGB gc2RGBColor(AnyClassOp * pc, GC gc);

void agatDrawPoint(AnyClassOp * pc, Drawable d, GC gc, int x, int y);

void agatDrawLine(AnyClassOp * pc, Drawable d, GC gc, int x1, int y1, int x2, int y2);

void agatDrawString(AnyClassOp * pc, Drawable d, GC gc, int x, int y, char *str, int size);

void agatDrawRectangle(AnyClassOp * pc, Drawable d, GC gc, int x, int y, int w, int h);

void agatFillRectangle(AnyClassOp * pc, Drawable d, GC gc, int x, int y, int w, int h);

/* definit l'appartenance aux 4 zones
/* de l'ecran
/*   rux ruy : largeur et hauteur de l'ecran de clipping
/*   x y     : coordonnees du point a tester
/*   p       : octet qui contiendra le code de la zone ou se trouve le point
/*             ex:  p= ox1001 => pt a droite du bord droit
/*                               pt au dessus du haut de l'ecran
*/
void position(double rux, double ruy, double x, double y, int *p);

/* gestion du clipping    Cohen-Sutherland
/*   rux ruy     : largeur et hauteur de l'ecran de clipping
/*   x1 y1 x2 y2 : coordonnees du segment a clipper
/*   p           : le code de la zone ou se trouve le point x1 y1
/*   xc yc       : les coordonnees apres clipping de x1 y1
*/
int clipping(double rux, double ruy, int p, double x1, double y1, double x2, double y2, double *xc, double *yc);

/* affichage d'un segment de droite
/*    dpy, win        : display et window ou ecrire
/*    gc              : graphic context pour le trace
/*    x1,y1,x2,y2     : coordonnees des extremites du segment
/*    dux duy dlx dly : les coordonnees de la fenetre de clipping
/*    clip            : faut il clipper ?
*/
void agatDrawBasicLine(AnyClassOp * pc, Window win, GC gc, double x1, double y1, double x2, double y2, double dux, double duy, double dlx, double dly);

/************************************************************ End Prototypes */

#endif
