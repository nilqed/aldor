#include "agat.h"


#define min(x1,x2) (((x1)<(x2)) ? (x1) : (x2))
#define max(x1,x2) (((x1)>(x2)) ? (x1) : (x2))

/**************************************************************** Prototypes */


/******************************************************************** Bodies */


void
dpySelectRect(Display * dpy, Window win, GC xorGc,
	      int imX, int imY, int mX, int mY)
{

    XDrawRectangle(dpy, win, xorGc, min(imX, mX), min(imY, mY),
		   max(imX, mX) - min(imX, mX), max(imY, mY) - min(imY, mY));
}

void
selectRect(Xwin * pxw, int x, int y)
{
    XEvent event;
    XExposeEvent expevent;
    int imX, imY, mX, mY;
    GC xorGc;
    char *winName;

    xorGc = createXorColorGc(pxw->dpy, pxw->win, 1);

    imX = x;
    mX = imX;
    imY = y;
    mY = imY;
    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);

    while (True != XCheckMaskEvent(pxw->dpy, ButtonReleaseMask, &event)) {
	if (True == XCheckMaskEvent(pxw->dpy, PointerMotionMask, &event)) {
	    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
	    mX = event.xmotion.x;
	    mY = event.xmotion.y;
	    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
	}
    }
    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
    /* Call the "mathematic" zoom function */
    (*(pxw->fzoo)) (pxw->pe, min(imX, mX), min(imY, mY), max(imX, mX), max(imY, mY));
}


void
selectStrip(Xwin * pxw, int x, int y)
{
    int imX, imY, mX, mY;
    AnyClassOp *pac;
    GC xorGc;
    XEvent event;

    pac = (AnyClassOp *) pxw->pe;
    xorGc = createXorColorGc(pxw->dpy, pxw->win, 1);
    imX = 0;
    mX = pac->xsz;
    imY = y;
    mY = imY;
    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);

    while (True != XCheckMaskEvent(pxw->dpy, ButtonReleaseMask, &event)) {
	if (True == XCheckMaskEvent(pxw->dpy, PointerMotionMask, &event)) {
	    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
	    mY = event.xmotion.y;
	    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
	}
    }
    dpySelectRect(pxw->dpy, pxw->win, xorGc, imX, imY, mX, mY);
    /* Call the "mathematic" zoom function */
    (*(pxw->fzoo)) (pxw->pe, min(imX, mX), min(imY, mY), max(imX, mX), max(imY, mY));
}
