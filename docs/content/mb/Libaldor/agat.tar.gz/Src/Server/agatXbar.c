#include "agat.h"


#define ThinBarScreenToRealY(pp,y) (((-(y)+(pp)->ysz)/(pp)->scaley)+(pp)->miny)
#define ThinBarScreenToRealX(pp,x) ((pp)->totBar-((pp)->curx)+((x)))	/* ?? */

/**************************************************************** Prototypes */

static void rescale(double v1, double v2, double *limv, double mulv);
static void thinBarResize(ThinBar * ptb, int x, int y);
static void thinBarCoord(ThinBar * pp, int x, int y, int rx, int ry, Window win, int First);
static void thinBarZoom(ThinBar * pp, int x1, int y1, int x2, int y2);
static void thinBarPS(ThinBar * pp, int x, int y);
static void drawBar(ThinBar * ptb, Drawable d, int n, int ex, int ey, int eszy);
static void drawBarPoint(ThinBar * ptb, Drawable d, int n, int ex, int ey, int eszy);

/*
 * thinbar ...
 */
static ThinBar *initThinBarAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, char *name);
static void plotBAxe(ThinBar * ptb);
static void thinBarRefresh(ThinBar * ptb);

/*
 * ratthinbar ...
 */
static void drawRatBar(ThinBar * ptb, Drawable d, int n, int x1, int y1, int x2, int y2);
static void ratThinBarCoord(ThinBar * pp, int x, int y, int rx, int ry);
static void ratThinBarZoom(ThinBar * pp, int x, int y, int rx, int ry);
static void ratThinBarRefresh(ThinBar * ptb);

/******************************************************************** Bodies */




double
ThinBarRealToScreenY(ThinBar * pp, double y)
{
    if (!pp->ps)
	return ((pp)->ysz - ((y) - (pp)->miny) * (pp)->scaley);
    else
	return (((y) - (pp)->miny) * (pp)->scaley);
}

double
ThinBarRealToScreenHY(ThinBar * ptb, double d)
{
    if (!ptb->ps)
	return d * ptb->scaley;
    else
	return -(d * ptb->scaley);
}


static void
rescale(double v1, double v2, double *limv, double mulv)
{

    *limv = v1 + (v1 - v2) * mulv;
}


static void
thinBarResize(ThinBar * ptb, int x, int y)
{
    UTrace(UTRACE_AXBAR,("thinBarResize\n"));
    if (x <= 0)
	x = 1;
    if (y <= 0)
	y = 1;
    ptb->xsz = x;
    ptb->ysz = y;
    XFreePixmap(ptb->dpy, ptb->pixmap);
    ptb->pixmap = XCreatePixmap(ptb->dpy, ptb->win, x, y, DefaultDepth(ptb->dpy, DefaultScreen(ptb->dpy)));
}


static void
thinBarCoord(ThinBar * pp, int x, int y, int rx, int ry, Window win, int First)
{
#define MARG_H 5
#define MARG_W 10
#define MARG_PT_X 10
#define MARG_PT_Y 10

    char tmp[100];
    static int size = 0;
    XEvent event_return;

    sprintf(tmp, " Num : %d H : %f", ThinBarScreenToRealX(pp, x), ThinBarScreenToRealY(pp, y));
    XSynchronize(pp->dpy, True);
    XMoveWindow(pp->dpy, win, rx + MARG_PT_X, ry + MARG_PT_Y);
    if (size != strlen(tmp) || First) {
	XResizeWindow(pp->dpy, win, MARG_W + strlen(tmp) * pp->fontWidth,
		      pp->fontHeight + MARG_H * 2);
	XWindowEvent(pp->dpy, win, ExposureMask, &event_return);
    }
    size = strlen(tmp);
    XClearWindow(pp->dpy, win);
    agatDrawString((AnyClassOp *) pp, win, pp->textGc, MARG_W, MARG_H + pp->fontHeight, tmp, strlen(tmp));
    XFlush(pp->dpy);
    XSynchronize(pp->dpy, False);
}


static void
thinBarZoom(ThinBar * pp, int x1, int y1, int x2, int y2)
{
    ThinBar *newpp;
    RDataBase initRDB;

    newpp = (ThinBar *) UZalloc(sizeof(ThinBar));
    *newpp = *pp;
    newpp->type = ZOOM_WINDOW;
    newpp->name = (char *) UZalloc(sizeof(char) * (strlen("zoom") + 1));
    strcpy(newpp->name, "zoom");
    newpp->maxy = ThinBarScreenToRealY(pp, y1);
    newpp->miny = ThinBarScreenToRealY(pp, y2);
    extractDB(0, NULL, pp->dpy, "zoom", &initRDB);
    newpp->xsz = initRDB.xsz;
    newpp->ysz = initRDB.ysz;

    createFirstWindow(&newpp->dpy, &newpp->win, &newpp->pixmap, newpp->xsz, newpp->ysz, &initRDB);
    addXwin(newpp->dpy, newpp->win, ZOOM_WINDOW, newpp->refresh, newpp->resize,
	  newpp->coord, newpp->szoom, newpp->zoom, NULL, newpp->pps, newpp);
    XStoreName(newpp->dpy, newpp->win, "zoom");
    fprintf(stderr, "ThinBarZoom not implemented\n");
    mapWindow(newpp->dpy, newpp->win, &initRDB);
}


static void
thinBarPS(ThinBar * pp, int x, int y)
{
    RDataBase initRDB;
    int tabCol[NB_MAX_COLOR + 3];
    char *buffer = NULL, *file[255];
    int i;

    extractDB(0, NULL, pp->dpy, buffer, &initRDB);	/* ?? */
    pp->ps = True;
    XFetchName(pp->dpy, pp->win, file);
    if (*file != NULL) {
	pp->fps = fopen(*file, "w");
	if (pp->fps != NULL) {
	    headPs(pp->fps, (AnyClassOp *) pp);

	    pp->tabRGB = (RGB *) UZalloc(sizeof(RGB) * (NB_MAX_COLOR + 3));	/* +Back,Text,Mark */
	    tabCol[0] = initRDB.fg;
	    tabCol[1] = initRDB.bg;
	    tabCol[2] = initRDB.markcolor;
	    for (i = 3; i < (NB_MAX_COLOR + 3); i++)
		tabCol[i] = initRDB.tabColor[i - 3];

	    x2psColors((AnyClassOp *) pp, tabCol, pp->tabRGB, (NB_MAX_COLOR + 3));

	    (*(pp->refresh)) (pp);
	    tailPs(pp->fps);
	    fclose(pp->fps);
	}
	else
	    fprintf(stderr, "Can't open file !\n");
    }
    pp->ps = False;
}


static void
drawBar(ThinBar * ptb, Drawable d, int n, int ex, int ey, int eszy)
{
    agatDrawLine((AnyClassOp *) ptb, d, ptb->drawGcs[n], ex, ey, ex, ey - eszy);
}


static void 
drawBarPoint(ThinBar * ptb, Drawable d, int n, int ex, int ey, int eszy)
{
    agatDrawPoint((AnyClassOp *) ptb, d, ptb->drawGcs[n], ex, ey - eszy);
}




/*
 * thinbar ...
 */

static ThinBar *
initThinBarAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, char *name) {
    ThinBar *ptb;
    InitPar *pip;
    Display *dpy;
    char *buffer = NULL;
    RDataBase initRDB;

    UTrace(UTRACE_AXBAR,("initThinBarAux\n"));
    dpy = openDisplayOnlyOne();
    ptb = (ThinBar *) UZalloc(sizeof(ThinBar));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    ptb->type = THINBAR_WINDOW;
    ptb->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(ptb->name, name);
    ptb->iconified = False;		/* ?? */
    ptb->killed = False;
    ptb->ps = False;
    ptb->xsz = initRDB.xsz;
    ptb->ysz = initRDB.ysz;
    createFirstWindow(&ptb->dpy, &ptb->win, &ptb->pixmap, ptb->xsz, ptb->ysz, &initRDB);

    addXwin(ptb->dpy, ptb->win, ptb->type, ref, res, coord, szoom, zoom, NULL, pps, ptb);
    appNameClass(ptb->dpy, ptb->win);
    XStoreName(ptb->dpy, ptb->win, buffer);
    ptb->drawGcs = createGcs(ptb->dpy, ptb->win, initRDB.tabColor, MAX_VAR_ARITY);
    ptb->textGc = createTextGc(ptb->dpy, ptb->win, initRDB.font, initRDB.fg,
			       &ptb->fontWidth, &ptb->fontHeight);
    ptb->font = (char *) UZalloc(sizeof(char) * (strlen(initRDB.font) + 1));
    strcpy(ptb->font, initRDB.font);
    ptb->backGc = createBackGc(ptb->dpy, ptb->win, initRDB.bg);
    ptb->qv = qCreate(nullFunc);
    ptb->maxy = MINDOUBLE * 1000.0;
    ptb->miny = -ptb->maxy;
    ptb->scaley = 1.0;
    ptb->curx = 0;
    ptb->totBar = 0;
    ptb->doAxe = doAxe;
    ptb->draw = draw;
    ptb->resize = res;
    ptb->refresh = ref;
    ptb->coord = coord;
    ptb->szoom = szoom;
    ptb->zoom = zoom;
    ptb->pps = pps;
    mapWindow(ptb->dpy, ptb->win, &initRDB);
    return ptb;
}


void *
initThinbar(HashTable * pht)
{
    return initThinBarAux(pht, thinBarRefresh, thinBarResize, drawBar, thinBarCoord, selectStrip, thinBarZoom, thinBarPS, False, "thinbar");
}


void *
initThinbarAxe(HashTable * pht)
{
    return initThinBarAux(pht, thinBarRefresh, thinBarResize, drawBar, thinBarCoord, selectStrip, thinBarZoom, thinBarPS, True, "thinbar");
}


void *
initPlotbar(HashTable * pht)
{
    return initThinBarAux(pht, thinBarRefresh, thinBarResize, drawBarPoint, thinBarCoord, selectStrip, thinBarZoom, thinBarPS, False, "plotbar");
}

void *
initPlotbarAxe(HashTable * pht)
{
    return initThinBarAux(pht, thinBarRefresh, thinBarResize, drawBarPoint, thinBarCoord, selectStrip, thinBarZoom, thinBarPS, False, "plotbar");
}

static void
plotBAxe(ThinBar * ptb)
{
    int nbTicks, nbcar, i, nbLabCar;
    double *aTicks, min, max;
    int y;
    char **aLabs;

    min = ptb->miny;
    max = ptb->maxy;
    if (min == max)
	return;
    nbTicks = buildYTicksLabs(ptb->xsz, ptb->ysz, ptb->fontHeight,
			      ptb->fontWidth, ptb->miny, ptb->maxy,
			      YTICKS_NB_CARMIN, YTICKS_VRATIO, YTICKS_HRATIO,
			      &nbLabCar, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	y = ThinBarRealToScreenY(ptb, aTicks[i]);
	agatDrawLine((AnyClassOp *) ptb, ptb->pixmap, ptb->textGc, 0, y, 10, y);
	if (y < 10)
	    agatDrawString((AnyClassOp *) ptb, ptb->pixmap, ptb->textGc, 10, y + 10, aLabs[i], strlen(aLabs[i]));
	else
	    agatDrawString((AnyClassOp *) ptb, ptb->pixmap, ptb->textGc, 10, y, aLabs[i], strlen(aLabs[i]));
    }
    free(aLabs);
    free(aTicks);
}

static void
thinBarRefresh(ThinBar * ptb)
{
    int i, szy, starty;
    double maxy, miny;
    Value *pv;

    UTrace(UTRACE_AXBAR,("thinBarRefresh\n"));
    if (!ptb->ps)
	XFillRectangle(ptb->dpy, ptb->pixmap, ptb->backGc, 0, 0, ptb->xsz, ptb->ysz);
    ptb->curx = 0;
    if (ptb->type != ZOOM_WINDOW) {
	maxy = MINDOUBLE * 1000;
	miny = -(MINDOUBLE * 1000);
	for (i = 0; i < qNbElts(ptb->qv); i++) {
	    pv = (Value *) qLookNth(ptb->qv, i);
	    if (maxy < pv->v.d)
		maxy = pv->v.d;
	    if (miny > pv->v.d)
		miny = pv->v.d;
	}
	rescale(maxy, miny, &ptb->maxy, XBAR_MULT_VSZ);
	rescale(miny, maxy, &ptb->miny, XBAR_MULT_VSZ);
    }

    ptb->scaley = ptb->ysz / (ptb->maxy - ptb->miny);
    for (i = 0; i < qNbElts(ptb->qv); i++) {
	pv = (Value *) qLookNth(ptb->qv, i);
	szy = ThinBarRealToScreenHY(ptb, pv->v.d);
	starty = ThinBarRealToScreenY(ptb, 0);
	if (!ptb->iconified)
	    ptb->draw(ptb, ptb->pixmap, pv->t, ptb->curx, starty, szy);
	ptb->curx++;
    }
    if ((ptb->doAxe) && (!ptb->iconified))
	plotBAxe(ptb);
    if (!ptb->ps)
	XCopyArea(ptb->dpy, ptb->pixmap, ptb->win, ptb->backGc, 0, 0, ptb->xsz, ptb->ysz, 0, 0);
    if (!ptb->iconified)
	XFlush(ptb->dpy);
}


void
thinbar(ThinBar * ptb, int arity, Value ** av)
{
    int i, szy, starty;
    double v;

    UTrace(UTRACE_AXBAR,("thinbar\n"));
    for (i = 0; i < arity; i++) {
	if (av[i] != NULL) {
	    v = valToDouble(av[i]);
	    qAdd(ptb->qv, convertVal(av[i], i, v));
	    if ((v > ptb->maxy) || (v < ptb->miny)) {
		thinBarRefresh(ptb);
	    }
	    else {
		szy = ThinBarRealToScreenHY(ptb, v);
		starty = ThinBarRealToScreenY(ptb, 0);
		if (!ptb->iconified)
		    ptb->draw(ptb, ptb->win, i, ptb->curx, starty, szy);
		ptb->curx++;
	    }
	    if (ptb->curx >= ptb->xsz) {
		qDel(ptb->qv, (int) (ptb->curx * XBAR_MULT_SCROLL), unAllocValue);
		thinBarRefresh(ptb);
	    }
	}
    }
    ptb->totBar++;
    if (!ptb->iconified)
	XFlush(ptb->dpy);
}



/*
 * ratthinbar ...
 */

static void
drawRatBar(ThinBar * ptb, Drawable d, int n, int x1, int y1, int x2, int y2)
{
    agatDrawLine((AnyClassOp *) ptb, d, ptb->drawGcs[n], x1, y1, x2, y2);
}


static void
ratThinBarCoord(ThinBar * pp, int x, int y, int rx, int ry)
{
    fprintf(stderr, "ratThinBarCoord not implemented\n");
}


static void
ratThinBarZoom(ThinBar * pp, int x, int y, int rx, int ry)
{
    fprintf(stderr, "ratThinBarZoom not implemented\n");
}


void *initRatThinBarAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), char *name) {
    ThinBar *ptb;
    InitPar *pip;
    Display *dpy;
    char *buffer;
    RDataBase initRDB;

    dpy = openDisplayOnlyOne();
    ptb = (ThinBar *) UZalloc(sizeof(ThinBar));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    ptb->type = RATTHINBAR_WINDOW;
    ptb->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(ptb->name, buffer);
    ptb->iconified = False;		/* ?? */
    ptb->killed = False;
    ptb->ps = False;
    ptb->xsz = initRDB.xsz;
    ptb->ysz = initRDB.ysz;
    createFirstWindow(&ptb->dpy, &ptb->win, &ptb->pixmap, ptb->xsz, ptb->ysz, &initRDB);

    addXwin(ptb->dpy, ptb->win, ptb->type, ref, res, coord, szoom, zoom, NULL, pps, ptb);
    appNameClass(ptb->dpy, ptb->win);
    XStoreName(ptb->dpy, ptb->win, buffer);
    ptb->drawGcs = createGcs(ptb->dpy, ptb->win, initRDB.tabColor, MAX_VAR_ARITY);
    ptb->backGc = createBackGc(ptb->dpy, ptb->win, initRDB.bg);
    pip = (InitPar *) htSearchKey(pht, "arity");
    ptb->arity = *((int *) pip->pe);
    ptb->curx = 0;
    ptb->qv = qCreate(nullFunc);
    ptb->maxy = 0.0;
    ptb->scaley = 0.0;
    ptb->draw = draw;
    ptb->resize = res;
    ptb->refresh = ref;
    ptb->coord = coord;
    ptb->szoom = szoom;
    ptb->zoom = zoom;
    ptb->pps = pps;
    mapWindow(ptb->dpy, ptb->win, &initRDB);
    return ptb;
}


void *
initRatThinbar(HashTable * pht)
{
    return initRatThinBarAux(pht, ratThinBarRefresh, thinBarResize, drawRatBar, ratThinBarCoord, selectStrip, ratThinBarZoom, thinBarPS, "ratthinbar");
}


static void
ratThinBarRefresh(ThinBar * ptb)
{
    int i, j, starty, endy;
    Value *pv;
    double sumv, scalev;
    double cury;

    if (!ptb->ps)
	XFillRectangle(ptb->dpy, ptb->pixmap, ptb->backGc, 0, 0, ptb->xsz, ptb->ysz);
    ptb->curx = 0;
    for (i = 0; i < (qNbElts(ptb->qv) / ptb->arity); i++) {
	sumv = 0;
	for (j = 0; j < ptb->arity; j++) {
	    pv = (Value *) qLookNth(ptb->qv, i * ptb->arity + j);
	    sumv += pv->v.d;
	}
	scalev = ((double) ptb->ysz) / sumv;
	cury = 0.0;
	for (j = 0; j < ptb->arity; j++) {
	    pv = (Value *) qLookNth(ptb->qv, i * ptb->arity + j);
	    if (pv->v.d != 0.0) {
		starty = ptb->ysz - ceil(cury * scalev);	/* !!! */
		cury += pv->v.d;
		endy = ptb->ysz - ceil(cury * scalev);
		if (!ptb->iconified)
		    ptb->draw(ptb, ptb->win, ptb->drawGcs[i],
			      ptb->curx, starty, ptb->curx, endy);
	    }
	}
	ptb->curx++;
    }
    if (!ptb->ps)
	XCopyArea(ptb->dpy, ptb->pixmap, ptb->win, ptb->backGc, 0, 0, ptb->xsz, ptb->ysz, 0, 0);
    if (!ptb->iconified)
	XFlush(ptb->dpy);
}


void
ratThinbar(ThinBar * ptb, int arity, Value ** av)
{
    double v, sumv, scalev, cury;
    int i, starty, endy;

    if (ptb->curx > ptb->xsz) {
	qDel(ptb->qv, (int) (ptb->xsz * XBAR_MULT_SCROLL) * (ptb->arity), unAllocValue);
	ratThinBarRefresh(ptb);
    }
    sumv = 0;
    for (i = 0; i < ptb->arity; i++) {
	v = fabs(valToDouble(av[i]));
	qAdd(ptb->qv, convertVal(av[i], i, v));
	sumv += v;
    }
    scalev = ((double) ptb->ysz) / sumv;

    cury = 0.0;
    for (i = 0; i < ptb->arity; i++) {
	if (av[i]->v.d != 0.0) {
	    starty = ptb->ysz - ceil(cury * scalev);	/* !!! */
	    cury += av[i]->v.d;
	    endy = ptb->ysz - ceil(cury * scalev);
	    if (!ptb->iconified)
		ptb->draw(ptb, ptb->win, ptb->drawGcs[i],
			  ptb->curx, starty, ptb->curx, endy);
	}
    }
    ptb->curx++;
    if (!ptb->iconified)
	XFlush(ptb->dpy);
}









