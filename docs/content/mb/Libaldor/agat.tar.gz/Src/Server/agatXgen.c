#include "agat.h"


HashTable *htXwin;
static int rw, rh;			/* root Window width and height */


/**************************************************************** Prototypes */


/******************************************************************** Bodies */


Display *
openDisplayOnlyOne()
{
    static Display *dpy = NULL;
    XWindowAttributes xwa;
    static XtAppContext app;
    int test = 0;

/*    extern int          globalArgc; Don't use 'cause of display -d */
    extern char **globalArgv;

    if (dpy == NULL) {
	app = XtCreateApplicationContext();
	if ((dpy = XtOpenDisplay(app, NULL, "agat", "Agat", NULL, 0, &test, globalArgv)) == NULL) {
	    UIError("agat server", "%s %s", "Can't open display:", XDisplayName(NULL));
	}
	XGetWindowAttributes(dpy, DefaultRootWindow(dpy), &xwa);
	rw = xwa.width;
	rh = xwa.height;
    }
    return dpy;
}


void
appNameClass(Display * dpy, Window win)
{
    XClassHint *classHint;

    classHint = XAllocClassHint();
    if (classHint == NULL) {
	fprintf(stderr, "Agat: Insufficient memory !\n");
	exit(1);
    }
    classHint->res_name = "agat";
    classHint->res_class = "Agat";
    XSetClassHint(dpy, win, classHint);
    free(classHint);
}


void
moveWindow(Display * dpy, Window win, RDataBase * RDB)
{
    static int cx = 0, cy = 0, nb = 1;

    if ((cx == 0) && (cy == 0)) {
	cx = RDB->origx;
	cy = RDB->origy;
    }

    if (cx + RDB->xsz > rw) {
	cx = RDB->origx;
	cy += RDB->ysz + RDB->pdy;
	if (cy + RDB->ysz > rh) {
	    cx += nb * RDB->pdx;
	    cy = RDB->origy + nb * RDB->pdy;
	    nb++;
	}
    }
    XMoveWindow(dpy, win, cx, cy);
    cx += RDB->xsz + RDB->pdx;
}

void
createFirstWindow(Display ** pdpy, Window * pwin, Pixmap * ppixmap, int xsz, int ysz, RDataBase * RDB)
{

    *pdpy = openDisplayOnlyOne();

    *pwin = XCreateSimpleWindow(*pdpy, DefaultRootWindow(*pdpy),
				100, 100, xsz, ysz,
				1,
				BlackPixel(*pdpy, DefaultScreen(*pdpy)),
				WhitePixel(*pdpy, DefaultScreen(*pdpy)));
    *ppixmap = XCreatePixmap(*pdpy, *pwin, xsz, ysz, DefaultDepth(*pdpy, DefaultScreen(*pdpy)));
    XSelectInput(*pdpy, *pwin, ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask | PointerMotionMask);
}

void
mapWindow(Display * dpy, Window win, RDataBase * RDB)
{
    XSynchronize(dpy, True);
    XMapWindow(dpy, win);
    if (RDB->organized == True)
	moveWindow(dpy, win, RDB);
    XFlush(dpy);
    XSynchronize(dpy, False);
}


int
findColor(Display * dpy, char *name, int col_dflt)
{
    XColor screen_def;
    Visual *v;
    int sn;
    Colormap co;

    sn = DefaultScreen(dpy);
    v = DefaultVisual(dpy, sn);
    co = DefaultColormap(dpy, sn);

    if (XParseColor(dpy, co, name, &screen_def) == 0) {
	fprintf(stderr, "Agat: bg color specification %s invalid\n", name);
	return col_dflt;
    }
    else {
	if ((v->class == StaticGray) || (v->class == GrayScale))
	    return col_dflt;
	else if (XAllocColor(dpy, co, &screen_def) == 0) {
	    return col_dflt;
	    fprintf(stderr, "Agat: couldn't allocate color: %s.\n", name);
	}
	else
	    return screen_def.pixel;
    }
}


GC *
createGcs(Display * dpy, Window d, int tabCo[], int nbgc)
{
    GC *agc;
    XGCValues gcv;
    XColor scdefcol, exactcol;
    Colormap defcm;
    int i;

    agc = (GC *) UZalloc(nbgc * sizeof(GC));
    defcm = DefaultColormap(dpy, DefaultScreen(dpy));
    for (i = 0; (i < nbgc) && (i < NB_MAX_COLOR); i++) {
	gcv.foreground = tabCo[i];
	agc[i] = XCreateGC(dpy, d, GCForeground, &gcv);
    }
    return agc;
}


GC
createBackGc(Display * dpy, Window d, int bg)
{
    XGCValues gcv;

    gcv.foreground = bg;
    gcv.graphics_exposures = False;
    return XCreateGC(dpy, d, GCForeground | GCGraphicsExposures, &gcv);
}


GC
createTextGc(Display * dpy, Window d, char *font, int fg, int *w, int *h)
{
    XFontStruct *fontstruct = NULL;	/* Font descriptor */
    XGCValues gcv;
    int bidon;
    XCharStruct xcs;

    if ((fontstruct = XLoadQueryFont(dpy, font)) == NULL) {
	fprintf(stderr, "Agat: display %s doesn't know font %s\n",
		DisplayString(dpy), font);
	UExit(1);
    }

    gcv.foreground = fg;
    gcv.font = fontstruct->fid;

    XTextExtents(fontstruct, "0", 1, &bidon, &bidon, &bidon, &xcs);
    *w = xcs.width;
    *h = xcs.ascent + xcs.descent;

    return XCreateGC(dpy, d, GCForeground | GCFont, &gcv);
}


GC
createColorGc(Display * dpy, Window d, char *colName)
{
    XGCValues gcv;
    XColor scdefcol, exactcol;
    Colormap defcm;

    defcm = DefaultColormap(dpy, DefaultScreen(dpy));
    XAllocNamedColor(dpy,
		     defcm,
		     colName,
		     &scdefcol, &exactcol);
    gcv.foreground = scdefcol.pixel;
    return XCreateGC(dpy, d, GCForeground, &gcv);
}


GC
createXorColorGc(Display * dpy, Window d, int mc)
{
    XGCValues gcv;

    gcv.foreground = mc;
    gcv.function = GXxor;

    return XCreateGC(dpy, d, GCFunction | GCForeground, &gcv);
}


char *
giveStreamTitle(char **an, char *opName)
{
    char *n;
    char **pn;
    int nbc = 0;

    pn = an;
    while (*pn != NULL) {
	nbc += strlen(*pn) + 1;
	pn++;
    }
    n = (char *) UZalloc((nbc + strlen(opName) + 2) * sizeof(char));
    strcpy(n, opName);
    strcat(n, ".");
    nbc = strlen(opName) + 1;
    pn = an;
    while (*pn != NULL) {
	strcpy(n + nbc, *pn);
	nbc += strlen(*pn);
	*(n + nbc) = ',';
	nbc++;
	pn++;
    }
    n[nbc - 1] = '\000';
    return n;
}


void
addXwin(Display * dpy, Window win, int type, GenericFunc fref, GenericFunc fres, GenericFunc fcoord, GenericFunc fzos, GenericFunc fzoom, GenericFunc fm3d, GenericFunc fpps, void *pe)
{
    Xwin *pxw;

    pxw = (Xwin *) UZalloc(sizeof(Xwin));
    pxw->dpy = dpy;
    pxw->win = win;
    pxw->type = type;
    pxw->fref = fref;
    pxw->fres = fres;
    pxw->fcoo = fcoord;
    pxw->fzos = fzos;
    pxw->fzoo = fzoom;
    pxw->fm3d = fm3d;
    pxw->fpps = fpps;
    pxw->pe = pe;
    htInsert(htXwin, pxw, False);
}


void
coordDisplay(Display * dpy, XEvent event)
{
    XEvent evt;
    XExposeEvent expevent;
    Xwin *pxw;
    int mouseX, mouseY, rootX, rootY;
    AnyClassOp *tmp;

    pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
    if (pxw != NULL) {
	/* Force to save the pixmap */
	(*(pxw->fref)) (pxw->pe);

	mouseX = event.xbutton.x;
	mouseY = event.xbutton.y;
	rootX = event.xbutton.x_root;
	rootY = event.xbutton.y_root;
	/* Create the coordonate window */
	pxw->winc = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 1, 1, 10, 10, 1,
					BlackPixel(dpy, DefaultScreen(dpy)),
					WhitePixel(dpy, DefaultScreen(dpy)));
	XSelectInput(dpy, pxw->winc, ExposureMask);
	XStoreName(dpy, pxw->winc, "Coordonates");
	XMapWindow(dpy, pxw->winc);

	(*(pxw->fcoo)) (pxw->pe, mouseX, mouseY, rootX, rootY, pxw->winc, True);

	while (True != XCheckMaskEvent(dpy, ButtonReleaseMask, &event)) {
	    if (True == XCheckMaskEvent(dpy, PointerMotionMask, &event)) {
		mouseX = event.xmotion.x;
		mouseY = event.xmotion.y;
		rootX = event.xmotion.x_root;
		rootY = event.xmotion.y_root;
		(*(pxw->fcoo)) (pxw->pe, mouseX, mouseY, rootX, rootY, pxw->winc, False);
	    }
	    while (True == XCheckWindowEvent(dpy, pxw->win, ExposureMask,
					     (XEvent *) & expevent)
		   && (expevent.type == Expose)) {
		tmp = pxw->pe;
		XCopyArea(dpy, tmp->pixmap, pxw->win, tmp->drawGcs[0], expevent.x,
			  expevent.y, expevent.width, expevent.height,
			  expevent.x, expevent.y);
	    }
	}

	/* destroy the coordonate window and refresh */
	XDestroyWindow(dpy, pxw->winc);
	XFlush(dpy);
	(*(pxw->fref)) (pxw->pe);
    }
}


void
zoomFunction(Display * dpy, XEvent event)
{
    XEvent evt;
    XExposeEvent expevent;
    Xwin *pxw;
    int imX, imY, mX, mY;
    GC xorGc;
    char *winName;

    pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
    if (pxw != NULL) {
	/* Force to save the pixmap */
	(*(pxw->fref)) (pxw->pe);
	/* Call the function of the zoom selection */
	(*(pxw->fzos)) (pxw, event.xbutton.x, event.xbutton.y);
    }
}


void
moveIn3DView(Display * dpy, XEvent event)
{
    Xwin *pxw;

    pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
    if (pxw != NULL)
	if ((*(pxw->fm3d)) != NULL)
	    (*(pxw->fm3d)) (pxw->pe);
}


void
checkXConfigureEvents(dpy, event)
    Display *dpy;
    XEvent event;
{
    Xwin *pxw;
    int width, height, borderw;
    AnyClassOp *classOp;

    switch (event.type) {
    case ConfigureNotify:
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    borderw = event.xconfigure.border_width;
	    width = event.xconfigure.width - borderw;
	    height = event.xconfigure.height - borderw;
	    /* because rescan to determinate min and max */
	    if (pxw->type != ZOOM_WINDOW)
		(*(pxw->fres)) (pxw->pe, width, height);
	    (*(pxw->fref)) (pxw->pe);
	}
	break;
    case UnmapNotify:
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    if (classOp->killed == True)
		htDel(htXwin, pxw, True);
	    else
		classOp->iconified = True;
	    /* ?? Creer un icon */
	}
	break;
    case MapNotify:
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    classOp->iconified = False;
	}
	break;
    }
}


void
checkXExposeEvents(dpy, event)
    Display *dpy;
    XEvent event;
{
    Xwin *pxw;
    XEvent bidon;

    if (event.type != Expose)
	return;
    if (event.xexpose.count != 0)
	return;
    pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
    if (pxw != NULL) {
	(*(pxw->fref)) (pxw->pe);
	/* Remove the others expose from the X queue */
	while (True == XCheckWindowEvent(dpy, pxw->win, ExposureMask, &bidon));
    }
}


void
checkXKeyEvents(dpy, event)
    Display *dpy;
    XEvent event;
{
    char tmp[31];
    Xwin *pxw;
    AnyClassOp *classOp;
    XEvent myEvent;
    RDataBase rDB;

    if (event.type != KeyPress)
	return;
    bzero(tmp, 10);
    XLookupString((XKeyEvent *) & event, tmp, 30,
		  NULL, NULL);
    if (((tmp[0] == 'b') || (tmp[0] == 'B')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    extractDB(0, NULL, pxw->dpy, classOp->name, &rDB);
	    XResizeWindow(pxw->dpy, pxw->win, rDB.bigx, rDB.bigy);
	}
    }
    if (((tmp[0] == 'k') || (tmp[0] == 'K')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    if (classOp->type == ZOOM_WINDOW) {
		classOp->killed = True;
		XDestroyWindow(pxw->dpy, pxw->win);
	    }
	}
    }
    if (((tmp[0] == 'n') || (tmp[0] == 'N')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    extractDB(0, NULL, pxw->dpy, classOp->name, &rDB);
	    XResizeWindow(pxw->dpy, pxw->win, rDB.xsz, rDB.ysz);
	}
    }
    if (((tmp[0] == 'p') || (tmp[0] == 'P')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL)
	    (*(pxw->fpps)) (pxw->pe, 0, 0);
    }
    if (((tmp[0] == 'q') || (tmp[0] == 'Q')) && (tmp[1] == '\0')) {
	fprintf(stderr, "exited by user!\n");
	exit(0);
    }
    if (((tmp[0] == 'r') || (tmp[0] == 'R')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL)
	    (*(pxw->fref)) (pxw->pe);
    }
    if (((tmp[0] == 's') || (tmp[0] == 'S')) && (tmp[1] == '\0')) {
	while (1) {
	    XPeekEvent(dpy, &myEvent);
	    if (myEvent.type != KeyPress) {
		checkXMouseEvents(dpy, myEvent);
		checkXConfigureEvents(dpy, myEvent);
		checkXExposeEvents(dpy, myEvent);
		XNextEvent(dpy, &myEvent);
	    }
	    else
		break;
	}
    }
    if (((tmp[0] == 't') || (tmp[0] == 'T')) && (tmp[1] == '\0')) {
	pxw = (Xwin *) htSearchKey(htXwin, &(event.xany.window));
	if (pxw != NULL) {
	    classOp = pxw->pe;
	    extractDB(0, NULL, pxw->dpy, classOp->name, &rDB);
	    XResizeWindow(pxw->dpy, pxw->win, rDB.tinyx, rDB.tinyy);
	}
    }
}


void
checkXMouseEvents(Display * dpy, XEvent event)
{
    if (event.type != ButtonPress)
	return;
    switch (event.xbutton.button) {
    case Button1:			/* Display coordonates */
	coordDisplay(dpy, event);
	break;
    case Button2:			/* Nothing */
	moveIn3DView(dpy, event);
	break;
    case Button3:			/* Zoom */
	zoomFunction(dpy, event);
	break;
    }
}


void
checkXEvents(void)
{
    Display *dpy;
    XEvent event;
    int n, i;

    if (htNbElts(htXwin) == 0)
	return;				/* no X window display activated now */
    dpy = ((Xwin *) htLookNth(htXwin, 0))->dpy;

    while (n = XPending(dpy)) {
	XNextEvent(dpy, &event);
	checkXMouseEvents(dpy, event);
	checkXConfigureEvents(dpy, event);
	checkXExposeEvents(dpy, event);
	checkXKeyEvents(dpy, event);
    }
}
