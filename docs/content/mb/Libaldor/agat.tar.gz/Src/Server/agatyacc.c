#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";

#endif
#define YYBYACC 1
#line 2 "agatyacc.y"
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "agatparse.h"
#include "agatcheck.h"

#line 14 "agatyacc.y"
typedef union {
    FADef *pDef;
    FAConstruct *pConstruct;
    FAReg *pReg;
    FAName *pNames;
    FAClause *pClause;
    FAPattern *pPattern;
    Byte State;
    FAAction *pAction;
    FAExpNode *pExpNod;
    char *pStr;
    Value *pVal;
}     YYSTYPE;

#line 30 "y.tab.c"
#define PAR_OP 257
#define PAR_CL 258
#define BRA_OP 259
#define BRA_CL 260
#define SBR_OP 261
#define SBR_CL 262
#define COMMA 263
#define SEMCO 264
#define ARROW 265
#define ASSIGN 266
#define AFFECT 267
#define PIPE 268
#define SHARP 269
#define CIRCU 270
#define STAR 271
#define UNDER 272
#define MINUS 273
#define PLUS 274
#define DIV 275
#define MAP 276
#define LET 277
#define IF 278
#define THEN 279
#define ELSE 280
#define ENDIF 281
#define NULL_ACTION 282
#define INCLUDE 283
#define GT 284
#define LT 285
#define GTOEQ 286
#define LTOEQ 287
#define EQUAL 288
#define NEQUA 289
#define IDENT 290
#define STRING 291
#define NUMBER 292
#define TOK_TRUE 293
#define TOK_FALSE 294
#define YYERRCODE 256
short yylhs[] = {-1,
    0, 0, 28, 28, 30, 31, 31, 32, 29, 29,
    29, 29, 29, 29, 29, 1, 1, 2, 2, 3,
    3, 4, 5, 6, 6, 7, 8, 8, 9, 9,
    10, 10, 11, 12, 12, 13, 14, 14, 15, 15,
    15, 15, 16, 16, 16, 16, 16, 17, 17, 18,
    18, 18, 18, 20, 20, 19, 21, 21, 21, 21,
    21, 21, 21, 22, 22, 22, 23, 23, 23, 26,
    26, 26, 25, 25, 25, 25, 25, 25, 24, 24,
    27, 27,
};
short yylen[] = {2,
    1, 0, 2, 1, 2, 3, 1, 1, 2, 2,
    2, 2, 2, 2, 1, 4, 3, 7, 6, 4,
    3, 4, 1, 6, 5, 3, 3, 1, 1, 3,
    3, 1, 1, 3, 1, 3, 3, 1, 2, 2,
    1, 1, 1, 1, 1, 1, 1, 3, 1, 1,
    1, 1, 1, 5, 7, 3, 1, 3, 3, 3,
    3, 3, 3, 1, 3, 3, 1, 3, 3, 1,
    2, 2, 1, 1, 1, 1, 1, 3, 3, 4,
    3, 1,
};
short yydefred[] = {0,
    0, 15, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 14, 0, 8, 5, 0, 0, 0,
    9, 10, 11, 12, 3, 13, 0, 0, 0, 33,
    0, 0, 0, 0, 0, 0, 0, 73, 75, 76,
    21, 23, 17, 0, 0, 77, 70, 67, 0, 20,
    16, 6, 0, 0, 0, 72, 71, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 31, 78, 43, 44, 46, 45, 47,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    79, 82, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 68, 69, 0, 19, 39, 0, 0, 0, 0,
    40, 0, 26, 0, 0, 80, 0, 18, 25, 34,
    0, 53, 0, 36, 0, 52, 51, 50, 37, 30,
    27, 0, 81, 0, 0, 0, 24, 0, 56, 48,
    0, 0, 54, 0, 55,
};
short yydgoto[] = {6,
    7, 8, 9, 10, 41, 42, 60, 88, 89, 31,
    32, 82, 83, 84, 85, 86, 124, 125, 126, 127,
    128, 44, 45, 46, 47, 48, 93, 11, 12, 13,
    17, 18,
};
short yysindex[] = {-201,
    -258, 0, -278, -274, -250, 0, -232, -204, -196, -162,
    0, -201, -160, 0, -246, 0, 0, -220, -206, -243,
    0, 0, 0, 0, 0, 0, -206, -243, -274, 0,
    -170, -156, -221, -236, -236, -182, -145, 0, 0, 0,
    0, 0, 0, 69, -209, 0, 0, 0, -141, 0,
    0, 0, -143, -206, -131, 0, 0, -176, -154, -129,
    -248, -221, -221, -221, -221, -221, -221, -221, -221, -221,
    -221, -124, -133, 0, 0, 0, 0, 0, 0, 0,
    -37, -114, -122, -118, -115, -138, -113, -111, -110, -176,
    0, 0, -234, -209, -209, -183, -183, -183, -183, -183,
    -183, 0, 0, -133, 0, 0, -206, -176, -255, -176,
    0, -221, 0, -154, -103, 0, -221, 0, 0, 0,
    -221, 0, -252, 0, -104, 0, 0, 0, 0, 0,
    0, -206, 0, -119, -221, -255, 0, -255, 0, 0,
    -181, -255, 0, -107, 0,
};
short yyrindex[] = {168,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 170, 0, 0, 0, 0, 0, -93, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, -224, 0, 0, 0, 0, -155, 0, 0, 0,
    0, 0, 0, 5, -123, 0, 0, 0, 0, 0,
    0, 0, -204, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    -185, 0, -83, 0, -89, -180, -193, 0, -82, 0,
    0, 0, 0, -91, -59, 12, 19, 43, 50, 57,
    81, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -27, 0, -194, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0,
};
short yygindex[] = {0,
    0, 0, 0, 0, -25, 0, 0, 65, 0, -26,
    0, -86, 0, 70, 0, 100, -77, 0, 0, 0,
    -20, 299, 48, 0, 87, 68, 0, 172, 0, 0,
    156, 0,
};

#define YYTABLESIZE 368
short yytable[] = {43,
    49, 33, 50, 115, 61, 14, 19, 51, 33, 91,
    27, 15, 55, 33, 135, 20, 16, 34, 35, 28,
    33, 120, 121, 116, 34, 35, 122, 74, 117, 34,
    35, 21, 36, 32, 123, 33, 38, 39, 40, 32,
    92, 37, 29, 38, 39, 40, 37, 105, 38, 39,
    40, 34, 35, 37, 1, 38, 39, 40, 140, 22,
    141, 70, 2, 49, 144, 71, 29, 23, 37, 29,
    38, 39, 40, 49, 58, 3, 59, 41, 118, 41,
    119, 4, 42, 30, 42, 49, 49, 53, 5, 62,
    63, 130, 76, 77, 78, 79, 133, 80, 142, 143,
    134, 24, 74, 26, 74, 137, 54, 74, 74, 94,
    95, 61, 74, 81, 139, 74, 72, 74, 74, 74,
    56, 57, 73, 74, 74, 74, 75, 90, 74, 74,
    74, 74, 74, 74, 64, 87, 64, 102, 103, 64,
    64, 104, 36, 107, 64, 108, 109, 110, 113, 64,
    64, 111, 114, 112, 132, 64, 64, 64, 136, 138,
    64, 64, 64, 64, 64, 64, 66, 2, 66, 4,
    7, 66, 66, 145, 35, 38, 66, 28, 131, 129,
    106, 66, 66, 25, 52, 0, 0, 66, 66, 66,
    0, 0, 66, 66, 66, 66, 66, 66, 65, 0,
    65, 0, 0, 65, 65, 0, 0, 0, 65, 0,
    0, 0, 0, 65, 65, 0, 0, 0, 0, 65,
    65, 65, 0, 0, 65, 65, 65, 65, 65, 65,
    74, 76, 77, 78, 79, 74, 80, 0, 0, 0,
    74, 0, 0, 74, 0, 74, 74, 74, 0, 0,
    0, 0, 74, 74, 0, 0, 74, 74, 74, 74,
    74, 74, 57, 0, 57, 0, 0, 57, 57, 60,
    0, 60, 57, 0, 60, 60, 61, 0, 61, 60,
    0, 61, 61, 57, 57, 57, 61, 0, 0, 0,
    60, 60, 60, 0, 0, 0, 0, 61, 61, 61,
    62, 0, 62, 0, 0, 62, 62, 63, 0, 63,
    62, 0, 63, 63, 58, 0, 58, 63, 0, 58,
    58, 62, 62, 62, 58, 0, 0, 0, 63, 63,
    63, 0, 0, 0, 0, 58, 58, 58, 59, 0,
    59, 62, 63, 59, 59, 0, 0, 0, 59, 0,
    0, 0, 64, 65, 66, 67, 68, 69, 0, 59,
    59, 59, 96, 97, 98, 99, 100, 101,
};
short yycheck[] = {20,
    27, 257, 28, 90, 257, 264, 257, 28, 257, 258,
    257, 290, 33, 257, 267, 266, 291, 273, 274, 266,
    257, 108, 278, 258, 273, 274, 282, 54, 263, 273,
    274, 264, 276, 258, 290, 257, 292, 293, 294, 264,
    61, 290, 263, 292, 293, 294, 290, 73, 292, 293,
    294, 273, 274, 290, 256, 292, 293, 294, 136, 264,
    138, 271, 264, 258, 142, 275, 260, 264, 290, 263,
    292, 293, 294, 268, 257, 277, 259, 263, 104, 265,
    107, 283, 263, 290, 265, 280, 281, 258, 290, 273,
    274, 112, 269, 270, 271, 272, 117, 274, 280, 281,
    121, 264, 258, 264, 260, 132, 263, 263, 264, 62,
    63, 257, 268, 290, 135, 271, 258, 273, 274, 275,
    34, 35, 266, 279, 280, 281, 258, 257, 284, 285,
    286, 287, 288, 289, 258, 290, 260, 70, 71, 263,
    264, 266, 276, 258, 268, 268, 265, 263, 260, 273,
    274, 290, 263, 267, 258, 279, 280, 281, 263, 279,
    284, 285, 286, 287, 288, 289, 258, 0, 260, 0,
    264, 263, 264, 281, 258, 265, 268, 260, 114, 110,
    81, 273, 274, 12, 29, -1, -1, 279, 280, 281,
    -1, -1, 284, 285, 286, 287, 288, 289, 258, -1,
    260, -1, -1, 263, 264, -1, -1, -1, 268, -1,
    -1, -1, -1, 273, 274, -1, -1, -1, -1, 279,
    280, 281, -1, -1, 284, 285, 286, 287, 288, 289,
    258, 269, 270, 271, 272, 263, 274, -1, -1, -1,
    268, -1, -1, 271, -1, 273, 274, 275, -1, -1,
    -1, -1, 280, 281, -1, -1, 284, 285, 286, 287,
    288, 289, 258, -1, 260, -1, -1, 263, 264, 258,
    -1, 260, 268, -1, 263, 264, 258, -1, 260, 268,
    -1, 263, 264, 279, 280, 281, 268, -1, -1, -1,
    279, 280, 281, -1, -1, -1, -1, 279, 280, 281,
    258, -1, 260, -1, -1, 263, 264, 258, -1, 260,
    268, -1, 263, 264, 258, -1, 260, 268, -1, 263,
    264, 279, 280, 281, 268, -1, -1, -1, 279, 280,
    281, -1, -1, -1, -1, 279, 280, 281, 258, -1,
    260, 273, 274, 263, 264, -1, -1, -1, 268, -1,
    -1, -1, 284, 285, 286, 287, 288, 289, -1, 279,
    280, 281, 64, 65, 66, 67, 68, 69,
};

#define YYFINAL 6
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 294
#if YYDEBUG
char *yyname[] = {
    "end-of-file", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "PAR_OP", "PAR_CL", "BRA_OP",
    "BRA_CL", "SBR_OP", "SBR_CL", "COMMA", "SEMCO", "ARROW", "ASSIGN", "AFFECT", "PIPE",
    "SHARP", "CIRCU", "STAR", "UNDER", "MINUS", "PLUS", "DIV", "MAP", "LET", "IF", "THEN",
    "ELSE", "ENDIF", "NULL_ACTION", "INCLUDE", "GT", "LT", "GTOEQ", "LTOEQ", "EQUAL",
    "NEQUA", "IDENT", "STRING", "NUMBER", "TOK_TRUE", "TOK_FALSE",
};
char *yyrule[] = {
    "$accept : all",
    "all : definitions",
    "all :",
    "definitions : definition definitions",
    "definitions : definition",
    "include : INCLUDE files",
    "files : file COMMA files",
    "files : file",
    "file : STRING",
    "definition : defconst SEMCO",
    "definition : defmacro SEMCO",
    "definition : defstream SEMCO",
    "definition : defpostproc SEMCO",
    "definition : include SEMCO",
    "definition : error SEMCO",
    "definition : SEMCO",
    "defconst : LET IDENT ASSIGN expression",
    "defconst : IDENT ASSIGN expression",
    "defmacro : LET IDENT PAR_OP names PAR_CL ASSIGN construct",
    "defmacro : IDENT PAR_OP names PAR_CL ASSIGN construct",
    "defstream : LET IDENT ASSIGN construct",
    "defstream : IDENT ASSIGN construct",
    "defpostproc : IDENT PAR_OP names PAR_CL",
    "construct : map",
    "map : MAP registers PAR_OP clauses PAR_CL names",
    "map : MAP PAR_OP clauses PAR_CL names",
    "registers : BRA_OP regdecls BRA_CL",
    "regdecls : regdecl COMMA regdecls",
    "regdecls : regdecl",
    "regdecl : IDENT",
    "regdecl : IDENT AFFECT expression",
    "names : name COMMA names",
    "names : name",
    "name : IDENT",
    "clauses : clause PIPE clauses",
    "clauses : clause",
    "clause : patterns ARROW actions",
    "patterns : pattern COMMA patterns",
    "patterns : pattern",
    "pattern : IDENT state",
    "pattern : state IDENT",
    "pattern : IDENT",
    "pattern : state",
    "state : SHARP",
    "state : CIRCU",
    "state : UNDER",
    "state : STAR",
    "state : PLUS",
    "actions : action COMMA actions",
    "actions : action",
    "action : expression",
    "action : ifthenelse",
    "action : assignation",
    "action : NULL_ACTION",
    "ifthenelse : IF expression THEN actions ENDIF",
    "ifthenelse : IF expression THEN actions ELSE actions ENDIF",
    "assignation : IDENT AFFECT expression",
    "expression : sexpression",
    "expression : sexpression EQUAL sexpression",
    "expression : sexpression NEQUA sexpression",
    "expression : sexpression GT sexpression",
    "expression : sexpression LT sexpression",
    "expression : sexpression GTOEQ sexpression",
    "expression : sexpression LTOEQ sexpression",
    "sexpression : factors",
    "sexpression : sexpression PLUS factors",
    "sexpression : sexpression MINUS factors",
    "factors : factor",
    "factors : factors STAR factor",
    "factors : factors DIV factor",
    "factor : fact",
    "factor : PLUS fact",
    "factor : MINUS fact",
    "fact : NUMBER",
    "fact : IDENT",
    "fact : TOK_TRUE",
    "fact : TOK_FALSE",
    "fact : funcall",
    "fact : PAR_OP expression PAR_CL",
    "funcall : IDENT PAR_OP PAR_CL",
    "funcall : IDENT PAR_OP params PAR_CL",
    "params : params COMMA expression",
    "params : expression",
};

#endif
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#ifdef YYSTACKSIZE
#ifndef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#endif
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];

#define yystacksize YYSTACKSIZE
#line 205 "agatyacc.y"

#include "agatlex.c"

yyerror(s)
    char *s;
{
    char tmp[MAX_CHAR_TMP];

    sprintf(tmp, "%s%s", ER_YACC_SYNTAX, yytext);
    parseError(tmp);
}


int 
yywrap()
{
    int fd, i, a;
    IncDesc *pi;

    for (i = 0; i < htNbElts(htInclude); i++) {
	pi = htLookNth(htInclude, i);
	if (pi->done == False) {
	    fd = UOpenPath(lIncludePath, pi->name, O_RDONLY);
	    if (fd < 0) {
		checkError(pi->file, pi->lgn, UOpenError(errno, pi->name));
		pi->done = True;
		continue;		/* for the next include */
	    }
	    close(0);
	    dup(fd);
	    close(fd);
	    yyin = fdopen(0, "r");
	    curLgn = 1;
	    curFile = pi->name;
	    pi->done = True;
	    return 0;
	}
    }
    return 1;
}

#line 405 "y.tab.c"
#define YYABORT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;

#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG")) {
	yyn = *yys;
	if (yyn >= '0' && yyn <= '9')
	    yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate])
	goto yyreduce;
    if (yychar < 0) {
	if ((yychar = yylex()) < 0)
	    yychar = 0;
#if YYDEBUG
	if (yydebug) {
	    yys = 0;
	    if (yychar <= YYMAXTOKEN)
		yys = yyname[yychar];
	    if (!yys)
		yys = "illegal-symbol";
	    printf("yydebug: state %d, reading %d (%s)\n", yystate,
		   yychar, yys);
	}
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
	yyn <= YYTABLESIZE && yycheck[yyn] == yychar) {
#if YYDEBUG
	if (yydebug)
	    printf("yydebug: state %d, shifting to state %d\n",
		   yystate, yytable[yyn]);
#endif
	if (yyssp >= yyss + yystacksize - 1) {
	    goto yyoverflow;
	}
	*++yyssp = yystate = yytable[yyn];
	*++yyvsp = yylval;
	yychar = (-1);
	if (yyerrflag > 0)
	    --yyerrflag;
	goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
	yyn <= YYTABLESIZE && yycheck[yyn] == yychar) {
	yyn = yytable[yyn];
	goto yyreduce;
    }
    if (yyerrflag)
	goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3) {
	yyerrflag = 3;
	for (;;) {
	    if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
		yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE) {
#if YYDEBUG
		if (yydebug)
		    printf("yydebug: state %d, error recovery shifting\
 to state %d\n", *yyssp, yytable[yyn]);
#endif
		if (yyssp >= yyss + yystacksize - 1) {
		    goto yyoverflow;
		}
		*++yyssp = yystate = yytable[yyn];
		*++yyvsp = yylval;
		goto yyloop;
	    }
	    else {
#if YYDEBUG
		if (yydebug)
		    printf("yydebug: error recovery discarding state %d\n",
			   *yyssp);
#endif
		if (yyssp <= yyss)
		    goto yyabort;
		--yyssp;
		--yyvsp;
	    }
	}
    }
    else {
	if (yychar == 0)
	    goto yyabort;
#if YYDEBUG
	if (yydebug) {
	    yys = 0;
	    if (yychar <= YYMAXTOKEN)
		yys = yyname[yychar];
	    if (!yys)
		yys = "illegal-symbol";
	    printf("yydebug: state %d, error recovery discards token %d (%s)\n",
		   yystate, yychar, yys);
	}
#endif
	yychar = (-1);
	goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
	printf("yydebug: state %d, reducing by rule %d (%s)\n",
	       yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1 - yym];
    switch (yyn) {
    case 2:
#line 54 "agatyacc.y"
	{
	    fprintf(stderr, "warning: file %s seems to be empty!\n", curFile);
	}
	break;
    case 8:
#line 69 "agatyacc.y"
	{
	    addInclude(yyvsp[0].pStr);
	}
	break;
    case 9:
#line 72 "agatyacc.y"
	{
	    addDef(yyvsp[-1].pDef);
	}
	break;
    case 10:
#line 73 "agatyacc.y"
	{
	    addDef(yyvsp[-1].pDef);
	}
	break;
    case 11:
#line 74 "agatyacc.y"
	{
	    addDef(yyvsp[-1].pDef);
	}
	break;
    case 12:
#line 75 "agatyacc.y"
	{
	    addDef(yyvsp[-1].pDef);
	}
	break;
    case 16:
#line 81 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_CONST, yyvsp[-2].pStr, NULL, NULL, yyvsp[0].pExpNod);
	}
	break;
    case 17:
#line 82 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_CONST, yyvsp[-2].pStr, NULL, NULL, yyvsp[0].pExpNod);
	}
	break;
    case 18:
#line 85 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_MACRO, yyvsp[-5].pStr, yyvsp[-3].pNames, yyvsp[0].pConstruct, NULL);
	}
	break;
    case 19:
#line 86 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_MACRO, yyvsp[-5].pStr, yyvsp[-3].pNames, yyvsp[0].pConstruct, NULL);
	}
	break;
    case 20:
#line 89 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_STREAM, yyvsp[-2].pStr, NULL, yyvsp[0].pConstruct, NULL);
	}
	break;
    case 21:
#line 90 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_STREAM, yyvsp[-2].pStr, NULL, yyvsp[0].pConstruct, NULL);
	}
	break;
    case 22:
#line 93 "agatyacc.y"
	{
	    yyval.pDef = bDef(DT_POSTPROC, yyvsp[-3].pStr, yyvsp[-1].pNames, NULL, NULL);
	}
	break;
    case 23:
#line 96 "agatyacc.y"
	{
	    yyval.pConstruct = yyvsp[0].pConstruct;
	}
	break;
    case 24:
#line 99 "agatyacc.y"
	{
	    yyval.pConstruct = bConstruct(CT_MAP, yyvsp[-4].pReg, yyvsp[-2].pClause, yyvsp[0].pNames);
	}
	break;
    case 25:
#line 100 "agatyacc.y"
	{
	    yyval.pConstruct = bConstruct(CT_MAP, NULL, yyvsp[-2].pClause, yyvsp[0].pNames);
	}
	break;
    case 26:
#line 103 "agatyacc.y"
	{
	    yyval.pReg = yyvsp[-1].pReg;
	}
	break;
    case 27:
#line 106 "agatyacc.y"
	{
	    yyvsp[-2].pReg->next = yyvsp[0].pReg;
	    yyval.pReg = yyvsp[-2].pReg;
	}
	break;
    case 28:
#line 107 "agatyacc.y"
	{
	    yyval.pReg = yyvsp[0].pReg;
	}
	break;
    case 29:
#line 110 "agatyacc.y"
	{
	    yyval.pReg = bReg(yyvsp[0].pStr, NULL);
	}
	break;
    case 30:
#line 111 "agatyacc.y"
	{
	    yyval.pReg = bReg(yyvsp[-2].pStr, yyvsp[0].pExpNod);
	}
	break;
    case 31:
#line 114 "agatyacc.y"
	{
	    yyvsp[-2].pNames->next = yyvsp[0].pNames;
	    yyval.pNames = yyvsp[-2].pNames;
	}
	break;
    case 32:
#line 115 "agatyacc.y"
	{
	    yyval.pNames = yyvsp[0].pNames;
	}
	break;
    case 33:
#line 118 "agatyacc.y"
	{
	    yyval.pNames = bName(yyvsp[0].pStr);
	}
	break;
    case 34:
#line 121 "agatyacc.y"
	{
	    yyvsp[-2].pClause->next = yyvsp[0].pClause;
	    yyval.pClause = yyvsp[-2].pClause;
	}
	break;
    case 35:
#line 122 "agatyacc.y"
	{
	    yyval.pClause = yyvsp[0].pClause;
	}
	break;
    case 36:
#line 125 "agatyacc.y"
	{
	    yyval.pClause = bClause(yyvsp[-2].pPattern, yyvsp[0].pAction);
	}
	break;
    case 37:
#line 128 "agatyacc.y"
	{
	    yyvsp[-2].pPattern->next = yyvsp[0].pPattern;
	    yyval.pPattern = yyvsp[-2].pPattern;
	}
	break;
    case 38:
#line 129 "agatyacc.y"
	{
	    yyval.pPattern = yyvsp[0].pPattern;
	}
	break;
    case 39:
#line 132 "agatyacc.y"
	{
	    yyval.pPattern = bPattern(yyvsp[-1].pStr, yyvsp[0].State);
	}
	break;
    case 40:
#line 133 "agatyacc.y"
	{
	    yyval.pPattern = bPattern(yyvsp[0].pStr, yyvsp[-1].State);
	}
	break;
    case 41:
#line 134 "agatyacc.y"
	{
	    yyval.pPattern = bPattern(yyvsp[0].pStr, ST_NO_STATE);
	}
	break;
    case 42:
#line 135 "agatyacc.y"
	{
	    yyval.pPattern = bPattern(NULL, yyvsp[0].State);
	}
	break;
    case 43:
#line 138 "agatyacc.y"
	{
	    yyval.State = ST_NO_VALUE;
	}
	break;
    case 44:
#line 139 "agatyacc.y"
	{
	    yyval.State = ST_FIRST_NEW_VALUE;
	}
	break;
    case 45:
#line 140 "agatyacc.y"
	{
	    yyval.State = ST_NEW_VALUE;
	}
	break;
    case 46:
#line 141 "agatyacc.y"
	{
	    yyval.State = ST_NO_NEW_VALUE;
	}
	break;
    case 47:
#line 142 "agatyacc.y"
	{
	    yyval.State = ST_NO_NEW_VALUE_BUT_ONE;
	}
	break;
    case 48:
#line 145 "agatyacc.y"
	{
	    yyvsp[-2].pAction->next = yyvsp[0].pAction;
	    yyval.pAction = yyvsp[-2].pAction;
	}
	break;
    case 49:
#line 146 "agatyacc.y"
	{
	    yyval.pAction = yyvsp[0].pAction;
	}
	break;
    case 50:
#line 149 "agatyacc.y"
	{
	    yyval.pAction = bAction(ACT_EXPR, NULL, yyvsp[0].pExpNod, NULL, NULL);
	}
	break;
    case 51:
#line 150 "agatyacc.y"
	{
	    yyval.pAction = yyvsp[0].pAction;
	}
	break;
    case 52:
#line 151 "agatyacc.y"
	{
	    yyval.pAction = yyvsp[0].pAction;
	}
	break;
    case 53:
#line 152 "agatyacc.y"
	{
	    yyval.pAction = bAction(ACT_NULL, NULL, NULL, NULL, NULL);
	}
	break;
    case 54:
#line 155 "agatyacc.y"
	{
	    yyval.pAction = bAction(ACT_IFTE, NULL, yyvsp[-3].pExpNod, yyvsp[-1].pAction, NULL);
	}
	break;
    case 55:
#line 156 "agatyacc.y"
	{
	    yyval.pAction = bAction(ACT_IFTE, NULL, yyvsp[-5].pExpNod, yyvsp[-3].pAction, yyvsp[-1].pAction);
	}
	break;
    case 56:
#line 159 "agatyacc.y"
	{
	    yyval.pAction = bAction(ACT_ASGN, yyvsp[-2].pStr, yyvsp[0].pExpNod, NULL, NULL);
	}
	break;
    case 57:
#line 162 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 58:
#line 163 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPEQUAL, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 59:
#line 164 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPNEQUA, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 60:
#line 165 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPGT, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 61:
#line 166 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPLT, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 62:
#line 167 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPGTOEQ, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 63:
#line 168 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPLTOEQ, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 64:
#line 171 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 65:
#line 172 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPPLUS, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 66:
#line 173 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPMINUS, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 67:
#line 176 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 68:
#line 177 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPMULT, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 69:
#line 178 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncBin(OPDIV, yyvsp[-2].pExpNod, yyvsp[0].pExpNod);
	}
	break;
    case 70:
#line 182 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 71:
#line 183 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 72:
#line 184 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncUn(OPMINUS_U, yyvsp[0].pExpNod);
	}
	break;
    case 73:
#line 187 "agatyacc.y"
	{
	    yyval.pExpNod = benValue(yyvsp[0].pVal);
	}
	break;
    case 74:
#line 188 "agatyacc.y"
	{
	    yyval.pExpNod = benVar(yyvsp[0].pStr);
	}
	break;
    case 75:
#line 189 "agatyacc.y"
	{
	    yyval.pExpNod = benValue(yyvsp[0].pVal);
	}
	break;
    case 76:
#line 190 "agatyacc.y"
	{
	    yyval.pExpNod = benValue(yyvsp[0].pVal);
	}
	break;
    case 77:
#line 191 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[0].pExpNod;
	}
	break;
    case 78:
#line 192 "agatyacc.y"
	{
	    yyval.pExpNod = yyvsp[-1].pExpNod;
	}
	break;
    case 79:
#line 195 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncCall(yyvsp[-2].pStr, NULL);
	}
	break;
    case 80:
#line 196 "agatyacc.y"
	{
	    yyval.pExpNod = benFuncCall(yyvsp[-3].pStr, yyvsp[-1].pExpNod);
	}
	break;
    case 81:
#line 199 "agatyacc.y"
	{
	    yyval.pExpNod = benArgList(yyvsp[0].pExpNod, yyvsp[-2].pExpNod);
	}
	break;
    case 82:
#line 200 "agatyacc.y"
	{
	    yyval.pExpNod = benArgList(yyvsp[0].pExpNod, NULL);
	}
	break;
#line 837 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0) {
#if YYDEBUG
	if (yydebug)
	    printf("yydebug: after reduction, shifting from state 0 to\
 state %d\n", YYFINAL);
#endif
	yystate = YYFINAL;
	*++yyssp = YYFINAL;
	*++yyvsp = yyval;
	if (yychar < 0) {
	    if ((yychar = yylex()) < 0)
		yychar = 0;
#if YYDEBUG
	    if (yydebug) {
		yys = 0;
		if (yychar <= YYMAXTOKEN)
		    yys = yyname[yychar];
		if (!yys)
		    yys = "illegal-symbol";
		printf("yydebug: state %d, reading %d (%s)\n",
		       YYFINAL, yychar, yys);
	    }
#endif
	}
	if (yychar == 0)
	    goto yyaccept;
	goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
	yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
	yystate = yytable[yyn];
    else
	yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
	printf("yydebug: after reduction, shifting from state %d \
to state %d\n", *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1) {
	goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
