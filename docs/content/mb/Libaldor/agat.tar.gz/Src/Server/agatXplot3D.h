#ifndef AGATXPLOT3D_H
#define AGATXPLOT3D_H
#include "agat.h"

/* size of ticks mark */
#define XPLOT_TICKSIZE 6

/* for Y labels */
/* no y label with less than this lenght */
#define YTICKS_NB_CARMIN 8
/* what part of the screen must be covered by y labels */
/* YTICKS_VRATIO == 5 -> 1/5 of screen height is used for label print */
/* YTICKS_HRATIO == 8 -> 1/8 of screen widht is  used for label print */
#define YTICKS_VRATIO 4
#define YTICKS_HRATIO 8

/* for X labels */
/* no x label with less than this lenght */
#define XTICKS_NB_CARMIN 8
/* a kind of default value for number of ticks */
#define NB_X_TICKS 4
/* what part of the screen must be covered by X labels */
#define XTICKS_HRATIO 1.2


/* number of points checked for compression */
#define COMP_QP_NBP 50


typedef struct Plot3D {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;
    RGB *tabRGB;			/* array of RGB values of the colors
					 * to draw in PS */
    int fontHeight, fontWidth;
    int xsz, ysz;			/* window size */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    View vw;
    void (*refresh) ();
    Boolean firstValue;			/* is this the first point ? */
    Boolean doAxe;			/* must we do the axes ? */
    double minx, maxx, miny, maxy, minz, maxz;	/* values extrema */


    Queue *qv;				/* values plotted */
    int nbpt;				/* nb points */
    double scalex, scaley, scalez;	/* scaling factors */
/*    double          x, y, z, lx, ly, lz;        /* point coord and last point coord */
    Point3 p, lp;
    Boolean onlyPlot3D;			/* line or onlyplot? */
    void (*draw) ();
    void (*resize) ();
    void (*coord) ();
    void (*szoom) ();
    void (*zoom) ();
    void (*m3d) ();
    void (*pps) ();
}      Plot3D;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
void Plot3DRealToScreen(Plot3D * pp, Point3 * ppt, int *x, int *y);

void *initPlot3D(HashTable * pht);

void *initPlotLine3D(HashTable * pht);

void plot3D(Plot3D * pp, Value * vx, Value * vy, Value * vz);

void plot3DInt(Plot3D * pp, Value * vx, Value * vy, Value * vz, Value * reInit);

/************************************************************ End Prototypes */


#endif
