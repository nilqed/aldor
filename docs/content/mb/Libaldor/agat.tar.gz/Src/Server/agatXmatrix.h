#ifndef AGATXMATRIX_H
#define AGATXMATRIX_H
#include "agat.h"

/* size of ticks mark */
#define XMATRIX_TICKSIZE 6

/* for Y labels */
/* no y label with less than this lenght */
#define YTICKS_NB_CARMIN 8
/* what part of the screen must be covered by y labels */
/* YTICKS_VRATIO == 5 -> 1/5 of screen height is used for label print */
/* YTICKS_HRATIO == 8 -> 1/8 of screen widht is  used for label print */
#define YTICKS_VRATIO 4
#define YTICKS_HRATIO 8

/* for X labels */
/* no x label with less than this lenght */
#define XTICKS_NB_CARMIN 8
/* a kind of default value for number of ticks */
#define NB_X_TICKS 4
/* what part of the screen must be covered by X labels */
#define XTICKS_HRATIO 1.2


/* number of points checked for compression */
#define COMP_QP_NBP 50

typedef struct Matrix {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;				/* To respect AnyClass */
    RGB *tabRGB;
    int fontHeight, fontWidth;
    int xsz, ysz;			/* window size */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    ArrayList *al;
    int nbpt;				/* nb points */
    double minx, maxx, miny, maxy;	/* values extrema */
    double scalex, scaley;		/* scaling factors */
    int i, j;
    double minVal, maxVal;
    Boolean colored, propor;
    Boolean firstValue;			/* is this the first point ? */
    Boolean grid;			/* border or not */
    void (*draw) ();
    void (*resize) ();
    void (*refresh) ();
    void (*coord) ();
    void (*szoom) ();
    void (*zoom) ();
    void (*pps) ();
    Boolean doAxe;			/* must we do the axes ? */
}      Matrix;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
double MatrixRealToScreenX(Matrix * pp, double x);

double MatrixRealToScreenY(Matrix * pp, double y);

int retCol(Matrix * pp, int col);

void *initMatrix(HashTable * pht);

void *initMatrixAxe(HashTable * pht);

void *initMatrixGrid(HashTable * pht);

void *initMatrixAxeGrid(HashTable * pht);

/****************************************************************************/
void *initMatrixcol(HashTable * pht);

void *initMatrixcolAxe(HashTable * pht);

void *initMatrixcolGrid(HashTable * pht);

void *initMatrixcolAxeGrid(HashTable * pht);

/****************************************************************************/
void *initMatrixval(HashTable * pht);

void *initMatrixvalAxe(HashTable * pht);

void *initMatrixvalGrid(HashTable * pht);

void *initMatrixvalAxeGrid(HashTable * pht);

void matrix(Matrix * pp, Value * i, Value * j);

void matrixCol(Matrix * pp, Value * i, Value * j, Value * Val);

void matrixVal(Matrix * pp, Value * i, Value * j, Value * Val);

void matrixRestart(Matrix * pp, Value * i, Value * j, Value * reInit);

/************************************************************ End Prototypes */

#endif
