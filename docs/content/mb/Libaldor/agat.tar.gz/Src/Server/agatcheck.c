#include "agat.h"


FADef *allDef;
List *lIncludePath;
HashTable *htInclude;
HashTable *htConst;
HashTable *htMacro;
HashTable *htStream;
HashTable *htFunc;
FuncProto *funcProtos = NULL;
int funcProtosNb;
PostProc *postProcs = NULL;
int postProcsNb;
Boolean silentWarn = False;



/**************************************************************** Prototypes */


/******************************************************************** Bodies */

 /* static */ void *
keyIncDesc(IncDesc * p1)
{
    return p1->name;
}


 /* static */ void *
keyConstDesc(ConstDesc * p1)
{
    return p1->name;
}

 /* static */ void *
keyMacroDesc(MacroDesc * p1)
{
    return p1->name;
}

 /* static */ void *
keyStreamDesc(StreamDesc * p1)
{
    return p1->name;
}

 /* static */ void *
keyFuncDesc(FuncDesc * p1)
{
    return p1->name;
}



void
parseError(char *msg)
{
    fprintf(stderr, "%s:%d: %s\n", curFile, curLgn, msg);
    nbError++;
    if (nbError >= MAX_ERROR_BEF_ABORT) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp, "Aborting: found too much errors (%d error%s)\n",
		nbError, NBTOSS(nbError));
	fprintf(stderr, "%s\n", tmp);
	UExit(1);
    }
}

void
checkError(char *file, int lgn, char *msg)
{
    if (lgn != 0)
	fprintf(stderr, "%s:%d: %s\n", file, lgn, msg);
    else
	fprintf(stderr, "%s: %s\n", file, msg);
    nbError++;
    if (nbError >= MAX_ERROR_BEF_ABORT) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp, "Aborting: found too much errors (%d error%s)\n",
		nbError, NBTOSS(nbError));
	fprintf(stderr, "%s\n", tmp);
	UExit(1);
    }
}


void
checkWarning(char *file, int lgn, char *msg)
{
    if (silentWarn)
	return;
    if (lgn != 0)
	fprintf(stderr, "%s:%d: warning: %s\n", file, lgn, msg);
    else
	fprintf(stderr, "%s: warning: %s\n", file, msg);
}


void
addFunc(char *funcName, int arity, unsigned char parType, unsigned char retType, GenericFunc pFunc)
{
    char *fn;

    fn = UStrDup(funcName);
    htInsert(htFunc, bName(fn), False);
    if (funcProtos == NULL) {
	funcProtos = (FuncProto *) UZalloc(FP_CHKSZ * sizeof(FuncProto));
	funcProtosNb = 0;
    }
    else if (funcProtosNb % FP_CHKSZ == 0)
	funcProtos = (FuncProto *) URealloc(funcProtos,
			     (funcProtosNb + FP_CHKSZ) * sizeof(FuncProto));
    funcProtos[funcProtosNb].n = fn;
    funcProtos[funcProtosNb].arity = arity;
    funcProtos[funcProtosNb].pt = parType;
    funcProtos[funcProtosNb].rt = retType;
    funcProtos[funcProtosNb].pf = pFunc;
    funcProtosNb++;
}

void
addPostProcFunc(char *funcName, int arity, unsigned char st, GenericFunc pInitFunc, GenericFunc pFunc)
{
    PostProc *p;

    if (postProcs == NULL) {
	postProcs = (PostProc *) UZalloc(PP_CHKSZ * sizeof(PostProc));
	postProcsNb = 0;
    }
    else if (postProcsNb % PP_CHKSZ == 0) {
	postProcs = (PostProc *) URealloc(postProcs,
			       (postProcsNb + PP_CHKSZ) * sizeof(PostProc));
    }
    p = &postProcs[postProcsNb];
    p->name = funcName;
    p->arity = arity;
    p->synchType = st;
    p->pfi = (void *(*) ()) pInitFunc;
    p->pf = (void (*) ()) pFunc;
    postProcsNb++;
}



void
initFirstAnalysis(void)
{					/* size, keyFunc, orderFunc,
					 * freeFunc, hashFunc, printFunc */
    htInclude = htCreate(HT_INC_SZ, keyIncDesc, ordString, free, hashString, printString);
    htConst = htCreate(HT_CONST_SZ, keyConstDesc, ordString, free, hashString, printString);
    htMacro = htCreate(HT_MACRO_SZ, keyMacroDesc, ordString, free, hashString, printString);
    htStream = htCreate(HT_STREAM_SZ, keyStreamDesc, ordString, free, hashString, printString);
    htFunc = htCreate(HT_FUNC_SZ, keyFuncDesc, ordString, free, hashString, printString);
    initFunc();
    initPostProcFunc();
}

void
endFirstAnalysis(void)
{
    htFree(htInclude, True);
    htFree(htConst, True);
    htFree(htMacro, True);
    htFree(htStream, True);
}


void
addDef(FADef * pd)
{
    static FADef *pl = NULL;

    if (pl == NULL)
	allDef = pd;
    else
	pl->next = pd;
    pl = pd;
}


void
addInclude(char *ident)
{
    IncDesc *p;

    p = (IncDesc *) UCalloc(1, sizeof(IncDesc));
    p->lgn = curLgn;
    p->file = curFile;
    p->name = ident;
    p->done = False;
    htInsert(htInclude, p, False);
}



void
addConst(char *file, int lgn, char *ident, FADef * pd)
{
    ConstDesc *ps, *p;

    if ((ps = htSearchKey(htConst, ident)) != NULL) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp,
	    "Constant %s already defined in\n%s:%d first declaration of %s",
		ident, ps->file, ps->lgn, ident);
	checkError(file, lgn, tmp);
	return;
    }
    p = (ConstDesc *) UCalloc(1, sizeof(ConstDesc));
    p->lgn = lgn;
    p->file = file;
    p->name = ident;
    p->cycle = False;
    p->pd = pd;
    htInsert(htConst, p, False);
}

void
addMacro(char *file, int lgn, char *ident, int nbArg, FADef * pd)
{
    MacroDesc *ps, *p;

    if ((ps = htSearchKey(htMacro, ident)) != NULL) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp,
	      "Macro %s already defined in\n%s:%d: first declaration of %s",
		ident, ps->file, ps->lgn, ident);
	parseError(tmp);
	return;
    }
    p = (MacroDesc *) UCalloc(1, sizeof(MacroDesc));
    p->lgn = lgn;
    p->file = file;
    p->name = ident;
    p->pc = pd->pc;
    p->nbArg = nbArg;
    htInsert(htMacro, p, False);
}

void
addStream(char *file, int lgn, char *ident, FADef * pd)
{
    StreamDesc *ps, *p;

    if ((ps = htSearchKey(htStream, ident)) != NULL) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp,
	  "Stream %s already defined in...\n%s:%d: first declaration of %s",
		ident, ps->file, ps->lgn, ident);
	checkError(file, lgn, tmp);
	return;
    }
    p = (StreamDesc *) UCalloc(1, sizeof(StreamDesc));
    p->lgn = lgn;
    p->file = file;
    p->name = ident;
    p->pd = pd;
    htInsert(htStream, p, False);
}

 /* static */ char *
NewStreamName(void)
{
    static int n = 0;

    char tmp[MAX_CHAR_TMP];

    sprintf(tmp, "_F%d", n++);
    return UStrDup(tmp);
}


/* transform a funcall (which is in fact a macro call) */
/* into a stream reference */
/* this new stream is named and added to the list of definitions */
 /* static */ FAExpNode *
callToStream(FAExpNode * pen)
{
    FADef *pd;
    char *nn;

    nn = NewStreamName();
    pd = bDef(DT_CONST, nn, NULL, NULL, pen);
    pd->lgn = pen->lgn;
    pd->file = pen->file;
    addDef(pd);
    return benVar(nn);
}


 /* static */ FAName *
callParams(FAOp * po)
{
    FAName *ln, *lnt;
    int i;

    ln = NULL;
    for (i = 0; i < po->arity; i++) {
	if (po->sons[i]->t == ENT_OP)	/* transform the funcall in a stream
					 * def */
	    po->sons[i] = callToStream(po->sons[i]);
	lnt = ln;
	ln = (FAName *) UZalloc(sizeof(FAName));
	ln->file = po->sons[i]->file;
	ln->lgn = po->sons[i]->lgn;
	ln->n = po->sons[i]->varName;
	ln->next = lnt;
    }
    return ln;
}

 /* static */ void
constToCallMacro(FADef * pd)
{
    MacroDesc *pmd;

    pd->t = DT_STREAM;
    pd->pc = bConstruct(CT_CMACR, NULL, NULL, NULL);
    pd->pc->lgn = pd->pen->lgn;
    pd->pc->file = pd->pen->file;
    /* find the constructor of this macro */
    pmd = htSearchKey(htMacro, pd->pen->po->opName);
    /* duplicate this constructor to fill the map */
    pd->pc = dupConstruct(pmd->pc);
    pd->pc->lf = callParams(pd->pen->po);
    pd->pc->name = pd->pen->po->opName;
    pd->pc->nbArg = pd->pen->po->arity;
    pd->pen = NULL;			/* ??free exptree */
}


 /* static */ Boolean
goodMacroParams(FAOp * po)
{
    int i;

    for (i = 0; i < po->arity; i++) {
	if (po->sons[i]->t == ENT_VAR)	/* ok that's a stream reference */
	    continue;
	if (po->sons[i]->t == ENT_OP)
	    if ((htSearchKey(htMacro, po->sons[i]->po->opName)) &&
		(goodMacroParams(po->sons[i]->po)))	/* ok that's a macro
							 * call */
		continue;
	return False;			/* bad news, that's not a stream
					 * constructor */
    }
    return True;			/* all right these parameters are all
					 * stream-like */
}


/* check a definition to see if it's not a stream definition with a callmacro */
/* instead of a const definition with a function call */
 /* static */ void
findCallMacro(FADef * ldef)
{
    Boolean macroIdent;
    Boolean funcIdent;
    Boolean goodParams;
    char tmp[MAX_CHAR_TMP];

    while (ldef != NULL) {
	if ((ldef->t == DT_CONST) && (ldef->pen->t == ENT_OP)) {
	    macroIdent = (htSearchKey(htMacro, ldef->pen->po->opName)) ? True : False;
	    funcIdent = (htSearchKey(htFunc, ldef->pen->po->opName)) ? True : False;
	    goodParams = goodMacroParams(ldef->pen->po);
	    if (macroIdent && funcIdent && !goodParams) {
		sprintf(tmp, "%s is taken to be a function call instead of a macro call because parameters are not stream ", ldef->pen->po->opName);
		checkWarning(ldef->pen->file, ldef->pen->lgn, tmp);
	    }
	    else if (macroIdent && funcIdent && goodParams) {
		sprintf(tmp, "%s is taken to be a macro call (hiding a function call)", ldef->pen->po->opName);
		checkWarning(ldef->pen->file, ldef->pen->lgn, tmp);
	    }
	    else if (macroIdent && !funcIdent && !goodParams) {
		sprintf(tmp, " bad kind of parameters for a macro call ");
		checkError(ldef->pen->file, ldef->pen->lgn, tmp);
	    }
	    if (macroIdent && goodParams) {
		/* that's not a const definition but a callmacro */
		constToCallMacro(ldef);
	    }
	}
	ldef = ldef->next;
    }
}

int
nbFANames(FAName * lf)
{
    int nbn = 0;

    while (lf != NULL) {
	nbn++;
	lf = lf->next;
    }
    return nbn;
}

 /* static */ void
findMacroIdent(FADef * ldef)
{
    while (ldef != NULL) {
	switch (ldef->t) {
	    case DT_MACRO:{
		addMacro(ldef->file, ldef->lgn, ldef->name, nbFANames(ldef->lf), ldef);
		break;
	    }
	}
	ldef = ldef->next;
    }
}

 /* static */ void
findConstStreamIdent(FADef * ldef)
{
    while (ldef != NULL) {
	switch (ldef->t) {
	    case DT_CONST:{
		addConst(ldef->file, ldef->lgn, ldef->name, ldef);
		break;
	    }
	case DT_STREAM:{
		addStream(ldef->file, ldef->lgn, ldef->name, ldef);
		break;
	    }
	}
	ldef = ldef->next;
    }
}


/*************************/
/* for semantic checking */
/*************************/

/* check if two types are compatible.         */
/* two floating points number are compatibles */
/* two integers are compatibles               */
/* (Booleanis taken to be integer)              */
Boolean
compTypes(unsigned char t1, unsigned char t2)
{
    Boolean isInt1, isFloat1;
    Boolean isInt2, isFloat2;

    if ((t1 == VT_NOTYPE) || (t2 == VT_NOTYPE))
	return True;
    isInt1 = ((t1 >= VT_BOOL) && (t1 <= VT_ULONG)) ? True : False;
    isFloat1 = ((t1 >= VT_FLOAT) && (t1 <= VT_DOUBLE)) ? True : False;
    isInt2 = ((t2 >= VT_BOOL) && (t2 <= VT_ULONG)) ? True : False;
    isFloat2 = ((t2 >= VT_FLOAT) && (t2 <= VT_DOUBLE)) ? True : False;

    return ((isInt1 && isInt2) || (isFloat1 && isFloat2)) ? True : False;
}



 /* static */ FAName *
concFANameList(FAName * la, FAName * lb)
{
    FAName *l;

    if (la == NULL)
	return lb;
    if (lb == NULL)
	return la;
    l = la;
    while (la->next != NULL)
	la = la->next;
    la->next = lb;
    return l;
}

 /* static */ FAName *
nameUsed(FAExpNode * pen)
{
    FAName *lnu = NULL, *lp;
    FAOp *po;
    int i;

    if (pen->t == ENT_VAR) {
	lnu = (FAName *) UZalloc(sizeof(FAName));
	lnu->next = NULL;
	lnu->lgn = pen->lgn;
	lnu->file = pen->file;
	lnu->n = pen->varName;
    }
    else if (pen->t == ENT_OP) {
	po = pen->po;
	for (i = 0; i < po->arity; i++) {
	    lp = lnu;
	    lnu = nameUsed(po->sons[i]);
	    lnu = concFANameList(lp, lnu);
	}
    }
    return lnu;
}

 /* static */ void
scCycle(FAName * ln, FAName * lnu)
{
    ConstDesc *pcd;
    FAName cn, *pn;

    while (lnu != NULL) {
	pn = ln;
	while (pn != NULL) {
	    if (!strcmp(pn->n, lnu->n)) {
		char tmp[MAX_CHAR_TMP];

		pcd = htSearchKey(htConst, pn->n);
		if ((pcd != NULL) && (pcd->cycle == False)) {
		    pcd->cycle = True;
		    sprintf(tmp, "cycle during declaration of %s", pn->n);
		    checkError(lnu->file, lnu->lgn, tmp);
		}
		return;
	    }
	    pn = pn->next;
	}
	pcd = htSearchKey(htConst, lnu->n);
	if ((pcd != NULL) && (pcd->cycle == False)) {
	    /* to avoid undeclared const and infinite loops */
	    cn.n = lnu->n;
	    cn.next = ln;
	    cn.file = "";
	    cn.lgn = 0;
	    scCycle(&cn, pcd->lnu);
	}
	lnu = lnu->next;
    }
    return;
}

 /* static */ void
scConstDefsLoops(FADef * ldef)
{
    FAName *lnu, cn;
    ConstDesc *pcd;
    FADef *pd;

    /* to build List of Used Names, prior cycle detection */
    pd = ldef;
    while (pd != NULL) {
	if (pd->t == DT_CONST) {
	    lnu = nameUsed(pd->pen);
	    pcd = htSearchKey(htConst, pd->name);
	    pcd->lnu = lnu;
	    while (lnu != NULL) {
		if (!htSearchKey(htConst, lnu->n)) {
		    char tmp[MAX_CHAR_TMP];

		    sprintf(tmp, "no such constant %s", lnu->n);
		    checkError(lnu->file, lnu->lgn, tmp);
		}
		lnu = lnu->next;
	    }
	}
	pd = pd->next;
    }
    /* to check cycles for each const declaration */
    pd = ldef;
    while (pd != NULL) {
	if (pd->t == DT_CONST) {
	    pcd = htSearchKey(htConst, pd->name);
	    if ((pcd != NULL) && (pcd->cycle == False)) {
		/* to avoid undeclared const and infinite loops */
		cn.n = pd->name;
		cn.next = NULL;
		cn.file = "";
		cn.lgn = 0;
		scCycle(&cn, pcd->lnu);
	    }
	}
	pd = pd->next;
    }
}


/* checks that a macro call matchs the prototype of macro */
 /* static */ void
scMacroCall(FAConstruct * pc)
{
    MacroDesc *pmd;
    char tmp[MAX_CHAR_TMP];

    pmd = htSearchKey(htMacro, pc->name);
    if (pmd == NULL) {
	sprintf(tmp, "macro %s undefined", pc->name);
	checkError(pc->file, pc->lgn, tmp);
	return;
    }
    if (pc->nbArg != pmd->nbArg) {
	sprintf(tmp, "macro %s defined with %d argument%s ", pc->name, pmd->nbArg, NBTOSS(pmd->nbArg));
	checkError(pc->file, pc->lgn, tmp);
	return;
    }
}

 /* static */ LString *
scRegisters(FAReg * lr)
{
    LString *lrn = NULL;
    FAReg *pr;

    if (lr == NULL)
	return (LString *) NULL;
    pr = lr;
    while (pr) {
	lrn = lsAdd(lrn, pr->regName);
	pr = pr->next;
    }
    pr = lr;
    while (pr) {
	if (pr->pen != NULL)
	    scExpr(pr->pen, lrn, NULL);
	pr = pr->next;
    }
    return lrn;
}

 /* static */ int
scVar(FAExpNode * pe, LString * lrn, LString * lpi)
{
    Boolean isReg, isPat;
    ConstDesc *isConst;
    char tmp[MAX_CHAR_TMP];

    isPat = lsIn(lpi, pe->varName);
    isReg = lsIn(lrn, pe->varName);
    isConst = htSearchKey(htConst, pe->varName);
    if (isPat && isReg) {
	sprintf(tmp, "pattern %s will hide register of same name", pe->varName);
	checkWarning(pe->file, pe->lgn, tmp);
    }
    else if (isPat && isConst) {
	sprintf(tmp, "pattern %s will hide constant of same name\n%s:%d: declaration of constant %s", pe->varName, isConst->file, isConst->lgn, pe->varName);
	checkWarning(pe->file, pe->lgn, tmp);
    }
    else if (isReg && isConst) {
	sprintf(tmp, "register %s will hide constant of same name\n%s:%d: declaration of constant %s", pe->varName, isConst->file, isConst->lgn, pe->varName);
	checkWarning(pe->file, pe->lgn, tmp);
    }
    pe->pvn = (VarNode *) UZalloc(sizeof(VarNode));
    pe->pvn->t = (isPat) ? VNT_PAT : ((isReg) ? VNT_REG : ((isConst) ? VNT_CST : VNT_NOTYPE));
    pe->pvn->pv = NULL;
    return VT_NOTYPE;
}


 /* static */ void *
keyFuncProto(FuncProto * pfp)
{
    return pfp->n;
}

 /* static */ int
scOp(FAExpNode * pe, LString * lrn, LString * lpi)
{
    char tmp[MAX_CHAR_TMP];
    FuncDesc *fd;
    int i, j;
    Boolean foundName = False;
    Boolean foundArity = False;
    int lt = VT_NOTYPE, bt = VT_NOTYPE, rt = -1;
    List *opl;

    if ((fd = htSearchKey(htFunc, pe->po->opName)) == NULL) {
	sprintf(tmp, "no such function '%s'", pe->po->opName);
	checkError(pe->file, pe->lgn, tmp);
	return VT_NOTYPE;
    }
    /* this is the list of functions that will be searched at run-time     */
    /* to find the right one due to the parameter type (which is sometimes */
    /* known only during interpretation)                                   */
    opl = lCreate(keyFuncProto, ordVoid, nullFunc, printString);
    pe->po->opl = opl;
    for (i = 0; i < funcProtosNb; i++) {
	if (!strcmp(funcProtos[i].n, pe->po->opName)) {
	    foundName = True;
	    if (pe->po->arity == funcProtos[i].arity) {
		foundArity = True;
		for (j = 0; j < funcProtos[i].arity; j++) {
		    lt = Max(lt, scExpr(pe->po->sons[j], lrn, lpi));
		    /* actually function have homogeneous parameter types  */
		    /* so the more complex one is given to be the good one */
		    /* order of complexity is in type define               */
		    /* => array>..>double>long>int>bool...                 */
		}
		bt = Max(bt, funcProtos[i].pt);
		if (lt <= funcProtos[i].pt) {	/* it's a good prototype */
		    /* add it to the run-time-searched list of function */
		    lAdd(opl, &funcProtos[i]);
		    if (rt == -1)
			rt = funcProtos[i].rt;
		    else
			rt = Min(rt, funcProtos[i].rt);
		    /*
		     * the minimum type found will be used as the returned
		     * type
		     */
		    /* type checking is quite cool, isn't it? */
		}
	    }
	}
    }
    if (rt != -1)			/* ok there's at least one good
					 * prototype */
	return rt;
    if ((foundName) && (foundArity))
	sprintf(tmp, "bad parameter type for this function (%s instead of %s)",
		typeToStr(lt), typeToStr(bt));
    else
	sprintf(tmp, "bad number of parameters for this function");

    checkError(pe->file, pe->lgn, tmp);
    return VT_NOTYPE;			/* not reached */
}


 /* static */ int
scExpr(FAExpNode * pe, LString * lrn, LString * lpi)
{
    switch (pe->t) {
	case ENT_VAR:{
	    return scVar(pe, lrn, lpi);
	    break;
	}
    case ENT_OP:{
	    return scOp(pe, lrn, lpi);
	    break;
	}
    case ENT_VAL:{
	    return pe->pv->t;
	    break;
	}
    default:{
	    UIError("agat server", "%s", "scExpr: unknown pe->t");
	    return 0;
	}
    }
}


 /* static */ void
scIfThenElse(FAAction * pa, LString * lrn, LString * lpi)
{
    if (!compTypes(scExpr(pa->e, lrn, lpi), VT_BOOL))
	checkError(pa->e->file, pa->e->lgn,
		   "expression used in if statment must be boolean. ");
    scActions(pa->thenA, lrn, lpi);
    if (pa->elseA != NULL)
	scActions(pa->elseA, lrn, lpi);
}

 /* static */ void
scAssign(FAAction * pa, LString * lrn, LString * lpi)
{
    char tmp[MAX_CHAR_TMP];

    if (!lsIn(lrn, pa->regName)) {
	sprintf(tmp, "unknown register %s.", pa->regName);
	checkError(pa->file, pa->lgn, tmp);
    }
    scExpr(pa->e, lrn, lpi);
}

 /* static */ void
scActions(FAAction * la, LString * lrn, LString * lpi)
{
    while (la != NULL) {
	switch (la->t) {
	    case ACT_EXPR:{
		scExpr(la->e, lrn, lpi);
		break;
	    }
	case ACT_IFTE:{
		scIfThenElse(la, lrn, lpi);
		break;
	    }
	case ACT_ASGN:{
		scAssign(la, lrn, lpi);
		break;
	    }
	case ACT_NULL:{
		break;
	    }
	}
	la = la->next;
    }
}

 /* static */ int
scPattern(FAPattern * pp)
{
    if ((pp->name) && (pp->state == ST_NO_VALUE))
	checkError(pp->file, pp->lgn,
		   "a 'no value' pattern can't be named ");
    if ((pp->name) && (pp->state == ST_NO_NEW_VALUE))
	checkError(pp->file, pp->lgn,
		   "a 'no new value' pattern can't be named ");
    return ((pp->state != ST_NO_VALUE) && (pp->state != ST_NO_NEW_VALUE)) ? 1 : 0;
}


 /* static */ LString *
scPatterns(FAPattern * lp, int nbArg)
{
    int nbp = 0, nbn = 0;
    LString *lrn = NULL;
    FAPattern *pp;
    char tmp[MAX_CHAR_TMP];

    pp = lp;
    while (pp != NULL) {
	nbn += scPattern(pp);
	lrn = lsAdd(lrn, pp->name);
	nbp++;
	pp = pp->next;
    }
    if (nbp != nbArg) {
	sprintf(tmp, "there%s %s pattern%s than stream (%d pattern%s for %d stream) ",
		NBTOSBE(nbp), (nbp > nbArg) ? "more" : "less", NBTOSS(nbp),
		nbp, NBTOSS(nbp), nbArg);
	checkError(lp->file, lp->lgn, tmp);
    }
    if (nbn == 0)
	checkError(lp->file, lp->lgn, "there must be at least one pattern like ^+_ (or a named one)");
    return lrn;
}


 /* static */ void
scMap(FAConstruct * pc)
{
    FAClause *lc;
    LString *lrn, *lpi;

    lrn = scRegisters(pc->lr);
    lc = pc->lc;
    while (lc != NULL) {
	lpi = scPatterns(lc->lp, pc->nbArg);
	scActions(lc->la, lrn, lpi);
	lsFree(lpi, False);
	lc = lc->next;
    }
}


 /* static */ void
scConstruct(FAConstruct * pc)
{
    switch (pc->t) {
	case CT_MAP:{
	    scMap(pc);
	    break;
	}
    case CT_CMACR:{
	    /* allready checked during const to macrocall conversion */
	    break;
	}
    }
}


 /* static */ Boolean
inFANameList(FAName * ln, char *n)
{
    while (ln != NULL) {
	if (!strcmp(ln->n, n))
	    return True;
	ln = ln->next;
    }
    return False;
}



/* checks that the stream used in right part are defined in left part */
/* and checks constructor */
 /* static */ void
scMacroDef(FADef * pd)
{
    FAName *ln;
    char tmp[MAX_CHAR_TMP];

    ln = pd->pc->lf;
    while (ln) {
	if (!inFANameList(pd->lf, ln->n)) {
	    sprintf(tmp, "unknown stream %s ", ln->n);
	    checkError(ln->file, ln->lgn, tmp);
	}
	ln = ln->next;
    }
    scConstruct(pd->pc);
}


 /* static */ void
scPostProcDef(FADef * pd)
{
    char tmp[MAX_CHAR_TMP];
    int i, nba = 0, foundArity = 0;
    Boolean foundName = False;

    nba = nbFANames(pd->lf);
    for (i = 0; i < postProcsNb; i++) {
	if (!strcmp(postProcs[i].name, pd->name)) {
	    foundName = True;
	    if (postProcs[i].arity == VAR_ARITY)
		foundArity++;
	    else if (nba == postProcs[i].arity)
		foundArity++;
	}
    }
    if (foundName == False) {
	sprintf(tmp, "the post-processing function %s is unknown.", pd->name);
	checkError(pd->file, pd->lgn, tmp);
	return;
    }
    else if (foundArity == 0) {
	sprintf(tmp, "the post-processing function %s with %d parameter%s is unknown.", pd->name, nba, NBTOSS(nba));
	checkError(pd->file, pd->lgn, tmp);
	return;
    }
    else if (foundArity > 1) {
	sprintf(tmp, "the post-processing function %s with %d parameter%s is ambiguous (%d matching prototypes found).", pd->name, nba, NBTOSS(nba), foundArity);
	checkError(pd->file, pd->lgn, tmp);
	return;
    }
}


/* checks the semantic correctness of a definition list */
 /* static */ void
scDefs(FADef * ldef)
{

    while (ldef != NULL) {
	switch (ldef->t) {
	    case DT_CONST:{
		/* checks expression used for const initialisation */
		/* const defs have already been checked for loops */
		scExpr(ldef->pen, NULL, NULL);
		break;
	    }
	case DT_STREAM:{
		/* checks constructor */
		scConstruct(ldef->pc);
		break;
	    }
	case DT_MACRO:{
		scMacroDef(ldef);
		break;
	    }

	case DT_POSTPROC:{
		scPostProcDef(ldef);
		break;
	    }
	}
	ldef = ldef->next;
    }
}


void
semaCheck(FADef * allDef)
{
    findMacroIdent(allDef);
    findCallMacro(allDef);
    findConstStreamIdent(allDef);
    scConstDefsLoops(allDef);
    scDefs(allDef);
}
