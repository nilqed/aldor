#include "agat.h"

#define NB_PS_FONT 4
#define DFLT_FONT  "12 /Times-Roman"


static char *listfmly[] = {"times", "helvetica", "courier", "symbol"};
char *useFont = NULL;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */

void
headPs(FILE * fps, AnyClassOp * pc)
{
    char *title[255];
    struct timeval tp;
    struct timezone tzp;
    struct tm *ptm;
    char *dateTime;

    fprintf(fps, "%%!PS-Adobe-1.0\n");
    fprintf(fps, "%%%%Creator: AGAT\n");
    XFetchName(pc->dpy, pc->win, title);
    if (*title != NULL)
	fprintf(fps, "%%%%Title: %s\n", *title);
    gettimeofday(&tp, &tzp);
    ptm = localtime(&(tp.tv_sec));
    if (ptm != NULL) {
	dateTime = asctime(ptm);
	fprintf(fps, "%%%%CreationDate: %s", dateTime);
    }
    fprintf(fps, "%%%%Pages: 1\n");
    fprintf(fps, "%%%%DocumentFonts: (atend)\n");
    fprintf(fps, "%%%%BoundingBox: 0 0 %d %d\n", pc->xsz, pc->ysz);
    fprintf(fps, "%%%%EndComments\n");
    fprintf(fps, "%%----- Variables -----\n");
    fprintf(fps, "/xsz %d def\n/ysz %d def\n", pc->xsz, pc->ysz);
    fprintf(fps, "%%----- Functions -----\n");
    fprintf(fps, "/setcolor                       %%Stack:r,g,b.\n");
    fprintf(fps, "{ setrgbcolor } def\n");
    fprintf(fps, "/plot                           %%Stack:x,y,r,g,b.\n");
    fprintf(fps, "{ setcolor moveto 1 1 rlineto stroke } def\n");
    fprintf(fps, "/line                           %%Stack:x1,y1,x2,y2,r,g,b.\n");
    fprintf(fps, "{ setcolor moveto lineto stroke } def\n");
    fprintf(fps, "/print\n{\n");
    fprintf(fps, " /b exch def /g exch def /r exch def\n");
    fprintf(fps, " /y exch def /x exch def\n");
    fprintf(fps, " /font exch def /size exch def /ch exch def\n");
    fprintf(fps, " r g b setcolor x y moveto\n");
    fprintf(fps, " font findfont size scalefont setfont\n");
    fprintf(fps, " ch show stroke\n} def\n");
    fprintf(fps, "/clipbox\n{\n newpath\n");
    fprintf(fps, " 0 0 moveto 0 ysz lineto xsz ysz lineto\n");
    fprintf(fps, " xsz 0 lineto 0 0 lineto closepath\n} def\n");
    fprintf(fps, "/rect\n{\n newpath\n");
    fprintf(fps, " setcolor moveto\n");
    fprintf(fps, " rlineto rlineto rlineto\n");
    fprintf(fps, " closepath stroke\n} def\n");
    fprintf(fps, "/rectfill\n{\n newpath\n");
    fprintf(fps, " setcolor moveto\n");
    fprintf(fps, " rlineto rlineto rlineto\n");
    fprintf(fps, " closepath fill stroke\n} def\n");
    fprintf(fps, "%%%%EndProlog\n");
    fprintf(fps, "clipbox clip\nnewpath\n");
}

void
tailPs(FILE * fps)
{
    fprintf(fps, "stroke\nshowpage\n");
    fprintf(fps, "%%%%Trailer\n");
    if (useFont != NULL)
	fprintf(fps, "%%%%DocumentsFonts: %s\n", useFont);
}

void
x2psColors(AnyClassOp * pc, int *tabCol, RGB * tabRGB, int nbCol)
{
    XColor xcol[nbCol];
    int i;

    /* Initialize struct */
    for (i = 0; i < nbCol; i++) {
	xcol[i].pixel = tabCol[i];
	tabRGB[i].xCol = tabCol[i];
    }

    XQueryColors(pc->dpy, DefaultColormap(pc->dpy, DefaultScreen(pc->dpy)), xcol, nbCol);

    for (i = 0; i < nbCol; i++) {
	tabRGB[i].r = (double) xcol[i].red / 65535.;
	tabRGB[i].g = (double) xcol[i].green / 65535.;
	tabRGB[i].b = (double) xcol[i].blue / 65535.;
    }
}

char *
getTokenNum(char *xFont, int nb)
{
    static char *res;
    int i;
    char buf[255];


    strcpy(buf, xFont);
    res = strtok(buf, "-");
    for (i = 0; i < (nb - 1); i++)
	res = strtok(NULL, "-");
    return res;
}

int
goodPsSize(int sz)
{
    if (sz <= 8)
	return 8;
    if ((sz >= 12) && (sz < 14))
	return 12;
    if ((sz >= 14) && (sz <= 16))
	return 14;
    if ((sz >= 17) && (sz <= 20))
	return 18;
    if (sz > 20)
	return 24;
}

void
x2psFont(AnyClassOp * pc, char *xFont, char *psFont)
{
    char *tmp, *pxlsz;
    char tmpfmly[50], fmly[50], tmppxlsz[5];
    char c;
    int sz, i;

    if (xFont != NULL) {
	tmp = getTokenNum(xFont, 2);
	if (tmp == NULL) {		/* If not an X Font */
	    sprintf(psFont, DFLT_FONT);
	    useFont = (char *) UZalloc(sizeof(char) * strlen(DFLT_FONT));
	    strcpy(useFont, psFont);
	    return;
	}
	strcpy(tmpfmly, tmp);
	for (i = 0; i < NB_PS_FONT; i++)
	    if (strcmp(tmpfmly, listfmly[i]) == 0)
		break;
	if ((listfmly[i] != 0) && (strcmp(tmpfmly, listfmly[i]) == 0)) {
	    c = toupper(tmpfmly[0]);
	    sprintf(fmly, "%c%s", c, &tmpfmly[1]);
	}
	else
	    sprintf(fmly, "%s", "Times-Roman");

	if (useFont == NULL) {
	    useFont = (char *) UZalloc(sizeof(char) * strlen(fmly));
	    strcpy(useFont, fmly);
	}

	tmp = getTokenNum(xFont, 7);
	if (tmp == NULL) {		/* If not an X Font */
	    sprintf(psFont, DFLT_FONT);
	    useFont = (char *) UZalloc(sizeof(char) * strlen(DFLT_FONT));
	    strcpy(useFont, psFont);
	    return;
	}
	strcpy(tmppxlsz, tmp);
	pxlsz = (char *) UZalloc(sizeof(char) * 2);
	if (strcmp(tmppxlsz, "*") != 0) {
	    sz = atoi(tmppxlsz);
	    if (sz < 10)
		sprintf(pxlsz, "%d", sz);
	    else
		sprintf(pxlsz, "%d%d", sz / 10, sz - ((sz / 10) * 10));
	}
	else
	    sprintf(pxlsz, "12");

	sprintf(psFont, "%s /%s", pxlsz, fmly);
	free(pxlsz);
    }
}
