#ifndef AGATXZOOM_H
#define AGATXZOOM_H

#include "agat.h"

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
void dpySelectRect(Display * dpy, Window win, GC xorGc, int imX, int imY, int mX, int mY);

void selectRect(Xwin * pxw, int x, int y);

void selectStrip(Xwin * pxw, int x, int y);

/************************************************************ End Prototypes */


#endif
