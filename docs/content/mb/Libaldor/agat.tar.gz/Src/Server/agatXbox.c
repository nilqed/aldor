#include "agat.h"


#define ENLARG_RAT 0.1
#define EnlargePlot(x,y) ((x)+ENLARG_RAT*((x)-(y)))

#define X_AXE 1
#define Y_AXE 2
#define SW_AXE(axe,x,y) (((axe)==X_AXE)?(x):(y))
#define XTICKS_MAXSTEP 10

#define SamePt(xa,ya,xb,yb,eps) ((Abs((xa)-(xb))<(eps))&&((Abs((ya)-(yb))<(eps))))
/*
 * int SamePt(double xa,double ya,double xb,double yb,double eps) { return
 * ((Abs((xa)-(xb))<eps)&&(Abs((ya)-(yb))<eps)); }
 */

#define BoxScreenToRealX(pp,x) ((((x)-(pp)->xm)/(pp)->scalex)+(pp)->minx)
#define BoxScreenToRealY(pp,y) ((((-y)+(pp)->ysz-(pp)->ym)/(pp)->scaley)+(pp)->miny)

/**************************************************************** Prototypes */

static void drawBox(Box * pp);
static void drawBoxFill(Box * pp);
static void boxResize(Box * pp, int x, int y);
static void boxCoord(Box * pp, int x, int y, int rx, int ry, Window win, int First);
static void boxZoom(Box * pp, int x1, int y1, int x2, int y2);
static void boxPS(Box * pp, int x, int y);
static Box *initBoxAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, Boolean onlyShape, char *name);
static void findAxe(Box * pp, int *pve, int axe);
static void plotXTicks(Box * pp, int posAxe);
static void plotYTicks(Box * pp, int posAxe);
static void plotOneAxe(Box * pp, int axe);
static void plotAxes(Box * pp);
static void boxRefresh(Box * pp);

/******************************************************************** Bodies */

double
BoxRealToScreenX(Box * pp, double x)
{
    return (((x) - (pp)->minx) * (pp)->scalex + (pp)->xm);
}


double
BoxRealToScreenY(Box * pp, double y)
{
    if (!pp->ps)
	return ((pp)->ysz - (pp)->ym - ((y) - (pp)->miny) * (pp)->scaley);
    else
	return ((pp)->ym + ((y) - (pp)->miny) * (pp)->scaley);
}


static void
drawBox(Box * pp)
{
    int ulex, uley, lrex, lrey;

    ulex = BoxRealToScreenX(pp, pp->ulx);
    uley = BoxRealToScreenY(pp, pp->uly);
    lrex = BoxRealToScreenX(pp, pp->lrx);
    lrey = BoxRealToScreenY(pp, pp->lry);

    if ((ulex == lrex) && (uley == lrey))
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ulex, uley);

    agatDrawRectangle((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ulex, uley, lrex - ulex, lrey - uley);
}


static void
drawBoxFill(Box * pp)
{
    int ulex, uley, lrex, lrey;

    ulex = BoxRealToScreenX(pp, pp->ulx);
    uley = BoxRealToScreenY(pp, pp->uly);
    lrex = BoxRealToScreenX(pp, pp->lrx);
    lrey = BoxRealToScreenY(pp, pp->lry);

    if ((ulex == lrex) && (uley == lrey))
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ulex, uley);

    agatFillRectangle((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ulex, uley, lrex - ulex, lrey - uley);
}



static void
boxResize(Box * pp, int x, int y)
{
    Value *vx, *vy;
    int i;
    double maxx, maxy, minx, miny;

    if (x <= 0)
	x = 1;
    if (y <= 0)
	y = 1;
    pp->xsz = x;
    pp->ysz = y;
    pp->xusz = x - pp->xm * 2;
    pp->yusz = y - pp->ym * 2;
    /* recompute extrema */
    if (qNbElts(pp->qv)) {
	vx = (Value *) qLookNth(pp->qv, 0);
	vy = (Value *) qLookNth(pp->qv, 1);
	minx = maxx = vx->v.d;
	miny = maxy = vy->v.d;
	for (i = 2; i < qNbElts(pp->qv);) {
	    vx = (Value *) qLookNth(pp->qv, i++);
	    vy = (Value *) qLookNth(pp->qv, i++);
	    if (vx->v.d > maxx)
		maxx = vx->v.d;
	    else if (vx->v.d < minx)
		minx = vx->v.d;
	    if (vy->v.d > maxy)
		maxy = vy->v.d;
	    else if (vy->v.d < miny)
		miny = vy->v.d;
	}
	pp->maxx = maxx;
	pp->minx = minx;
	pp->maxy = maxy;
	pp->miny = miny;

	XFreePixmap(pp->dpy, pp->pixmap);
	pp->pixmap = XCreatePixmap(pp->dpy, pp->win, x, y, DefaultDepth(pp->dpy, DefaultScreen(pp->dpy)));
    }
}


static void
boxCoord(Box * pp, int x, int y, int rx, int ry, Window win, int First)
{
#define MARG_H 5
#define MARG_W 10
#define MARG_PT_X 10
#define MARG_PT_Y 10

    char tmp[100];
    static int size = 0;
    XEvent event_return;

    sprintf(tmp, "X : %f  Y : %f", BoxScreenToRealX(pp, x), BoxScreenToRealY(pp, y));
    XSynchronize(pp->dpy, True);
    XMoveWindow(pp->dpy, win, rx + MARG_PT_X, ry + MARG_PT_Y);
    if (size != strlen(tmp) || First) {
	XResizeWindow(pp->dpy, win, MARG_W + strlen(tmp) * pp->fontWidth,
		      pp->fontHeight + MARG_H * 2);
	XWindowEvent(pp->dpy, win, ExposureMask, &event_return);
    }
    size = strlen(tmp);
    XClearWindow(pp->dpy, win);
    agatDrawString((AnyClassOp *) pp, win, pp->textGc, MARG_W, MARG_H + pp->fontHeight, tmp, strlen(tmp));
    XFlush(pp->dpy);
    XSynchronize(pp->dpy, False);
}


static void
boxZoom(Box * pp, int x1, int y1, int x2, int y2)
{
    Box *newpp;
    RDataBase initRDB;

    newpp = (Box *) UZalloc(sizeof(Box));
    *newpp = *pp;
    newpp->type = ZOOM_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen("zoom") + 1));
    strcpy(pp->name, "zoom");
    newpp->minx = BoxScreenToRealX(pp, x1);
    newpp->maxy = BoxScreenToRealY(pp, y1);
    newpp->maxx = BoxScreenToRealX(pp, x2);
    newpp->miny = BoxScreenToRealY(pp, y2);
    extractDB(0, NULL, pp->dpy, "zoom", &initRDB);
    newpp->xsz = initRDB.xsz;
    newpp->ysz = initRDB.ysz;
    newpp->xm = initRDB.xm;
    newpp->ym = initRDB.ym;
    newpp->xusz = newpp->xsz - newpp->xm * 2;
    newpp->yusz = newpp->ysz - newpp->ym * 2;

    createFirstWindow(&newpp->dpy, &newpp->win, &newpp->pixmap, newpp->xsz, newpp->ysz, &initRDB);
    addXwin(newpp->dpy, newpp->win, ZOOM_WINDOW, newpp->refresh, newpp->resize,
	  newpp->coord, newpp->szoom, newpp->zoom, NULL, newpp->pps, newpp);
    XStoreName(newpp->dpy, newpp->win, "zoom");
    mapWindow(newpp->dpy, newpp->win, &initRDB);
}


static void
boxPS(Box * pp, int x, int y)
{
    RDataBase initRDB;
    int tabCol[NB_MAX_COLOR + 3];
    char *buffer = NULL, *file[255];
    int i;

    extractDB(0, NULL, pp->dpy, buffer, &initRDB);	/* ?? */
    pp->ps = True;
    XFetchName(pp->dpy, pp->win, file);
    if (*file != NULL) {
	pp->fps = fopen(*file, "w");
	if (pp->fps != NULL) {
	    headPs(pp->fps, (AnyClassOp *) pp);

	    pp->tabRGB = (RGB *) UZalloc(sizeof(RGB) * (NB_MAX_COLOR + 3));	/* +Back,Text,Mark */
	    tabCol[0] = initRDB.fg;
	    tabCol[1] = initRDB.bg;
	    tabCol[2] = initRDB.markcolor;
	    for (i = 3; i < (NB_MAX_COLOR + 3); i++)
		tabCol[i] = initRDB.tabColor[i - 3];

	    x2psColors((AnyClassOp *) pp, tabCol, pp->tabRGB, (NB_MAX_COLOR + 3));

	    (*(pp->refresh)) (pp);
	    tailPs(pp->fps);
	    fclose(pp->fps);
	}
	else
	    fprintf(stderr, "Can't open file !\n");
    }
    pp->ps = False;
}


static Box *initBoxAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, Boolean onlyShape, char *name) {
    Box *pp;
    InitPar *pip;
    Display *dpy;
    char *buffer;
    RDataBase initRDB;

    dpy = openDisplayOnlyOne();
    pp = (Box *) UZalloc(sizeof(Box));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    pp->type = BOX_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(pp->name, buffer);
    pp->iconified = False;		/* ?? */
    pp->killed = False;
    pp->ps = False;
    pp->xsz = initRDB.xsz;
    pp->ysz = initRDB.ysz;
    pp->xm = initRDB.xm;
    pp->ym = initRDB.xm;
    pp->xusz = pp->xsz - pp->xm * 2;
    pp->yusz = pp->ysz - pp->ym * 2;
    createFirstWindow(&pp->dpy, &pp->win, &pp->pixmap, pp->xsz, pp->ysz, &initRDB);

    pp->backGc = createBackGc(pp->dpy, pp->win, initRDB.bg);
    pp->textGc = createTextGc(pp->dpy, pp->win, initRDB.font, initRDB.fg,
			      &pp->fontWidth, &pp->fontHeight);
    pp->font = (char *) UZalloc(sizeof(char) * (strlen(initRDB.font) + 1));
    strcpy(pp->font, initRDB.font);
    addXwin(pp->dpy, pp->win, pp->type, ref, res, coord, szoom, zoom, NULL, pps, pp);
    appNameClass(pp->dpy, pp->win);
    XStoreName(pp->dpy, pp->win, buffer);
    pp->drawGcs = createGcs(pp->dpy, pp->win, initRDB.tabColor, 2);
    pp->qv = qCreate(nullFunc);
    pp->nbpt = 0;
    pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
    pp->scalex = pp->scaley = 1.0;
    pp->firstValue = True;
    pp->onlyShape = onlyShape;
    pp->draw = draw;
    pp->resize = res;
    pp->refresh = ref;
    pp->coord = coord;
    pp->szoom = szoom;
    pp->zoom = zoom;
    pp->pps = pps;
    pp->doAxe = doAxe;
    mapWindow(pp->dpy, pp->win, &initRDB);
    if (pp->iconified) {
	XIconifyWindow(pp->dpy, pp->win, DefaultScreen(dpy));
	XFlush(pp->dpy);
    }
    return pp;
}


void *
initBoxAxe(HashTable * pht)
{
    return initBoxAux(pht, boxRefresh, boxResize, drawBox, boxCoord, selectRect, boxZoom, boxPS, True, True, "box");
}

void *
initBox(HashTable * pht)
{
    return initBoxAux(pht, boxRefresh, boxResize, drawBox, boxCoord, selectRect, boxZoom, boxPS, False, True, "box");
}

void *
initBoxAxeFill(HashTable * pht)
{
    return initBoxAux(pht, boxRefresh, boxResize, drawBoxFill, boxCoord, selectRect, boxZoom, boxPS, True, False, "box");
}

void *
initBoxFill(HashTable * pht)
{
    return initBoxAux(pht, boxRefresh, boxResize, drawBoxFill, boxCoord, selectRect, boxZoom, boxPS, False, False, "box");
}



static void
findAxe(Box * pp, int *pve, int axe)
{
    double minv, maxv, scalev;
    double v;

    if (axe == Y_AXE) {
	minv = pp->minx;
	maxv = pp->maxx;
	scalev = pp->scalex;
    }
    else {
	minv = pp->miny;
	maxv = pp->maxy;
	scalev = pp->scaley;
    }
    v = Min(Max(minv, 0.0), maxv);
    if (axe == Y_AXE) {
	v = BoxRealToScreenX(pp, v);
	*pve = (int) Min(pp->xsz, Max(0, v));
    }
    else {
	v = BoxRealToScreenY(pp, v);
	*pve = (int) Min(pp->ysz, Max(0, v));
    }
}


static void
plotXTicks(Box * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbTotCar, nbLabCar, maxc, tmp;
    double *aTicks;
    char **aLabs;
    Bool reduced = False;

    nbTicks = buildXTicksLabs(pp->xsz, pp->fontWidth, pp->minx, pp->maxx,
			      XTICKS_HRATIO, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	x = BoxRealToScreenX(pp, aTicks[i]);
	if (posAxe < (pp->fontHeight + 2)) {
	    /* put labels under X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe - 1, x, posAxe + XBOX_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe + (pp->fontHeight + 2), aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* put labels over X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe + 1, x, posAxe - XBOX_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe - 2, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotYTicks(Box * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbLabCar;
    double *aTicks;
    char **aLabs;

    nbTicks = buildYTicksLabs(pp->xsz, pp->ysz, pp->fontHeight, pp->fontWidth,
			      pp->miny, pp->maxy, YTICKS_NB_CARMIN,
		  YTICKS_VRATIO, YTICKS_HRATIO, &nbLabCar, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	y = BoxRealToScreenY(pp, aTicks[i]);
	if ((pp->xsz - posAxe) < (pp->fontWidth * (nbLabCar + 1))) {
	    /* axe is near the right bordre of window */
	    /* so plot ticks and labels to the left of axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + 1, y, posAxe - XBOX_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - (pp->fontWidth * (strlen(aLabs[i]) + 1)), y, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* all is right */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - 1, y, posAxe + XBOX_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + (pp->fontWidth), y, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotOneAxe(Box * pp, int axe)
{
    int posAxe;

    if ((pp->minx == pp->maxx) || (pp->miny == pp->maxy))
	return;
    findAxe(pp, &posAxe, axe);
    if (axe == Y_AXE) {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe, 0, posAxe, pp->ysz);
	plotYTicks(pp, posAxe);
    }
    else {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, 0, posAxe, pp->xsz, posAxe);
	plotXTicks(pp, posAxe);
    }
}


static void
plotAxes(Box * pp)
{
    plotOneAxe(pp, X_AXE);
    plotOneAxe(pp, Y_AXE);
}


static void
boxRefresh(Box * pp)
{
    Value *vulx, *vuly, *vlrx, *vlry;
    int ulex, uley, lrex, lrey, i;

    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz, pp->ysz);
    if (pp->firstValue) {
	if (pp->maxx == pp->minx)
	    pp->maxx += 1e-100;
	if (pp->maxy == pp->miny)
	    pp->maxy += 1e-100;
	pp->firstValue = False;
    }

    pp->scalex = ((double) pp->xusz) / (pp->maxx - pp->minx);
    pp->scaley = ((double) pp->yusz) / (pp->maxy - pp->miny);
    for (i = 0; i < qNbElts(pp->qv);) {
	vulx = (Value *) qLookNth(pp->qv, i++);
	vuly = (Value *) qLookNth(pp->qv, i++);
	vlrx = (Value *) qLookNth(pp->qv, i++);
	vlry = (Value *) qLookNth(pp->qv, i++);
	ulex = BoxRealToScreenX(pp, vulx->v.d);
	uley = BoxRealToScreenY(pp, vuly->v.d);
	lrex = BoxRealToScreenX(pp, vlrx->v.d);
	lrey = BoxRealToScreenY(pp, vlry->v.d);

	if (pp->onlyShape == True)
	    agatDrawRectangle((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ulex, uley, lrex - ulex, lrey - uley);
	else
	    agatFillRectangle((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ulex, uley, lrex - ulex, lrey - uley);

    }
    if (pp->doAxe)
	plotAxes(pp);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz, pp->ysz, 0, 0);
	XFlush(pp->dpy);
    }
}


void
box(Box * pp, Value * vulx, Value * vuly, Value * vlrx, Value * vlry)
{
    double ulx, uly, lrx, lry;
    Boolean ref = False;


    ulx = valToDouble(vulx);
    uly = valToDouble(vuly);
    lrx = valToDouble(vlrx);
    lry = valToDouble(vlry);
    if (ulx > lrx) {
	USwap(ulx, lrx, double);
	USwap(vulx, vlrx, Value *);
    }
    if (uly < lry) {
	USwap(uly, lry, double);
	USwap(vuly, vlry, Value *);
    }
    if (pp->firstValue) {
	pp->minx = ulx;
	pp->maxx = lrx;
	pp->miny = lry;
	pp->maxy = uly;
	ref = True;
    }
    else {
	if (ulx < pp->minx) {
	    pp->minx = EnlargePlot(ulx, pp->maxx);
	    ref = True;
	}
	if (lrx > pp->maxx) {
	    pp->maxx = EnlargePlot(lrx, pp->minx);
	    ref = True;
	}
	if (lry < pp->miny) {
	    pp->miny = EnlargePlot(lry, pp->maxy);
	    ref = True;
	}
	if (uly > pp->maxy) {
	    pp->maxy = EnlargePlot(uly, pp->miny);
	    ref = True;
	}
    }
    pp->nbpt += 2;
    qAdd(pp->qv, convertVal(vulx, 0, ulx));
    qAdd(pp->qv, convertVal(vuly, 1, uly));
    qAdd(pp->qv, convertVal(vlrx, 2, lrx));
    qAdd(pp->qv, convertVal(vlry, 3, lry));
    pp->ulx = ulx;
    pp->uly = uly;
    pp->lrx = lrx;
    pp->lry = lry;
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp);
	    XFlush(pp->dpy);
	}
    }
}


void
boxRestart(Box * pp, Value * vulx, Value * vuly, Value * vlrx, Value * vlry, Value * reInit)
{
    if (evalBool(reInit)) {
	qDel(pp->qv, qNbElts(pp->qv), unAllocValue);
	pp->nbpt = 0;
	pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
	pp->scalex = pp->scaley = 1.0;
	pp->firstValue = True;
    }
    unAllocValue(reInit);
    box(pp, vulx, vuly, vlrx, vlry);
}
