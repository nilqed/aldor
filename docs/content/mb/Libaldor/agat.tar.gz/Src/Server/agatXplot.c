#include "agat.h"


#define ENLARG_RAT 0.1
#define EnlargePlot(x,y) ((x)+ENLARG_RAT*((x)-(y)))
#define XTICKS_MAXSTEP 10
#define X_AXE 1
#define Y_AXE 2
#define SW_AXE(axe,x,y) (((axe)==X_AXE)?(x):(y))


#define SamePt(xa,ya,xb,yb,eps) ((Abs((xa)-(xb))<(eps))&&((Abs((ya)-(yb))<(eps))))
/*
 * int SamePt(double xa,double ya,double xb,double yb,double eps) { return
 * ((Abs((xa)-(xb))<eps)&&(Abs((ya)-(yb))<eps)); }
 */

#define PlotScreenToRealX(pp,x) ((((x)-(pp)->xm)/(pp)->scalex)+(pp)->minx)
#define PlotScreenToRealY(pp,y) ((((-y)+(pp)->ysz-(pp)->ym)/(pp)->scaley)+(pp)->miny)


/**************************************************************** Prototypes */

static void putMark(AnyClassOp * pc, Window win, GC gc, int ex, int ey);
static void drawSegm(Plot * pp);
static void drawPoint(Plot * pp);
static void plotResize(Plot * pp, int x, int y);
static void plotCoord(Plot * pp, int x, int y, int rx, int ry, Window win, int First);
static void plotZoom(Plot * pp, int x1, int y1, int x2, int y2);
static void plotPS(Plot * pp, int x, int y);
static Plot *initPlotAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, char *name);
static void findAxe(Plot * pp, int *pve, int axe);
static void plotXTicks(Plot * pp, int posAxe);
static void plotYTicks(Plot * pp, int posAxe);
static void plotOneAxe(Plot * pp, int axe);
static void plotAxes(Plot * pp);
static void plotRefresh(Plot * pp);
static void plotLineRefresh(Plot * pp);

/* start:   check all points or just the last chunck> */
static void compressQPlot(Queue * qv, double eps, int nbcheck, int all);

/******************************************************************** Bodies */


double
PlotRealToScreenX(Plot * pp, double x)
{
    return (((x) - (pp)->minx) * (pp)->scalex + (pp)->xm);
}


double
PlotRealToScreenY(Plot * pp, double y)
{
    if (!pp->ps)
	return ((pp)->ysz - (pp)->ym - ((y) - (pp)->miny) * (pp)->scaley);
    else
	return ((pp)->ym + ((y) - (pp)->miny) * (pp)->scaley);
}


static void
putMark(AnyClassOp * pc, Window win, GC gc, int ex, int ey)
{
    agatDrawLine(pc, win, gc, ex - 5, ey, ex + 5, ey);
    agatDrawLine(pc, win, gc, ex, ey - 5, ex, ey + 5);
}


static void
drawSegm(Plot * pp)
{
    int ex, ey, lex, ley;

    Window *tmpWin;

    lex = PlotRealToScreenX(pp, pp->lx);
    ley = PlotRealToScreenY(pp, pp->ly);
    ex = PlotRealToScreenX(pp, pp->x);
    ey = PlotRealToScreenY(pp, pp->y);
    if (pp->onlyPlot)
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ex, ey);
    else {
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, lex, ley);

	agatDrawBasicLine((AnyClassOp *) pp, pp->win, pp->drawGcs[0], lex, ley, ex, ey, 0, 0, pp->xsz, pp->ysz);
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, ex, ey);
    }
}

static void
drawPoint(Plot * pp)
{
    int ex, ey, lex, ley;

    lex = PlotRealToScreenX(pp, pp->lx);
    ley = PlotRealToScreenY(pp, pp->ly);
    ex = PlotRealToScreenX(pp, pp->x);
    ey = PlotRealToScreenY(pp, pp->y);
    if (!pp->onlyPlot) {
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, lex, ley);
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], lex, ley);
    }
    putMark((AnyClassOp *) pp, pp->win, pp->markGc, ex, ey);
    XFlush(pp->dpy);
}


static void
plotResize(Plot * pp, int x, int y)
{
    Value *vx, *vy;
    int i;
    double maxx, maxy, minx, miny;

    if (x <= 0)
	x = 1;
    if (y <= 0)
	y = 1;
    pp->xsz = x;
    pp->ysz = y;
    pp->xusz = x - pp->xm * 2;
    pp->yusz = y - pp->ym * 2;
    /* recompute extrema */
    if (qNbElts(pp->qv)) {
	vx = (Value *) qLookNth(pp->qv, 0);
	vy = (Value *) qLookNth(pp->qv, 1);
	minx = maxx = vx->v.d;
	miny = maxy = vy->v.d;

	for (i = 2; i < qNbElts(pp->qv);) {
	    vx = (Value *) qLookNth(pp->qv, i++);
	    vy = (Value *) qLookNth(pp->qv, i++);
	    if (vx->v.d > maxx)
		maxx = vx->v.d;
	    else if (vx->v.d < minx)
		minx = vx->v.d;

	    if (vy->v.d > maxy)
		maxy = vy->v.d;
	    else if (vy->v.d < miny)
		miny = vy->v.d;
	}
	pp->maxx = maxx;
	pp->minx = minx;
	pp->maxy = maxy;
	pp->miny = miny;

	XFreePixmap(pp->dpy, pp->pixmap);
	pp->pixmap = XCreatePixmap(pp->dpy, pp->win, x, y, DefaultDepth(pp->dpy, DefaultScreen(pp->dpy)));
    }
}


static void
plotCoord(Plot * pp, int x, int y, int rx, int ry, Window win, int First)
{
#define MARG_H 5
#define MARG_W 10
#define MARG_PT_X 10
#define MARG_PT_Y 10

    char tmp[100];
    static int size = 0;
    XEvent event_return;


    sprintf(tmp, " X : %g  Y : %g", PlotScreenToRealX(pp, x), PlotScreenToRealY(pp, y));
    XSynchronize(pp->dpy, True);
    XMoveWindow(pp->dpy, win, rx + MARG_PT_X, ry + MARG_PT_Y);
    if (size != strlen(tmp) || First) {
	XResizeWindow(pp->dpy, win, MARG_W + strlen(tmp) * pp->fontWidth,
		      pp->fontHeight + MARG_H * 2);
	XWindowEvent(pp->dpy, win, ExposureMask, &event_return);
    }
    size = strlen(tmp);
    XClearWindow(pp->dpy, win);
    agatDrawString((AnyClassOp *) pp, win, pp->textGc, MARG_W, MARG_H + pp->fontHeight, tmp, strlen(tmp));
    XFlush(pp->dpy);
    XSynchronize(pp->dpy, False);
}


static void
plotZoom(Plot * pp, int x1, int y1, int x2, int y2)
{
    Plot *newpp;
    RDataBase initRDB;

    newpp = (Plot *) UZalloc(sizeof(Plot));
    *newpp = *pp;
    newpp->type = ZOOM_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen("zoom") + 1));
    strcpy(pp->name, "zoom");
    newpp->minx = PlotScreenToRealX(pp, x1);
    newpp->maxy = PlotScreenToRealY(pp, y1);
    newpp->maxx = PlotScreenToRealX(pp, x2);
    newpp->miny = PlotScreenToRealY(pp, y2);
    extractDB(0, NULL, pp->dpy, "zoom", &initRDB);
    newpp->xsz = initRDB.xsz;
    newpp->ysz = initRDB.ysz;
    newpp->xm = initRDB.xm;
    newpp->ym = initRDB.ym;
    newpp->xusz = newpp->xsz - newpp->xm * 2;
    newpp->yusz = newpp->ysz - newpp->ym * 2;

    createFirstWindow(&newpp->dpy, &newpp->win, &newpp->pixmap, newpp->xsz, newpp->ysz, &initRDB);
    addXwin(newpp->dpy, newpp->win, ZOOM_WINDOW, newpp->refresh, newpp->resize,
	  newpp->coord, newpp->szoom, newpp->zoom, NULL, newpp->pps, newpp);
    XStoreName(newpp->dpy, newpp->win, "zoom");
    mapWindow(newpp->dpy, newpp->win, &initRDB);
}


static void
plotPS(Plot * pp, int x, int y)
{
    RDataBase initRDB;
    int tabCol[NB_MAX_COLOR + 3];
    char *buffer = NULL, *file[255];
    int i;

    extractDB(0, NULL, pp->dpy, buffer, &initRDB);	/* ?? */
    pp->ps = True;
    XFetchName(pp->dpy, pp->win, file);
    if (*file != NULL) {
	pp->fps = fopen(*file, "w");
	if (pp->fps != NULL) {
	    headPs(pp->fps, (AnyClassOp *) pp);

	    pp->tabRGB = (RGB *) UZalloc(sizeof(RGB) * (NB_MAX_COLOR + 3));	/* +Back,Text,Mark */
	    tabCol[0] = initRDB.fg;
	    tabCol[1] = initRDB.bg;
	    tabCol[2] = initRDB.markcolor;
	    for (i = 3; i < (NB_MAX_COLOR + 3); i++)
		tabCol[i] = initRDB.tabColor[i - 3];

	    x2psColors((AnyClassOp *) pp, tabCol, pp->tabRGB, (NB_MAX_COLOR + 3));

	    (*(pp->refresh)) (pp);
	    tailPs(pp->fps);
	    fclose(pp->fps);
	}
	else
	    fprintf(stderr, "Can't open file !\n");
    }
    pp->ps = False;
}


static Plot *initPlotAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*pps) (), Boolean doAxe, char *name) {
    Plot *pp;
    InitPar *pip;
    Display *dpy;
    char *buffer = NULL;
    RDataBase initRDB;

    dpy = openDisplayOnlyOne();
    pp = (Plot *) UZalloc(sizeof(Plot));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    pp->type = PLOT_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(pp->name, buffer);
    pp->iconified = False;		/* ?? */
    pp->killed = False;
    pp->ps = False;
    pp->xsz = initRDB.xsz;
    pp->ysz = initRDB.ysz;
    pp->xm = initRDB.xm;
    pp->ym = initRDB.ym;
    pp->xusz = pp->xsz - pp->xm * 2;
    pp->yusz = pp->ysz - pp->ym * 2;
    createFirstWindow(&pp->dpy, &pp->win, &pp->pixmap, pp->xsz, pp->ysz, &initRDB);

    pp->backGc = createBackGc(pp->dpy, pp->win, initRDB.bg);
    pp->textGc = createTextGc(pp->dpy, pp->win, initRDB.font, initRDB.fg,
			      &pp->fontWidth, &pp->fontHeight);
    pp->font = (char *) UZalloc(sizeof(char) * (strlen(initRDB.font) + 1));
    strcpy(pp->font, initRDB.font);
    addXwin(pp->dpy, pp->win, pp->type, ref, res, coord, szoom, zoom, NULL, pps, pp);
    appNameClass(pp->dpy, pp->win);
    XStoreName(pp->dpy, pp->win, buffer);
    pp->drawGcs = createGcs(pp->dpy, pp->win, initRDB.tabColor, 2);
    pp->markGc = createXorColorGc(pp->dpy, pp->win, initRDB.markcolor);
    pp->qv = qCreate(nullFunc);
    pp->nbpt = 0;
    pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
    pp->scalex = pp->scaley = 1.0;
    pp->firstValue = True;
    pp->draw = draw;
    pp->resize = res;
    pp->refresh = ref;
    pp->coord = coord;
    pp->szoom = szoom;
    pp->zoom = zoom;
    pp->pps = pps;
    pp->doAxe = doAxe;
    mapWindow(pp->dpy, pp->win, &initRDB);
    if (pp->iconified) {
	XIconifyWindow(pp->dpy, pp->win, DefaultScreen(dpy));
	XFlush(pp->dpy);
    }
    return pp;
}

void *
initPlotAxe(HashTable * pht)
{
    return initPlotAux(pht, plotRefresh, plotResize, drawPoint, plotCoord, selectRect, plotZoom, plotPS, True, "plot");
}

void *
initPlot(HashTable * pht)
{
    return initPlotAux(pht, plotRefresh, plotResize, drawPoint, plotCoord, selectRect, plotZoom, plotPS, False, "plot");
}

void *
initPlotAxeLine(HashTable * pht)
{
    return initPlotAux(pht, plotLineRefresh, plotResize, drawSegm, plotCoord, selectRect, plotZoom, plotPS, True, "plot");
}

void *
initPlotLine(HashTable * pht)
{
    return initPlotAux(pht, plotLineRefresh, plotResize, drawSegm, plotCoord, selectRect, plotZoom, plotPS, False, "plot");
}


static void
findAxe(Plot * pp, int *pve, int axe)
{
    double minv, maxv, scalev;
    double v;

    if (axe == Y_AXE) {
	minv = pp->minx;
	maxv = pp->maxx;
	scalev = pp->scalex;
    }
    else {
	minv = pp->miny;
	maxv = pp->maxy;
	scalev = pp->scaley;
    }
    v = Min(Max(minv, 0.0), maxv);
    if (axe == Y_AXE) {
	v = PlotRealToScreenX(pp, v);
	*pve = (int) Min(pp->xsz, Max(0, v));
    }
    else {
	v = PlotRealToScreenY(pp, v);
	*pve = (int) Min(pp->ysz, Max(0, v));

    }
}


static void
plotXTicks(Plot * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbTotCar, nbLabCar, maxc, tmp;
    double *aTicks;
    char **aLabs;
    Bool reduced = False;

    nbTicks = buildXTicksLabs(pp->xsz, pp->fontWidth, pp->minx, pp->maxx,
			      XTICKS_HRATIO, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	x = PlotRealToScreenX(pp, aTicks[i]);
	if ((pp->ysz - posAxe) < (pp->fontHeight + 2)) {
	    /* put labels over X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe + 1, x, posAxe - XPLOT_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe - 2, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* put labels under X axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, x, posAxe - 1, x, posAxe + XPLOT_TICKSIZE);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, x + 2, posAxe + (pp->fontHeight + 2), aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotYTicks(Plot * pp, int posAxe)
{
    int nbTicks, i, j, x, y, nbLabCar;
    double *aTicks;
    char **aLabs;

    nbTicks = buildYTicksLabs(pp->xsz, pp->ysz, pp->fontHeight, pp->fontWidth,
			      pp->miny, pp->maxy, YTICKS_NB_CARMIN,
		  YTICKS_VRATIO, YTICKS_HRATIO, &nbLabCar, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	y = PlotRealToScreenY(pp, aTicks[i]);
	if ((pp->xsz - posAxe) < (pp->fontWidth * (nbLabCar + 1))) {
	    /* axe is near the right border of window */
	    /* so plot ticks and labels to the left of axe */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + 1, y, posAxe - XPLOT_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - (pp->fontWidth * (strlen(aLabs[i]) + 1)), y, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* all is right */
	    agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe - 1, y, posAxe + XPLOT_TICKSIZE, y);
	    agatDrawString((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe + (pp->fontWidth), y, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}


static void
plotOneAxe(Plot * pp, int axe)
{
    int posAxe;

    if ((pp->minx == pp->maxx) || (pp->miny == pp->maxy))
	return;
    findAxe(pp, &posAxe, axe);
    if (axe == Y_AXE) {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, posAxe, 0, posAxe, pp->ysz);
	plotYTicks(pp, posAxe);
    }
    else {
	agatDrawLine((AnyClassOp *) pp, pp->pixmap, pp->textGc, 0, posAxe, pp->xsz, posAxe);
	plotXTicks(pp, posAxe);
    }
}


static void
plotAxes(Plot * pp)
{
    plotOneAxe(pp, X_AXE);
    plotOneAxe(pp, Y_AXE);
}


static void
plotRefresh(Plot * pp)
{
    Value *vx, *vy;
    int ex, ey, i;

    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz + 1, pp->ysz + 1);
    if (pp->firstValue) {
	pp->maxx = NonNull(pp->minx, pp->maxx);
	pp->minx = pp->maxx - 1.0e-10;
	pp->maxy = NonNull(pp->miny, pp->maxy);
	pp->miny = pp->maxy - 1.0e-10;
	pp->firstValue = False;
    }
    compressQPlot(pp->qv,
		  (Min((pp->maxx - pp->minx) / (double) pp->xusz,
		       (pp->maxy - pp->miny) / (double) pp->yusz)) / 4.0,
		  COMP_QP_NBP / 1.5, True);

    pp->scalex = ((double) pp->xusz) / UForceNonZero(pp->maxx - pp->minx, 1.0e-10);
    pp->scaley = ((double) pp->yusz) / UForceNonZero(pp->maxy - pp->miny, 1.0e-10);
    for (i = 0; i < qNbElts(pp->qv);) {
	vx = (Value *) qLookNth(pp->qv, i++);
	vy = (Value *) qLookNth(pp->qv, i++);
	ex = PlotRealToScreenX(pp, vx->v.d);
	ey = PlotRealToScreenY(pp, vy->v.d);
	agatDrawPoint((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ex, ey);
    }
    if (qNbElts(pp->qv))
	putMark((AnyClassOp *) pp, pp->pixmap, pp->markGc, ex, ey);
    if (pp->doAxe)
	plotAxes(pp);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz + 1, pp->ysz + 1, 0, 0);
	XFlush(pp->dpy);
    }
}


static void
plotLineRefresh(Plot * pp)
{
    Value *vx, *vy;
    double ex, ey, lex, ley;
    int i;

    if (qNbElts(pp->qv) < 4)
	return;
    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz + 1, pp->ysz + 1);
    if (pp->firstValue) {
	if (pp->nbpt < 2) {
	    pp->maxx = NonNull(pp->minx, pp->maxx);
	    pp->minx = pp->maxx - 1.0e-10;
	    pp->maxy = NonNull(pp->miny, pp->maxy);
	    pp->miny = pp->maxy - 1.0e-10;
	}
	pp->firstValue = False;
    }
    pp->scalex = ((double) pp->xusz) / UForceNonZero(pp->maxx - pp->minx, 1.0e-10);
    pp->scaley = ((double) pp->yusz) / UForceNonZero(pp->maxy - pp->miny, 1.0e-10);
    vx = (Value *) qLookNth(pp->qv, 0);
    vy = (Value *) qLookNth(pp->qv, 1);
    lex = PlotRealToScreenX(pp, vx->v.d);
    ley = PlotRealToScreenY(pp, vy->v.d);
    agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], lex, ley);

    for (i = 2; i < qNbElts(pp->qv);) {
	vx = (Value *) qLookNth(pp->qv, i++);
	vy = (Value *) qLookNth(pp->qv, i++);
	ex = PlotRealToScreenX(pp, vx->v.d);
	ey = PlotRealToScreenY(pp, vy->v.d);
	if (vx->t)
	    agatDrawPoint((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ex, ey);
	else
	    agatDrawBasicLine((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], lex, ley, ex, ey, 0, 0, (pp->xsz), pp->ysz);
	lex = ex;
	ley = ey;
    }
    if (pp->doAxe)
	plotAxes(pp);
    if (qNbElts(pp->qv))
	putMark((AnyClassOp *) pp, pp->pixmap, pp->markGc, ex, ey);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz + 1, pp->ysz + 1, 0, 0);
	XFlush(pp->dpy);
    }
}


void
plot(Plot * pp, Value * vx, Value * vy)
{
    double x, y, psx, psy;
    Boolean ref = False;

    pp->onlyPlot = pp->firstValue;
    x = valToDouble(vx);
    y = valToDouble(vy);
    if (x < pp->minx) {
	if (pp->firstValue)
	    pp->minx = x;
	else
	    pp->minx = EnlargePlot(x, pp->maxx);
	ref = True;
    }
    else if (x > pp->maxx) {
	if (pp->firstValue)
	    pp->maxx = x;
	else
	    pp->maxx = EnlargePlot(x, pp->minx);
	ref = True;
    }
    if (y < pp->miny) {
	if (pp->firstValue)
	    pp->miny = y;
	else
	    pp->miny = EnlargePlot(y, pp->maxy);
	ref = True;
    }
    else if (y > pp->maxy) {
	if (pp->firstValue)
	    pp->maxy = y;
	else
	    pp->maxy = EnlargePlot(y, pp->miny);
	ref = True;
    }
    pp->nbpt++;
    if (!(pp->nbpt % (COMP_QP_NBP / 2)))
	compressQPlot(pp->qv,
		      (Min((pp->maxx - pp->minx) / (double) pp->xusz,
			   (pp->maxy - pp->miny) / (double) pp->yusz)) / 4.0,
		      COMP_QP_NBP, False);
    pp->lx = pp->x;
    pp->ly = pp->y;
    pp->x = x;
    pp->y = y;
    qAdd(pp->qv, convertVal(vx, 0, x));
    qAdd(pp->qv, convertVal(vy, 1, y));
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp);
	    XFlush(pp->dpy);
	}
    }
}


void
plotInt(Plot * pp, Value * vx, Value * vy, Value * reInit)
{
    double x, y, psx, psy;
    Boolean ref = False;

    pp->onlyPlot = pp->firstValue;
    x = valToDouble(vx);
    y = valToDouble(vy);
    if (x < pp->minx) {
	if (pp->firstValue)
	    pp->minx = x;
	else
	    pp->minx = EnlargePlot(x, pp->maxx);
	ref = True;
    }
    else if (x > pp->maxx) {
	if (pp->firstValue)
	    pp->maxx = x;
	else
	    pp->maxx = EnlargePlot(x, pp->minx);
	ref = True;
    }
    if (y < pp->miny) {
	if (pp->firstValue)
	    pp->miny = y;
	else
	    pp->miny = EnlargePlot(y, pp->maxy);
	ref = True;
    }
    else if (y > pp->maxy) {
	if (pp->firstValue)
	    pp->maxy = y;
	else
	    pp->maxy = EnlargePlot(y, pp->miny);
	ref = True;
    }
    pp->nbpt++;

    pp->lx = pp->x;
    pp->ly = pp->y;
    pp->x = x;
    pp->y = y;
    if (evalBool(reInit)) {
	qAdd(pp->qv, convertVal(vx, 1, x));
	qAdd(pp->qv, convertVal(vy, 1, y));
    }
    else {
	qAdd(pp->qv, convertVal(vx, 0, x));
	qAdd(pp->qv, convertVal(vy, 0, y));
    }

    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    if (evalBool(reInit))
		drawPoint(pp);
	    else
		drawSegm(pp);
	    XFlush(pp->dpy);
	}
    }
}


void
plotRestart(Plot * pp, Value * vx, Value * vy, Value * reInit)
{
    if (evalBool(reInit)) {
	qDel(pp->qv, qNbElts(pp->qv), unAllocValue);
	pp->nbpt = 0;
	pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
	pp->scalex = pp->scaley = 1.0;
	pp->firstValue = True;
    }
    unAllocValue(reInit);
    plot(pp, vx, vy);
}



/* eps: epsilon dist between 2 points
 * nbcheck: size of points-chuncks to compare (in term of points)
 * start:   check all points or just the last chunck>
 */
static void
compressQPlot(Queue * qv, double eps, int nbcheck, Bool all)
{
    int nbv, nbp, sval, indqa, indqb;
    int i, j;
    int nbpc = 0;
    Value *pvax, *pvay, *pvbx, *pvby;

    nbv = qNbElts(qv);
    if (all)
	sval = 1;
    else
	sval = Max(1, nbv - 2 * nbcheck + 1);
    while (sval < nbv) {
	nbp = Min((nbv - sval) / 2, nbcheck);
	/* nbp=how many points to check (1pt = 2 values) */
	for (i = 0; i < nbp - 1; i++) {
	    indqa = sval + 2 * i;
	    pvax = qLookNth(qv, indqa);
	    if (!pvax)
		continue;
	    pvay = qLookNth(qv, indqa + 1);

	    for (j = i + 1; j < nbp; j++) {
		indqb = sval + 2 * j;
		pvbx = qLookNth(qv, indqb);
		if (!pvbx)
		    continue;
		pvby = qLookNth(qv, indqb + 1);
		if (SamePt(pvax->v.d, pvay->v.d, pvbx->v.d, pvby->v.d, eps)) {
		    nbpc++;
		    unAllocValue(pvbx);
		    unAllocValue(pvby);
		    qDelNth(qv, indqb);
		    qDelNth(qv, indqb + 1);
		}
	    }
	}
	sval += nbcheck * 2;
    }
    if (nbpc) {
	/*
	 * printf("compressQPlot : %d/%d compression %d remaining \n",
	 * nbpc,nbcheck,qNbElts(qv));
	 */
	qCompactNull(qv);
	nbpc = 0;
    }
}
