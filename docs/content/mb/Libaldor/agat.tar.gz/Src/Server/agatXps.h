#ifndef AGATXPS_H
#define AGATXPS_H
#include "agat.h"


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
void headPs(FILE * fps, AnyClassOp * pc);

void tailPs(FILE * fps);

void x2psColors(AnyClassOp * pc, int *tabCol, RGB * tabRGB, int nbCol);

char *getTokenNum(char *xFont, int nb);

int goodPsSize(int sz);

void x2psFont(AnyClassOp * pc, char *xFont, char *psFont);

/************************************************************ End Prototypes */


#endif
