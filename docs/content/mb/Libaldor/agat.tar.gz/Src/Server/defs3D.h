#ifndef DEFS_H_
#define DEFS_H_
#include "agat.h"

typedef struct ViewStruct {
    double xmin, xmax;
    double ymin, ymax;
    double zmin, zmax;
    double sw;				/* Size of the Window View */
    Matrix4 smR;			/* saved mouse rotation matrix */
    Matrix4 mPer;			/* Perspective Matrix */
    Matrix4 mTot;			/* mvv3dv * vmm * vom */
    Matrix4 vom;			/* View Orientation Matrix */
    Matrix4 vmm;			/* View Mapping Matrix */
    Matrix4 mvv3dv;
    Point3 vrp;				/* View Reference Point */
    Point3 prp;				/* Projection Reference Point */
    Vector3 vpn;			/* View Plane Normal */
    Vector3 vup;			/* View Up Vector */
}          View;

/**************************************************************** Prototypes */

/************************************************************ End Prototypes */



#endif
