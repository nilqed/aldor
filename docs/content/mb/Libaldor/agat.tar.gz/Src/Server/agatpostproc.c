#include "agat.h"

/**************************************************************** Prototypes */


/******************************************************************** Bodies */


/* code of custom functions          */
/* you may add yours ...             */
/* provided you add their prototypes */
/* using addPostProcFunc             */
/* (see below: initPostProcFunc)     */
/* these functions are called each time one ore more of their parameters */
/* (streams) produce a new value. These values are given as parameter to */
/* post-processing functions. If there are some empty streams NULL value */
/* are used.                                                             */
/* Deallocation of values given as parameters is your responsability     */
/* (use unAllocValue or unAllocValueArray)                               */

/* constant arity functions are called with Value * as parameters        */
/* someBinaryFunction( Value *v1, Value *v2)                             */
/* non constant arity functions use a different prtotype:                */
/* someVariableArityFunction( int arity, Value array[arity] )            */


/* a set of very simple post processing functions */

/* print a Value to stdout */

void *
initPrint(HashTable * pht)
{
    InitPar *pip;

    pip = (InitPar *) htSearchKey(pht, "parNames");
    return pip->pe;
}


void
printValue(char **anames, Value * v)
{
    if (v != NULL) {
	printf("%s : ", anames[0]);
	displayValue(v);
    }
    putchar('\n');
    unAllocValue(v);
}

void
printValues(char **anames, int arity, Value ** av)
{
    int i;

    for (i = 0; i < arity; i++) {
	if (av[i] != NULL) {
	    printf("%s : ", anames[i]);
	    displayValue(av[i]);
	    putchar(' ');
	}
    }
    putchar('\n');
    unAllocValueArray(av, arity);
}


void
sleepOne(void *p, int arity, Value ** av)
{
    int z;

    unAllocValueArray(av, arity);
    z = sleep(1);
}


/***********************************************************************/
/* look at that if you want to add some new postprocessing function in */
/* Agat language                                                       */
/***********************************************************************/

void
initPostProcFunc(void)
{
/*
 * No Graphic Operator
 */
    addPostProcFunc("print", 1, ST_NONBLOCKING, (GenericFunc) initPrint, (GenericFunc) printValue);
    addPostProcFunc("prints", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initPrint, (GenericFunc) printValues);
    addPostProcFunc("sleep", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) nullFunc, (GenericFunc) sleepOne);

/*
 * 2D Graphic Operators
 */

/* Histogram-like Operators*/
    addPostProcFunc("thinbar", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initThinbar, (GenericFunc) thinbar);
    addPostProcFunc("thinbaraxe", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initThinbarAxe, (GenericFunc) thinbar);
    addPostProcFunc("plotbar", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initPlotbar, (GenericFunc) thinbar);
    addPostProcFunc("plotbaraxe", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initPlotbarAxe, (GenericFunc) thinbar);
    addPostProcFunc("ratthinbar", VAR_ARITY, ST_BLOCKING, (GenericFunc) initRatThinbar, (GenericFunc) ratThinbar);
    addPostProcFunc("histo", 2, ST_BLOCKING, (GenericFunc) initHisto, (GenericFunc) histo);
    addPostProcFunc("histoaxe", 2, ST_BLOCKING, (GenericFunc) initHistoAxe, (GenericFunc) histo);

/* Plotting Operators*/
    addPostProcFunc("plot", 2, ST_BLOCKING, (GenericFunc) initPlot, (GenericFunc) plot);
    addPostProcFunc("plotaxe", 2, ST_BLOCKING, (GenericFunc) initPlotAxe, (GenericFunc) plot);
    addPostProcFunc("plotline", 2, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plot);
    addPostProcFunc("plotaxeline", 2, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plot);
    addPostProcFunc("plotlineaxe", 2, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plot);
    addPostProcFunc("plotrestart", 3, ST_BLOCKING, (GenericFunc) initPlot, (GenericFunc) plotRestart);
    addPostProcFunc("plotaxerestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxe, (GenericFunc) plotRestart);
    addPostProcFunc("plotlinerestart", 3, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotaxelinerestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotlineaxerestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotlineint", 3, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plotInt);
    addPostProcFunc("plotaxelineint", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotInt);
    addPostProcFunc("plotlineaxeint", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotInt);
/* Box Operators */
    addPostProcFunc("box", 4, ST_BLOCKING, (GenericFunc) initBox, (GenericFunc) box);
    addPostProcFunc("boxaxe", 4, ST_BLOCKING, (GenericFunc) initBoxAxe, (GenericFunc) box);
    addPostProcFunc("boxfill", 4, ST_BLOCKING, (GenericFunc) initBoxFill, (GenericFunc) box);
    addPostProcFunc("boxaxefill", 4, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) box);
    addPostProcFunc("boxfillaxe", 4, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) box);
    addPostProcFunc("boxrestart", 5, ST_BLOCKING, (GenericFunc) initBox, (GenericFunc) boxRestart);
    addPostProcFunc("boxaxerestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxe, (GenericFunc) boxRestart);
    addPostProcFunc("boxfillrestart", 5, ST_BLOCKING, (GenericFunc) initBoxFill, (GenericFunc) boxRestart);
    addPostProcFunc("boxaxefillrestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) boxRestart);
    addPostProcFunc("boxfillaxerestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) boxRestart);
/* Matrix Operators */
    addPostProcFunc("matrix", 2, ST_BLOCKING, (GenericFunc) initMatrix, (GenericFunc) matrix);
    addPostProcFunc("matrixgrid", 2, ST_BLOCKING, (GenericFunc) initMatrixGrid, (GenericFunc) matrix);
    addPostProcFunc("matrixaxe", 2, ST_BLOCKING, (GenericFunc) initMatrixAxe, (GenericFunc) matrix);
    addPostProcFunc("matrixgridaxe", 2, ST_BLOCKING, (GenericFunc) initMatrixAxeGrid, (GenericFunc) matrix);
    addPostProcFunc("matrixaxegrid", 2, ST_BLOCKING, (GenericFunc) initMatrixAxeGrid, (GenericFunc) matrix);

    addPostProcFunc("matrixcol", 3, ST_BLOCKING, (GenericFunc) initMatrixcol, (GenericFunc) matrixCol);
    addPostProcFunc("matrixcolgrid", 3, ST_BLOCKING, (GenericFunc) initMatrixcolGrid, (GenericFunc) matrixCol);
    addPostProcFunc("matrixcolaxe", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxe, (GenericFunc) matrixCol);
    addPostProcFunc("matrixcolaxegrid", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxeGrid, (GenericFunc) matrixCol);
    addPostProcFunc("matrixcolgridaxe", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxeGrid, (GenericFunc) matrixCol);

    addPostProcFunc("matrixval", 3, ST_BLOCKING, (GenericFunc) initMatrixval, (GenericFunc) matrixVal);
    addPostProcFunc("matrixvalgrid", 3, ST_BLOCKING, (GenericFunc) initMatrixvalGrid, (GenericFunc) matrixVal);
    addPostProcFunc("matrixvalaxe", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxe, (GenericFunc) matrixVal);
    addPostProcFunc("matrixvalaxegrid", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxeGrid, (GenericFunc) matrixVal);
    addPostProcFunc("matrixvalgridaxe", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxeGrid, (GenericFunc) matrixVal);

/*
 * 3D Graphic Operators
 */

    addPostProcFunc("plot3d", 3, ST_BLOCKING, (GenericFunc) initPlot3D, (GenericFunc) plot3D);
    addPostProcFunc("plot3dline", 3, ST_BLOCKING, (GenericFunc) initPlotLine3D, (GenericFunc) plot3D);
    addPostProcFunc("plot3dlineint", 4, ST_BLOCKING, (GenericFunc) initPlotLine3D, (GenericFunc) plot3DInt);

/* Shifted Names*/
/* Histogram-like Operators */
    addPostProcFunc("thinBar", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initThinbar, (GenericFunc) thinbar);
    addPostProcFunc("thinBarAxe", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initThinbarAxe, (GenericFunc) thinbar);
    addPostProcFunc("plotBar", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initPlotbar, (GenericFunc) thinbar);
    addPostProcFunc("plotBarAxe", VAR_ARITY, ST_NONBLOCKING, (GenericFunc) initPlotbarAxe, (GenericFunc) thinbar);
    addPostProcFunc("ratThinBar", VAR_ARITY, ST_BLOCKING, (GenericFunc) initRatThinbar, (GenericFunc) ratThinbar);
    addPostProcFunc("histoAxe", 2, ST_BLOCKING, (GenericFunc) initHistoAxe, (GenericFunc) histo);
/* Plotting Operators */
    addPostProcFunc("plotAxe", 2, ST_BLOCKING, (GenericFunc) initPlotAxe, (GenericFunc) plot);
    addPostProcFunc("plotLine", 2, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plot);
    addPostProcFunc("plotAxeLine", 2, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plot);
    addPostProcFunc("plotLineAxe", 2, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plot);
    addPostProcFunc("plotRestart", 3, ST_BLOCKING, (GenericFunc) initPlot, (GenericFunc) plotRestart);
    addPostProcFunc("plotAxeRestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxe, (GenericFunc) plotRestart);
    addPostProcFunc("plotLineRestart", 3, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotAxeLinerestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotLineAxeRestart", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotRestart);
    addPostProcFunc("plotLineInt", 3, ST_BLOCKING, (GenericFunc) initPlotLine, (GenericFunc) plotInt);
    addPostProcFunc("plotAxeLineInt", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotInt);
    addPostProcFunc("plotLineAxeInt", 3, ST_BLOCKING, (GenericFunc) initPlotAxeLine, (GenericFunc) plotInt);
/* Box Operators */
    addPostProcFunc("boxAxe", 4, ST_BLOCKING, (GenericFunc) initBoxAxe, (GenericFunc) box);
    addPostProcFunc("boxFill", 4, ST_BLOCKING, (GenericFunc) initBoxFill, (GenericFunc) box);
    addPostProcFunc("boxAxeFill", 4, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) box);
    addPostProcFunc("boxFillAxe", 4, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) box);
    addPostProcFunc("boxRestart", 5, ST_BLOCKING, (GenericFunc) initBox, (GenericFunc) boxRestart);
    addPostProcFunc("boxAxeRestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxe, (GenericFunc) boxRestart);
    addPostProcFunc("boxFillRestart", 5, ST_BLOCKING, (GenericFunc) initBoxFill, (GenericFunc) boxRestart);
    addPostProcFunc("boxAxeFillRestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) boxRestart);
    addPostProcFunc("boxFillAxeRestart", 5, ST_BLOCKING, (GenericFunc) initBoxAxeFill, (GenericFunc) boxRestart);
/* Matrix Operators */
    addPostProcFunc("matrixGrid", 2, ST_BLOCKING, (GenericFunc) initMatrixGrid, (GenericFunc) matrix);
    addPostProcFunc("matrixAxe", 2, ST_BLOCKING, (GenericFunc) initMatrixAxe, (GenericFunc) matrix);
    addPostProcFunc("matrixGridAxe", 2, ST_BLOCKING, (GenericFunc) initMatrixAxeGrid, (GenericFunc) matrix);
    addPostProcFunc("matrixAxeGrid", 2, ST_BLOCKING, (GenericFunc) initMatrixAxeGrid, (GenericFunc) matrix);

    addPostProcFunc("matrixCol", 3, ST_BLOCKING, (GenericFunc) initMatrixcol, (GenericFunc) matrixCol);
    addPostProcFunc("matrixColGrid", 3, ST_BLOCKING, (GenericFunc) initMatrixcolGrid, (GenericFunc) matrixCol);
    addPostProcFunc("matrixColAxe", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxe, (GenericFunc) matrixCol);
    addPostProcFunc("matrixColAxeGrid", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxeGrid, (GenericFunc) matrixCol);
    addPostProcFunc("matrixColGridAxe", 3, ST_BLOCKING, (GenericFunc) initMatrixcolAxeGrid, (GenericFunc) matrixCol);

    addPostProcFunc("matrixVal", 3, ST_BLOCKING, (GenericFunc) initMatrixval, (GenericFunc) matrixVal);
    addPostProcFunc("matrixValGrid", 3, ST_BLOCKING, (GenericFunc) initMatrixvalGrid, (GenericFunc) matrixVal);
    addPostProcFunc("matrixValAxe", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxe, (GenericFunc) matrixVal);
    addPostProcFunc("matrixValAxeGrid", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxeGrid, (GenericFunc) matrixVal);
    addPostProcFunc("matrixValGridAxe", 3, ST_BLOCKING, (GenericFunc) initMatrixvalAxeGrid, (GenericFunc) matrixVal);

    addPostProcFunc("plot3D", 3, ST_BLOCKING, (GenericFunc) initPlot3D, (GenericFunc) plot3D);
    addPostProcFunc("plot3DLine", 3, ST_BLOCKING, (GenericFunc) initPlotLine3D, (GenericFunc) plot3D);
    addPostProcFunc("plot3DLineInt", 4, ST_BLOCKING, (GenericFunc) initPlotLine3D, (GenericFunc) plot3DInt);

}
