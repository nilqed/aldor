#include "agat.h"

#define ENLARG_RAT 0.1
#define EnlargePlot3D(x,y) ((x)+ENLARG_RAT*((x)-(y)))
#define XTICKS_MAXSTEP 10
#define X_AXE 1


#define Y_AXE 2
#define Z_AXE 3
#define SW_AXE(axe,x,y) (((axe)==X_AXE)?(x):(y))


#define SamePt(xa,ya,xb,yb,eps) ((Abs((xa)-(xb))<(eps))&&((Abs((ya)-(yb))<(eps))))

/**************************************************************** Prototypes */

static void putMark(AnyClassOp * pc, Window win, GC gc, int ex, int ey);
static void drawSegm3D(Plot3D * pp);
static void drawPoint3D(Plot3D * pp);
static void plot3DResize(Plot3D * pp, int x, int y);
static void plot3DCoord(Plot3D * pp, int x, int y, int rx, int ry, Window win, int First);
static void plotMouse3D(Plot3D * pp);
static void plot3DZoom(Plot3D * pp, int x1, int y1, int x2, int y2);
static void plot3DPS(Plot3D * pp, int x, int y);
static Plot3D *initPlot3DAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*m3d) (), void (*pps) (), Boolean doAxe, char *name);

/*
static void     plot3DOneAxe(Plot3D * pp, int axe)
{
    int             posAxe;
    if ((pp->minx == pp->maxx) || (pp->miny == pp->maxy))
	return;
    findAxe(pp, &posAxe, axe);
    if (axe == Y_AXE) {
	agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe, 0, posAxe, pp->ysz);
	plot3DYTicks(pp, posAxe);
    }
    else {
	agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, 0, posAxe, pp->xsz, posAxe);
	plot3DXTicks(pp, posAxe);
    }
}
*/
static void plot3DAxes(Plot3D * pp);
static void plot3DRefresh(Plot3D * pp);
static void plot3DLineRefresh(Plot3D * pp);

/******************************************************************** Bodies */

void
Plot3DRealToScreen(Plot3D * pp, Point3 * ppt, int *x, int *y)
{
    Point3 pOut;

    V3MulPointByProjMatrix(ppt, &((pp->vw).mTot), &pOut);
    *x = (int) pOut.x;
    *y = (int) pOut.y;
}

static void
putMark(AnyClassOp * pc, Window win, GC gc, int ex, int ey)
{
    agatDrawLine(pc, win, gc, ex - 5, ey, ex + 5, ey);
    agatDrawLine(pc, win, gc, ex, ey - 5, ex, ey + 5);
}


static void
drawSegm3D(Plot3D * pp)
{
    int ex, ey, lex, ley;

    Window *tmpWin;

    Plot3DRealToScreen(pp, &(pp->lp), &lex, &ley);
    Plot3DRealToScreen(pp, &(pp->p), &ex, &ey);

    if (pp->onlyPlot3D)
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], ex, ey);
    else {
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, lex, ley);

	agatDrawBasicLine((AnyClassOp *) pp, pp->win, pp->drawGcs[0], lex, ley, ex, ey, 0, 0, pp->xsz, pp->ysz);
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, ex, ey);
    }
}

static void
drawPoint3D(Plot3D * pp)
{
    int ex, ey, lex, ley;

    Plot3DRealToScreen(pp, &(pp->lp), &lex, &ley);
    Plot3DRealToScreen(pp, &(pp->p), &ex, &ey);
    if (!pp->onlyPlot3D) {
	putMark((AnyClassOp *) pp, pp->win, pp->markGc, lex, ley);
	agatDrawPoint((AnyClassOp *) pp, pp->win, pp->drawGcs[0], lex, ley);
    }
    putMark((AnyClassOp *) pp, pp->win, pp->markGc, ex, ey);
    XFlush(pp->dpy);
}


static void
plot3DResize(Plot3D * pp, int x, int y)
{
    Point3 *pt;
    int i, nbe;
    double maxx, maxy, maxz, minx = 0, miny = 0, minz = 0;


    if (x <= 0)
	x = 1;
    if (y <= 0)
	y = 1;
    pp->xsz = x;
    pp->ysz = y;
    pp->xusz = x - pp->xm * 2;
    pp->yusz = y - pp->ym * 2;

    if (qNbElts(pp->qv)) {
	pt = (Point3 *) qLookNth(pp->qv, 0);
	if (pt == NULL)
	    pt = (Point3 *) qLookNth(pp->qv, 1);
	maxx = pt->x;
	maxy = pt->y;
	maxz = pt->z;
	maxx = NonNull(minx, maxx);
	minx = maxx - 1.0e-10;
	maxy = NonNull(miny, maxy);
	miny = maxy - 1.0e-10;
	maxz = NonNull(minz, maxz);
	minz = maxz - 1.0e-10;
	nbe = qNbElts(pp->qv);
	for (i = 2; i < nbe;) {
	    pt = (Point3 *) qLookNth(pp->qv, i++);
	    if (pt == NULL)
		pt = (Point3 *) qLookNth(pp->qv, i++);
	    if (pt->x > maxx)
		maxx = pt->x;
	    else if (pt->x < minx)
		minx = pt->x;

	    if (pt->y > maxy)
		maxy = pt->y;
	    else if (pt->y < miny)
		miny = pt->y;

	    if (pt->z > maxz)
		maxz = pt->z;
	    else if (pt->z < minz)
		minz = pt->z;
	}
	pp->maxx = maxx;
	pp->minx = minx;
	pp->maxy = maxy;
	pp->miny = miny;
	pp->maxz = maxz;
	pp->minz = minz;
	ChangeBb(&(pp->vw), pp->minx, pp->maxx, pp->miny, pp->maxy, pp->minz, pp->maxz);
/*        init3D(&(pp->vw), pp->minx, pp->maxx, pp->miny, pp->maxy, pp->minz, pp->maxz, &((pp->vw).vrp), &((pp->vw).vup));*/

	XFreePixmap(pp->dpy, pp->pixmap);
	pp->pixmap = XCreatePixmap(pp->dpy, pp->win, x, y, DefaultDepth(pp->dpy, DefaultScreen(pp->dpy)));
    }
}


static void
plot3DCoord(Plot3D * pp, int x, int y, int rx, int ry, Window win, int First)
{
#define MARG_H 5
#define MARG_W 10
#define MARG_PT_X 10
#define MARG_PT_Y 10

    char tmp[100];
    static int size = 0;
    XEvent event_return;


    sprintf(tmp, "Not yet implemented");
    XSynchronize(pp->dpy, True);
    XMoveWindow(pp->dpy, win, rx + MARG_PT_X, ry + MARG_PT_Y);
    if (size != strlen(tmp) || First) {
	XResizeWindow(pp->dpy, win, MARG_W + strlen(tmp) * pp->fontWidth,
		      pp->fontHeight + MARG_H * 2);
	XWindowEvent(pp->dpy, win, ExposureMask, &event_return);
    }
    size = strlen(tmp);
    XClearWindow(pp->dpy, win);
    agatDrawString((AnyClassOp *) pp, win, pp->textGc, MARG_W, MARG_H + pp->fontHeight, tmp, strlen(tmp));
    XFlush(pp->dpy);
    XSynchronize(pp->dpy, False);
}


static void
plotMouse3D(Plot3D * pp)
{
    moveMouse3D((AnyClassOp3D *) pp, &(pp->vw));
}


static void
plot3DZoom(Plot3D * pp, int x1, int y1, int x2, int y2)
{
/*    Plot3D           *newpp;
    RDataBase       initRDB;

    newpp = (Plot3D *)UZalloc(sizeof(Plot3D));
    *newpp = *pp;
    newpp->type = ZOOM_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen("zoom") + 1));
    strcpy(pp->name, "zoom");
    newpp->minx = Plot3DScreenToRealX(pp, x1);
    newpp->maxy = Plot3DScreenToRealY(pp, y1);
    newpp->maxx = Plot3DScreenToRealX(pp, x2);
    newpp->miny = Plot3DScreenToRealY(pp, y2);
    extractDB(0, NULL, pp->dpy, "zoom", &initRDB);
    newpp->xsz = initRDB.xsz;
    newpp->ysz = initRDB.ysz;
    newpp->xm = initRDB.xm;
    newpp->ym = initRDB.ym;
    newpp->xusz = newpp->xsz - newpp->xm * 2;
    newpp->yusz = newpp->ysz - newpp->ym * 2;

    createFirstWindow(&newpp->dpy,&newpp->win, &newpp->pixmap, newpp->xsz, newpp->ysz, &initRDB);
    addXwin(newpp->dpy, newpp->win, ZOOM_WINDOW, newpp->refresh, newpp->resize,
            newpp->coord, newpp->szoom, newpp->zoom, newpp->m3d, newpp->pps, newpp);
    XStoreName(newpp->dpy,newpp->win,"zoom");
    mapWindow(newpp->dpy, newpp->win, &initRDB);
*/
}


static void
plot3DPS(Plot3D * pp, int x, int y)
{
    RDataBase initRDB;
    int tabCol[NB_MAX_COLOR + 3];
    char *buffer = NULL, *file[255];
    int i;

    extractDB(0, NULL, pp->dpy, buffer, &initRDB);	/* ?? */
    pp->ps = True;
    XFetchName(pp->dpy, pp->win, file);
    if (*file != NULL) {
	pp->fps = fopen(*file, "w");
	if (pp->fps != NULL) {
	    headPs(pp->fps, (AnyClassOp *) pp);

	    pp->tabRGB = (RGB *) UZalloc(sizeof(RGB) * (NB_MAX_COLOR + 3));	/* +Back,Text,Mark */
	    tabCol[0] = initRDB.fg;
	    tabCol[1] = initRDB.bg;
	    tabCol[2] = initRDB.markcolor;
	    for (i = 3; i < (NB_MAX_COLOR + 3); i++)
		tabCol[i] = initRDB.tabColor[i - 3];

	    x2psColors((AnyClassOp *) pp, tabCol, pp->tabRGB, (NB_MAX_COLOR + 3));

	    (*(pp->refresh)) (pp);
	    tailPs(pp->fps);
	    fclose(pp->fps);
	}
	else
	    fprintf(stderr, "Can't open file !\n");
    }
    pp->ps = False;
}


static Plot3D *initPlot3DAux(HashTable * pht, void (*ref) (), void (*res) (), void (*draw) (), void (*coord) (), void (*szoom) (), void (*zoom) (), void (*m3d) (), void (*pps) (), Boolean doAxe, char *name) {
    Plot3D *pp;
    InitPar *pip;
    Display *dpy;
    char *buffer = NULL;
    RDataBase initRDB;
    Point3 ovrp, ovup;

    dpy = openDisplayOnlyOne();
    pp = (Plot3D *) UZalloc(sizeof(Plot3D));
    pip = (InitPar *) htSearchKey(pht, "parNames");
    buffer = giveStreamTitle(pip->pe, name);
    extractDB(0, NULL, dpy, buffer, &initRDB);

    pp->type = PLOT3D_WINDOW;
    pp->name = (char *) UZalloc(sizeof(char) * (strlen(buffer) + 1));
    strcpy(pp->name, buffer);
    pp->iconified = False;		/* ?? */
    pp->killed = False;
    pp->ps = False;
    pp->xsz = initRDB.xsz;
    pp->ysz = initRDB.ysz;
    pp->xm = initRDB.xm;
    pp->ym = initRDB.ym;
    pp->xusz = pp->xsz - pp->xm * 2;
    pp->yusz = pp->ysz - pp->ym * 2;
    createFirstWindow(&pp->dpy, &pp->win, &pp->pixmap, pp->xsz, pp->ysz, &initRDB);

    pp->backGc = createBackGc(pp->dpy, pp->win, initRDB.bg);
    pp->textGc = createTextGc(pp->dpy, pp->win, initRDB.font, initRDB.fg,
			      &pp->fontWidth, &pp->fontHeight);
    pp->font = (char *) UZalloc(sizeof(char) * (strlen(initRDB.font) + 1));
    strcpy(pp->font, initRDB.font);
    addXwin(pp->dpy, pp->win, pp->type, ref, res, coord, szoom, zoom, m3d, pps, pp);
    appNameClass(pp->dpy, pp->win);
    XStoreName(pp->dpy, pp->win, buffer);
    pp->drawGcs = createGcs(pp->dpy, pp->win, initRDB.tabColor, 2);
    pp->markGc = createXorColorGc(pp->dpy, pp->win, initRDB.markcolor);
    pp->qv = qCreate(nullFunc);
    pp->nbpt = 0;
    pp->maxx = pp->maxy = pp->maxz = pp->minx = pp->miny = pp->minz = 0.0;
    pp->scalex = pp->scaley = pp->scalez = 1.0;
    V3FillPoint(&ovrp, 20, 0, 0);
    V3FillPoint(&ovup, 0, 0, 1);
    init3D(&(pp->vw), pp->minx, pp->maxx, pp->miny, pp->maxy, pp->minz, pp->maxz, &ovrp, &ovup);

    pp->firstValue = True;
    pp->draw = draw;
    pp->resize = res;
    pp->refresh = ref;
    pp->coord = coord;
    pp->szoom = szoom;
    pp->zoom = zoom;
    pp->m3d = m3d;
    pp->pps = pps;
    pp->doAxe = doAxe;
    mapWindow(pp->dpy, pp->win, &initRDB);
    if (pp->iconified) {
	XIconifyWindow(pp->dpy, pp->win, DefaultScreen(dpy));
	XFlush(pp->dpy);
    }
    return pp;
}

void *
initPlot3D(HashTable * pht)
{
    return initPlot3DAux(pht, plot3DRefresh, plot3DResize, drawPoint3D, plot3DCoord, selectRect, plot3DZoom, plotMouse3D, plot3DPS, False, "plot3D");
}

void *
initPlotLine3D(HashTable * pht)
{
    return initPlot3DAux(pht, plot3DLineRefresh, plot3DResize, drawSegm3D, plot3DCoord, selectRect, plot3DZoom, plotMouse3D, plot3DPS, False, "plot3D");
}

/*
static void     findAxe(Plot3D * pp, int *pve, int axe)
{
    double          minv, maxv, scalev;
    double          v;

    if (axe == Y_AXE) {
	minv = pp->minx;
	maxv = pp->maxx;
	scalev = pp->scalex;
    }
    else {
	minv = pp->miny;
	maxv = pp->maxy;
	scalev = pp->scaley;
    }
    v = Min(Max(minv, 0.0), maxv);
    if (axe == Y_AXE) {
	v = Plot3DRealToScreenX(pp, v);
	*pve = (int) Min(pp->xsz, Max(0, v));
    }
    else {
	v = Plot3DRealToScreenY(pp, v);
	*pve = (int) Min(pp->ysz, Max(0, v));

    }
}
*/
/*
static void     plot3DXTicks(Plot3D * pp, int posAxe)
{
    int             nbTicks, i, j, x, y, nbTotCar, nbLabCar, maxc, tmp;
    double         *aTicks;
    char          **aLabs;
    Bool            reduced = False;

    nbTicks = buildXTicksLabs(pp->xsz, pp->fontWidth, pp->minx, pp->maxx,
                              XTICKS_HRATIO, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	x = Plot3DRealToScreenX(pp, aTicks[i]);
	if ((pp->ysz - posAxe) < (pp->fontHeight + 2)) {
	    /* put labels over X axe *
	    agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, x, posAxe + 1, x, posAxe - XPLOT3D_TICKSIZE);
	    agatDrawString((AnyClassOp *)pp, pp->pixmap, pp->textGc, x + 2, posAxe - 2, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* put labels under X axe *
	    agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, x, posAxe - 1, x, posAxe + XPLOT3D_TICKSIZE);
	    agatDrawString((AnyClassOp *)pp, pp->pixmap, pp->textGc, x + 2, posAxe + (pp->fontHeight + 2), aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}
*/
/*
static void     plot3DYTicks(Plot3D * pp, int posAxe)
{
    int             nbTicks, i, j, x, y, nbLabCar;
    double         *aTicks;
    char          **aLabs;

    nbTicks = buildYTicksLabs(pp->xsz, pp->ysz, pp->fontHeight, pp->fontWidth,
                              pp->miny, pp->maxy, YTICKS_NB_CARMIN,
                              YTICKS_VRATIO, YTICKS_HRATIO, & nbLabCar, &aTicks, &aLabs);

    for (i = 0; i < nbTicks; i++) {
	y = Plot3DRealToScreenY(pp, aTicks[i]);
	if ((pp->xsz - posAxe) < (pp->fontWidth * (nbLabCar + 1))) {
	    /* axe is near the right border of window *
	    /* so plot3D ticks and labels to the left of axe *
	    agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe + 1, y, posAxe - XPLOT3D_TICKSIZE, y);
	    agatDrawString((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe - (pp->fontWidth * (strlen(aLabs[i]) + 1)), y, aLabs[i], strlen(aLabs[i]));
	}
	else {
	    /* all is right *
	    agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe - 1, y, posAxe + XPLOT3D_TICKSIZE, y);
	    agatDrawString((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe + (pp->fontWidth), y, aLabs[i], strlen(aLabs[i]));
	}
    }
    free(aLabs);
    free(aTicks);
}
*/
/*
static void     plot3DOneAxe(Plot3D * pp, int axe)
{
    int             posAxe;

    if ((pp->minx == pp->maxx) || (pp->miny == pp->maxy))
	return;
    findAxe(pp, &posAxe, axe);
    if (axe == Y_AXE) {
	agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, posAxe, 0, posAxe, pp->ysz);
	plot3DYTicks(pp, posAxe);
    }
    else {
	agatDrawLine((AnyClassOp *)pp, pp->pixmap, pp->textGc, 0, posAxe, pp->xsz, posAxe);
	plot3DXTicks(pp, posAxe);
    }
}
*/

static void
plot3DAxes(Plot3D * pp)
{
/*    plot3DOneAxe(pp, X_AXE);
    plot3DOneAxe(pp, Y_AXE);*/
    fprintf(stderr, "No Axe Display for 3D yet !! \n");
}


static void
plot3DRefresh(Plot3D * pp)
{
    int ex, ey, i, nbe;
    Point3 *pt;

    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz, pp->ysz);
    if (pp->firstValue) {
	pp->maxx = NonNull(pp->minx, pp->maxx);
	pp->minx = pp->maxx - 1.0e-10;
	pp->maxy = NonNull(pp->miny, pp->maxy);
	pp->miny = pp->maxy - 1.0e-10;
	pp->maxz = NonNull(pp->minz, pp->maxz);
	pp->minz = pp->maxz - 1.0e-10;
	pp->firstValue = False;
	init3D(&(pp->vw), pp->minx, pp->maxx, pp->miny, pp->maxy, pp->minz, pp->maxz, &((pp->vw).vrp), &((pp->vw).vup));
    }
/*    compressQPlot3D(pp->qv,
		  (Min((pp->maxx - pp->minx) / (double) pp->xusz,
		       (pp->maxy - pp->miny) / (double) pp->yusz)) / 4.0,
		  COMP_QP_NBP / 1.5, True);
*/
    pp->scalex = ((double) pp->xusz) / (pp->maxx - pp->minx);	/* ?? todel */
    pp->scaley = ((double) pp->yusz) / (pp->maxy - pp->miny);
    moveVRP((AnyClassOp3D *) pp);
    evaluateViewRepresentation(&(pp->vw), (AnyClassOp3D *) pp, &(pp->vw.vrp), &(pp->vw.vup), 1, 1, 1);
    nbe = qNbElts(pp->qv);
    for (i = 0; i < nbe;) {
	pt = (Point3 *) qLookNth(pp->qv, i++);
	Plot3DRealToScreen(pp, pt, &ex, &ey);
	agatDrawPoint((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ex, ey);
    }
    if (qNbElts(pp->qv))
	putMark((AnyClassOp *) pp, pp->pixmap, pp->markGc, ex, ey);
    if (pp->doAxe)
	plot3DAxes(pp);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz, pp->ysz, 0, 0);
	XFlush(pp->dpy);
    }
}


static void
plot3DLineRefresh(Plot3D * pp)
{
    int ex, ey, lex, ley;
    int i, nbe;
    Point3 *ppt;

    if (qNbElts(pp->qv) < 2)
	return;
    if (!pp->ps)
	XFillRectangle(pp->dpy, pp->pixmap, pp->backGc, 0, 0, pp->xsz, pp->ysz);
    if (pp->firstValue) {
	pp->maxx = NonNull(pp->minx, pp->maxx);
	pp->minx = pp->maxx - 1.0e-10;
	pp->maxy = NonNull(pp->miny, pp->maxy);
	pp->miny = pp->maxy - 1.0e-10;
	pp->maxz = NonNull(pp->minz, pp->maxz);
	pp->minz = pp->maxz - 1.0e-10;
	pp->firstValue = False;
	init3D(&(pp->vw), pp->minx, pp->maxx, pp->miny, pp->maxy, pp->minz, pp->maxz, &((pp->vw).vrp), &((pp->vw).vup));
    }
    pp->scalex = ((double) pp->xusz) / (pp->maxx - pp->minx);
    pp->scaley = ((double) pp->yusz) / (pp->maxy - pp->miny);
    moveVRP((AnyClassOp3D *) pp);
    evaluateViewRepresentation(&(pp->vw), (AnyClassOp3D *) pp, &(pp->vw.vrp), &(pp->vw.vup), 1, 1, 1);

    nbe = qNbElts(pp->qv);
    for (i = 0; i < nbe - 1;) {
	ppt = (Point3 *) qLookNth(pp->qv, i++);
	if ((ppt == NULL) || (i == 1)) {/* interupt in lines or first point */
	    ppt = (Point3 *) qLookNth(pp->qv, i++);
	    Plot3DRealToScreen(pp, ppt, &ex, &ey);
	    agatDrawPoint((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], ex, ey);
	}
	else {
	    Plot3DRealToScreen(pp, ppt, &ex, &ey);
	    agatDrawBasicLine((AnyClassOp *) pp, pp->pixmap, pp->drawGcs[0], lex, ley, ex, ey, 0, 0, (pp->xsz), pp->ysz);
	}
	lex = ex;
	ley = ey;
    }
    if (pp->doAxe)
	plot3DAxes(pp);
    if (qNbElts(pp->qv))
	putMark((AnyClassOp *) pp, pp->pixmap, pp->markGc, ex, ey);
    if (!pp->ps) {
	XCopyArea(pp->dpy, pp->pixmap, pp->win, pp->backGc, 0, 0, pp->xsz, pp->ysz, 0, 0);
	XFlush(pp->dpy);
    }
}


void
plot3D(Plot3D * pp, Value * vx, Value * vy, Value * vz)
{
    double x, y, z, psx, psy;
    Boolean ref = False;
    Point3 *ppt;

    pp->onlyPlot3D = pp->firstValue;
    x = valToDouble(vx);
    y = valToDouble(vy);
    z = valToDouble(vz);

    if (x < pp->minx) {
	if (pp->firstValue)
	    pp->minx = x;
	else
	    pp->minx = EnlargePlot3D(x, pp->maxx);
	ref = True;
    }
    else if (x > pp->maxx) {
	if (pp->firstValue)
	    pp->maxx = x;
	else
	    pp->maxx = EnlargePlot3D(x, pp->minx);
	ref = True;
    }
    if (y < pp->miny) {
	if (pp->firstValue)
	    pp->miny = y;
	else
	    pp->miny = EnlargePlot3D(y, pp->maxy);
	ref = True;
    }
    else if (y > pp->maxy) {
	if (pp->firstValue)
	    pp->maxy = y;
	else
	    pp->maxy = EnlargePlot3D(y, pp->miny);
	ref = True;
    }
    if (z < pp->minz) {
	if (pp->firstValue)
	    pp->minz = z;
	else
	    pp->minz = EnlargePlot3D(z, pp->maxz);
	ref = True;
    }
    else if (z > pp->maxz) {
	if (pp->firstValue)
	    pp->maxz = z;
	else
	    pp->maxz = EnlargePlot3D(z, pp->minz);
	ref = True;
    }
    pp->nbpt++;
/*    if (!(pp->nbpt % (COMP_QP_NBP / 2)))
	compressQPlot3D(pp->qv,
		      (Min((pp->maxx - pp->minx) / (double) pp->xusz,
			   (pp->maxy - pp->miny) / (double) pp->yusz)) / 4.0,
		      COMP_QP_NBP, False);*/
    V3CopyPoint(&(pp->p), &(pp->lp));
    V3FillPoint(&(pp->p), x, y, z);
    ppt = (Point3 *) UZalloc(sizeof(Point3));
    V3FillPoint(ppt, x, y, z);
    qAdd(pp->qv, ppt);
    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    pp->draw(pp);
	    XFlush(pp->dpy);
	}
    }
}


void
plot3DInt(Plot3D * pp, Value * vx, Value * vy, Value * vz, Value * reInit)
{
    double x, y, z, psx, psy;
    Boolean ref = False;
    Point3 *ppt;

    pp->onlyPlot3D = pp->firstValue;
    x = valToDouble(vx);
    y = valToDouble(vy);
    z = valToDouble(vz);
    if (x < pp->minx) {
	if (pp->firstValue)
	    pp->minx = x;
	else
	    pp->minx = EnlargePlot3D(x, pp->maxx);
	ref = True;
    }
    else if (x > pp->maxx) {
	if (pp->firstValue)
	    pp->maxx = x;
	else
	    pp->maxx = EnlargePlot3D(x, pp->minx);
	ref = True;
    }
    if (y < pp->miny) {
	if (pp->firstValue)
	    pp->miny = y;
	else
	    pp->miny = EnlargePlot3D(y, pp->maxy);
	ref = True;
    }
    else if (y > pp->maxy) {
	if (pp->firstValue)
	    pp->maxy = y;
	else
	    pp->maxy = EnlargePlot3D(y, pp->miny);
	ref = True;
    }
    if (z < pp->minz) {
	if (pp->firstValue)
	    pp->minz = z;
	else
	    pp->minz = EnlargePlot3D(z, pp->maxz);
	ref = True;
    }
    else if (z > pp->maxz) {
	if (pp->firstValue)
	    pp->maxz = z;
	else
	    pp->maxz = EnlargePlot3D(y, pp->minz);
	ref = True;
    }
    pp->nbpt++;

    V3CopyPoint(&(pp->p), &(pp->lp));
    V3FillPoint(&(pp->p), x, y, z);
    ppt = (Point3 *) UZalloc(sizeof(Point3));
    V3FillPoint(ppt, x, y, z);

    if (!evalBool(reInit)) {
	qAdd(pp->qv, ppt);
    }
    else {
	qAdd(pp->qv, NULL);
	qAdd(pp->qv, ppt);
/*        qAdd(pp->qv, convertVal(vx, 0, x));
        qAdd(pp->qv, convertVal(vy, 0, y));*/
    }

    if (!pp->iconified) {
	if (ref == True) {
	    pp->refresh(pp);
	}
	else {
	    if (evalBool(reInit))
		drawPoint3D(pp);
	    else
		drawSegm3D(pp);
	    XFlush(pp->dpy);
	}
    }
}

/*
void            plot3DRestart(Plot3D * pp, Value * vx, Value * vy, Value * reInit)
{
    if (evalBool(reInit)) {
	qDel(pp->qv, qNbElts(pp->qv), unAllocValue);
	pp->nbpt = 0;
	pp->maxx = pp->maxy = pp->minx = pp->miny = 0.0;
	pp->scalex = pp->scaley = 1.0;
	pp->firstValue = True;
    }
    unAllocValue(reInit);
    plot3D(pp, vx, vy);
}
*/


/**/
/* eps: epsilon dist between 2 points */
/* nbcheck: size of points-chuncks to compare (in term of points) */
/* start:   check all points or just the last chunck> */

/*
static void     compressQPlot3D(Queue * qv, double eps, int nbcheck, Bool all)
{
    int             nbv, nbp, sval, indqa, indqb;
    int             i, j;
    int             nbpc = 0;
    Value          *pvax, *pvay, *pvbx, *pvby;

    nbv = qNbElts(qv);
    if (all)
	sval = 1;
    else
	sval = Max(1, nbv - 2 * nbcheck + 1);
    while (sval < nbv) {
	nbp = Min((nbv - sval) / 2, nbcheck);
	/* nbp=how many points to check (1pt = 2 values) *
	for (i = 0; i < nbp - 1; i++) {
	    indqa = sval + 2 * i;
	    pvax = qLookNth(qv, indqa);
	    if (!pvax)
		continue;
	    pvay = qLookNth(qv, indqa );

	    for (j = i + 1; j < nbp; j++) {
		indqb = sval + 2 * j;
		pvbx = qLookNth(qv, indqb);
		if (!pvbx)
		    continue;
		pvby = qLookNth(qv, indqb + 1);
		if (SamePt(pvax->v.d, pvay->v.d, pvbx->v.d, pvby->v.d, eps)) {
		    nbpc++;
		    unAllocValue(pvbx);
		    unAllocValue(pvby);
		    qNullNb(qv, indqb);
		    qNullNb(qv, indqb + 1);
		}
	    }
	}
	sval += nbcheck * 2;
    }
    if (nbpc) {
	/*
	 * printf("compressQPlot3D : %d/%d compression %d remaining \n",
	 * nbpc,nbcheck,qNbElts(qv));
	 *
	qCompactNull(qv);
	nbpc = 0;
    }
}
*/
