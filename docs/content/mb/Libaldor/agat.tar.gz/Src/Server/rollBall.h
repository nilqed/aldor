#ifndef ROLLBALL_H
#define ROLLBALL_H
#include "agat.h"


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
Matrix4 *matBallRot(double cos_theta, double sin_theta, Point3 * n, Matrix4 * rm);

void ModifyView(View * vw, int dx, int dy, Matrix4 * matRet);

/************************************************************ End Prototypes */


#endif
