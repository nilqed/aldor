#ifndef AGATXBOX_H
#define AGATXBOX_H
#include "agat.h"

/* size of ticks mark */
#define XBOX_TICKSIZE 6

/* for Y labels */
/* no y label with less than this lenght */
#define YTICKS_NB_CARMIN 8
/* what part of the screen must be covered by y labels */
/* YTICKS_VRATIO == 5 -> 1/5 of screen height is used for label print */
/* YTICKS_HRATIO == 8 -> 1/8 of screen widht is  used for label print */
#define YTICKS_VRATIO 4
#define YTICKS_HRATIO 8

/* for X labels */
/* no x label with less than this lenght */
#define XTICKS_NB_CARMIN 8
/* a kind of default value for number of ticks */
#define NB_X_TICKS 4
/* what part of the screen must be covered by X labels */
#define XTICKS_HRATIO 1.2


/* number of points checked for compression */
#define COMP_QP_NBP 50

typedef struct Box {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;				/* To respect AnyClass */
    RGB *tabRGB;
    int fontHeight, fontWidth;
    int xsz, ysz;			/* window size */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    Queue *qv;				/* values plotted */
    int nbpt;				/* nb points */
    double minx, maxx, miny, maxy;	/* values extrema */
    double scalex, scaley;		/* scaling factors */
    double ulx, uly, lrx, lry;		/* box coords */
    Boolean firstValue;			/* is this the first point ? */
    Boolean onlyShape;			/* filled box or only shape? */
    void (*draw) ();
    void (*resize) ();
    void (*refresh) ();
    void (*coord) ();
    void (*szoom) ();
    void (*zoom) ();
    void (*pps) ();
    Boolean doAxe;			/* must we do the axes ? */
}   Box;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
double BoxRealToScreenX(Box * pp, double x);

double BoxRealToScreenY(Box * pp, double y);

void *initBoxAxe(HashTable * pht);

void *initBox(HashTable * pht);

void *initBoxAxeFill(HashTable * pht);

void *initBoxFill(HashTable * pht);

void box(Box * pp, Value * vulx, Value * vuly, Value * vlrx, Value * vlry);

void boxRestart(Box * pp, Value * vulx, Value * vuly, Value * vlrx, Value * vlry, Value * reInit);

/************************************************************ End Prototypes */


#endif
