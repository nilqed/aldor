#ifndef AGATCHECK_H
#define AGATCHECK_H
#include "agat.h"


/* the maximum number of errors before aborting */
#define MAX_ERROR_BEF_ABORT   20

/* size of chunks used during funProtos building (reallocation size) */
#define FP_CHKSZ 20
/* and postProcs building */
#define PP_CHKSZ 20

/* size of the hash-table used for include names storage */
#define HT_INC_SZ          20
#define HT_CONST_SZ        50
#define HT_MACRO_SZ        50
#define HT_STREAM_SZ       50
#define HT_FUNC_SZ         50
#define HT_POSTPROCFUNC_SZ 20

extern FADef *allDef;
extern List *lIncludePath;
extern HashTable *htInclude;
extern HashTable *htConst;
extern HashTable *htMacro;
extern HashTable *htStream;
extern HashTable *htFunc;
extern PostProc *postProcs;
extern int postProcsNb;
extern Boolean silentWarn;

/**************************************************************** Prototypes */


/* static */
void *keyIncDesc(IncDesc * p1);

/* static */
void *keyConstDesc(ConstDesc * p1);

/* static */
void *keyMacroDesc(MacroDesc * p1);

/* static */
void *keyStreamDesc(StreamDesc * p1);

/* static */
void *keyFuncDesc(FuncDesc * p1);

void parseError(char *msg);

void checkError(char *file, int lgn, char *msg);

void checkWarning(char *file, int lgn, char *msg);

void addFunc(char *funcName, int arity, unsigned char parType, unsigned char retType, GenericFunc pFunc);

void addPostProcFunc(char *funcName, int arity, unsigned char st, GenericFunc pInitFunc, GenericFunc pFunc);

void initFirstAnalysis(void);

void endFirstAnalysis(void);

void addDef(FADef * pd);

void addInclude(char *ident);

void addConst(char *file, int lgn, char *ident, FADef * pd);

void addMacro(char *file, int lgn, char *ident, int nbArg, FADef * pd);

void addStream(char *file, int lgn, char *ident, FADef * pd);

/* static */
char *NewStreamName(void);

/* static */
FAExpNode *callToStream(FAExpNode * pen);

/* static */
FAName *callParams(FAOp * po);

/* static */
void constToCallMacro(FADef * pd);

/* static */
Boolean goodMacroParams(FAOp * po);

/* static */
void findCallMacro(FADef * ldef);

int nbFANames(FAName * lf);

/* static */
void findMacroIdent(FADef * ldef);

/* static */
void findConstStreamIdent(FADef * ldef);

/* (Booleanis taken to be integer)              */
Boolean compTypes(unsigned char t1, unsigned char t2);

/* static */
FAName *concFANameList(FAName * la, FAName * lb);

/* static */
FAName *nameUsed(FAExpNode * pen);

/* static */
void scCycle(FAName * ln, FAName * lnu);

/* static */
void scConstDefsLoops(FADef * ldef);

/* static */
void scMacroCall(FAConstruct * pc);

/* static */
LString *scRegisters(FAReg * lr);

/* static */
int scVar(FAExpNode * pe, LString * lrn, LString * lpi);

/* static */
void *keyFuncProto(FuncProto * pfp);

/* static */
int scOp(FAExpNode * pe, LString * lrn, LString * lpi);

/* static */
int scExpr(FAExpNode * pe, LString * lrn, LString * lpi);

/* static */
void scIfThenElse(FAAction * pa, LString * lrn, LString * lpi);

/* static */
void scAssign(FAAction * pa, LString * lrn, LString * lpi);

/* static */
void scActions(FAAction * la, LString * lrn, LString * lpi);

/* static */
int scPattern(FAPattern * pp);

/* static */
LString *scPatterns(FAPattern * lp, int nbArg);

/* static */
void scMap(FAConstruct * pc);

/* static */
void scConstruct(FAConstruct * pc);

/* static */
Boolean inFANameList(FAName * ln, char *n);

/* static */
void scMacroDef(FADef * pd);

/* static */
void scPostProcDef(FADef * pd);

/* static */
void scDefs(FADef * ldef);

void semaCheck(FADef * allDef);

/************************************************************ End Prototypes */

#endif
