#include "agat.h"


#define MAX(a,b) (((a)>(b))?(a):(b))
#define ZDEEPTH 256


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
/* */
void
printMat(Matrix4 * m)
{
    int i;

    for (i = 0; i < 4; i++)
	fprintf(stderr, "%5f %5f %5f %5f\n", m->elt[i][0], m->elt[i][1], m->elt[i][2], m->elt[i][3]);
    fprintf(stderr, "\n");
}


void
printVect(Vector3 * v)
{
    fprintf(stderr, "Vect: %5f %5f %5f %5f\n", v->x, v->y, v->z);
}


void
printPoint(Vector3 * p)
{
    fprintf(stderr, "Point: %5f %5f %5f\n", p->x, p->y, p->z);
}


void
moveMouse3D(AnyClassOp3D * pp, View * vw)
{
    int mouseX, mouseY;
    XEvent mouseEvent;
    static int lmx, lmy;
    int first = 1;
    int dx, dy;
    Matrix4 rMouse, rot, tmp;
    Point3 ovrp, orig;
    Vector3 ovup, tmpv, ip, jp, kp;


    /* store original vrp and vup */
    V3CopyPoint(&(vw->vrp), &ovrp);
    V3CopyVector(&(vw->vup), &ovup);

    XNextEvent(pp->dpy, &mouseEvent);
    while (mouseEvent.type != ButtonRelease) {
	if (mouseEvent.type == MotionNotify) {
	    mouseX = mouseEvent.xmotion.x;
	    mouseY = mouseEvent.xmotion.y;
	    if (first) {
		lmx = mouseX + 1;
		lmy = mouseY + 1;
		first = 0;
	    }
	    dx = -(mouseX - lmx);
	    dy = -(mouseY - lmy);
	    /* compute the mouse rotation matrix given dx and dy on screen */
	    ModifyView(vw, dx, dy, &rMouse);
	    /* build rotation in target coordinates */
	    V3MatTransp2Mul(&rMouse, &(vw->smR), &tmp);
	    V3MatMul(&(vw->smR), &tmp, &rot);
	    /* rotate vup and vrp */
	    V3MulPointByMatrix(&ovrp, &rot, &(vw->vrp));
	    V3MulPointByMatrix(&ovup, &rot, &(vw->vup));
	    evaluateViewRepresentation(vw, pp, &(vw->vrp), &(vw->vup), 1, 1, 1);
	    (*(pp->refresh)) (pp);
/*	    CalcCoord(pp, &obj, &(vw->mTot), NULL);*/
	    XFlush(pp->dpy);
	}
	XNextEvent(pp->dpy, &mouseEvent);
    }

    /* to be sure that vup is orthogonal to vrp (enable rotation composition) */
    V3Cross(&(vw->vup), &(vw->vrp), &tmpv);
    V3Cross(&(vw->vrp), &tmpv, &(vw->vup));
    V3Normalize(&(vw->vup));

    /* renormalize vrp (same lenght) */
    V3Scale((Vector3 *) & (vw->vrp), V3Length((Vector3 *) & ovrp) / V3Length((Vector3 *) & (vw->vrp)));

    /* compute rotation needed to transform i -> vrp/||vrp|| AND k -> vup */
    V3CopyVector(&(vw->vrp), &ip);
    V3Normalize(&ip);
    V3CopyVector(&(vw->vup), &kp);
    V3Cross(&kp, &ip, &jp);
    V3VectorToMat(&ip, &jp, &kp, &(vw->smR));
}


/***************************************************************************\
|*   Functions for matrix computation                                      *|
\***************************************************************************/


void
evaluateVOM(Point3 * vrp, Vector3 * vpn, Vector3 * vup, Matrix4 * vom)
{
    Vector3 n, u, v;

    V3CopyVector(vpn, &n);
    V3Normalize(&n);
    V3Cross(vup, vpn, &u);
    V3Normalize(&u);
    V3Cross(&n, &u, &v);

    /* Make M = R . T(-VRP) */
    vom->elt[0][0] = u.x;
    vom->elt[0][1] = u.y;
    vom->elt[0][2] = u.z;
    vom->elt[0][3] = -(u.x * vrp->x + u.y * vrp->y + u.z * vrp->z);

    vom->elt[1][0] = v.x;
    vom->elt[1][1] = v.y;
    vom->elt[1][2] = v.z;
    vom->elt[1][3] = -(v.x * vrp->x + v.y * vrp->y + v.z * vrp->z);

    vom->elt[2][0] = n.x;
    vom->elt[2][1] = n.y;
    vom->elt[2][2] = n.z;
    vom->elt[2][3] = -(n.x * vrp->x + n.y * vrp->y + n.z * vrp->z);

    vom->elt[3][0] = 0;
    vom->elt[3][1] = 0;
    vom->elt[3][2] = 0;
    vom->elt[3][3] = 1;
}


void
evaluateVMM(
 /* First, we specify the view-plane boundaries */
	    double umin, double umax, double vmin, double vmax,
	    int projectionType,		/* Parallel or Perspective */
	    Point3 * prp,		/* coordinates in VRC (u,v,n) */
	    double fpd, double bpd,	/* Clip planes */
	    Matrix4 * vmm)
{
    Matrix4 tprp, shpar, sper, sht, nper, m;
    Vector3 dop, cw;

    V3MatTranslate(&tprp, -(prp->x), -(prp->y), -(prp->z));
    V3FillVector(&cw, (umax + umin) / 2, (vmax + vmin) / 2, 0);
    V3Sub(&cw, prp, &dop);
    if (dop.z == 0.0)
	dop.z = MINDOUBLE * 100.0;
    V3MatShearXY(&shpar, dop.x / dop.z, dop.y / dop.z);

    V3MatMul(&shpar, &tprp, &sht);
    V3MatScale(&sper, (2 * -(prp->z)) / ((umax - umin) * (-(prp->z) + bpd)),
	       (2 * -(prp->z)) / ((vmax - vmin) * (-(prp->z) + bpd)),
	       (-1) / (-(prp->z) + bpd)
	);
    V3MatMul(&sper, &sht, &nper);
    V3MatClip(&m, 0);
    V3MatMul(&m, &nper, vmm);
}


void
evaluateMVV3DV(
 /* We specify the NPC viewport */
	       double xvmin, double xvmax,
	       double yvmin, double yvmax,
	       double zvmin, double zvmax,
	       Matrix4 * mvv3dv)
{
    Matrix4 tunit, tmin, sc, tmp;

    V3MatTranslate(&tunit, 1, 1, 1);
    V3MatScale(&sc, (xvmax - xvmin) / 2,
	       (yvmax - yvmin) / 2,
	       (zvmax - zvmin));
    V3MatTranslate(&tmin, xvmin, yvmin, zvmin);
    V3MatMul(&sc, &tunit, &tmp);
    V3MatMul(&tmin, &tmp, mvv3dv);
}


void
evaluateViewRepresentation(View * vw, AnyClassOp3D * pp, Point3 * vrp, Vector3 * vup, int evom, int evmm, int emvv)
{
    Matrix4 nperp, mTmp, mtl, tmp;

    V3FillVector(&(vw->vpn), -vrp->x, -vrp->y, -vrp->z);

    if (evom)
	evaluateVOM(vrp, &(vw->vpn), vup, &(vw->vom));

    V3MatTranslate(&mtl, -(vw->xmax + vw->xmin) / 2,
		   -(vw->ymax + vw->ymin) / 2,
		   -(vw->zmax + vw->zmin) / 2);
    V3MatMul(&(vw->vom), &mtl, &tmp);
    V3MatCopy(&tmp, &(vw->vom));

    if (evmm)
	evaluateVMM(-vw->sw / 2, vw->sw / 2, -vw->sw / 2, vw->sw / 2,
		    0, &(vw->prp), 20 /* ??? */ , 19 /* ??? */ , &(vw->vmm));
    V3MatMul(&(vw->vmm), &(vw->vom), &nperp);

    if (emvv)
	evaluateMVV3DV(0, pp->xusz, 0, pp->yusz, 0, ZDEEPTH, &(vw->mvv3dv));

    V3MatMul(&(vw->mvv3dv), &nperp, &mTmp);

    V3MatPer(&(vw->mPer), (vw->prp).z);
    V3MatMul(&(vw->mPer), &mTmp, &(vw->mTot));
}

void
init3D(View * vw, double xmin, double xmax, double ymin, double ymax, double zmin, double zmax, Point3 * vrp, Point3 * vup)
{
    double max;

    vw->xmin = xmin;
    vw->xmax = xmax;
    vw->ymin = ymin;
    vw->ymax = ymax;
    vw->zmin = zmin;
    vw->zmax = zmax;
    max = MAX((vw->xmax - vw->xmin), (vw->ymax - vw->ymin));
    vw->sw = MAX(max, (vw->zmax - vw->zmin)) / 10;

    V3FillPoint(&(vw->vrp), vrp->x, vrp->y, vrp->z);
    V3FillVector(&(vw->vup), vup->x, vup->y, vup->z);
    V3FillPoint(&(vw->prp), 0, 0, vw->sw / 2);
    V3MatId(&(vw->smR));
}


void
ChangeBb(View * vw, double xmin, double xmax, double ymin, double ymax, double zmin, double zmax)
{
    double max;

    vw->xmin = xmin;
    vw->xmax = xmax;
    vw->ymin = ymin;
    vw->ymax = ymax;
    vw->zmin = zmin;
    vw->zmax = zmax;
    max = MAX((vw->xmax - vw->xmin), (vw->ymax - vw->ymin));
    vw->sw = MAX(max, (vw->zmax - vw->zmin)) / 10;

    V3FillPoint(&(vw->prp), 0, 0, vw->sw / 2);
}


int
pointInWindow(AnyClassOp3D * pp, Point3 * pt)
{
#define MARGX 10
#define MARGY 10

    if ((pt->x < pp->xusz - MARGX) && (pt->x > MARGX) &&
	(pt->y < pp->yusz - MARGY) && (pt->y > MARGY))
	return 1;
    else
	return 0;
}


void
moveVRP(AnyClassOp3D * pp)
{
    Point3 pmin, pmax, prjmin, prjmax;
    double nvrp, max, r;
    int i;

    if (V3Length(&((pp->vw).vrp)) != 0) {
	max = MAX((pp->maxx - pp->minx), (pp->maxy - pp->miny));
	r = MAX(max, (pp->maxz - pp->minz));
	if (r != 0) {
	    V3Scale(&(pp->vw.vrp), (r - V3Length(&(pp->vw.prp))) /
		    V3Length(&((pp->vw).vrp)));
	}
    }
}
