#ifndef AGTSERVER_H
#define AGTSERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include <math.h>
#include <memory.h>
#include <pwd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <values.h>
#include <X11/Intrinsic.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <X11/Xutil.h>

#include "util.h"

#include "agatGen.h"
#include "agattypes.h"
#include "agatbuild.h"
#include "agatcheck.h"
#include "agatfunc.h"
#include "agatparse.h"
#include "agatpostproc.h"
#include "agatprocess.h"
#include "arlist.h"
#include "agatXrm.h"
#include "agatXgen.h"
#include "agatXmatrix.h"
#include "defs3D.h"
#include "agatXgen3D.h"
#include "agatXgen3D.h"
#include "rollBall.h"
#include "agatXdraw.h"
#include "agatXps.h"
#include "agatXzoom.h"
#include "agatXbar.h"
#include "agatXbox.h"
#include "agatXhisto.h"
#include "agatXlabel.h"
#include "agatXplot.h"
#include "agatXplot3D.h"

#define UTRACE_AXBAR UTRACE_RESERVED<<1

#define RM_CHKZ_DESCSID 20
#define HT_KNOWNSTREAM_SZ 30
#define HT_XWIN_SZ 30

#define DEF_SCRIPT_NAME  "def.agt"

#define WM_OPTMULTDEF    "This option is already defined : "
#define WM_USING         "Using this value : "
#define WM_ENVARSET      "Environment variable was set but priority to call parameter : "
#define WM_REPLFNUNUSED  "Replay file not used. There's a command to anim : "
#define WM_REPLFANDDMPFN "Dump file not used. It's a replay of : "
#define WN_CHANGEDMETYPE "Type of stream has changed : "


#define ER_NOANIM         "Nothing to animate. There's no replay file and no command."
#define ER_NOT_EXECUTABLE "Can't execute this file : "
#define ER_CANTOPENFILE   "Can't open this file : "
#define ER_NOSFN          "No .agt file to describe animation."
#define ER_MSG            "It seems that something went wrong during data exchange. Animated code died?"
#define ER_CANTEXECUTEALGO "Can't execute :"

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
int main(int argc, char **argv, char **env);

void playReplay(void);

void playAlgo(void);

/************************************************************ End Prototypes */

#endif
