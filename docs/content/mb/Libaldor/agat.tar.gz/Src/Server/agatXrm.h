#ifndef AGATXRM_H
#define AGATXRM_H
#include "agat.h"

#define NB_MAX_COLOR 15

typedef struct RDataBase {
    Boolean iconic;			/* iconifying window */
    Boolean organized;			/* organized window when map */
    int origx, origy;			/* position of first window */
    int pdx, pdy;			/* space between to windows */
    int xsz, ysz;			/* normal size of the window */
    int bigx, bigy;			/* window with a big size */
    int tinyx, tinyy;			/* window with a tiny size */
    int xm, ym;				/* size of the margin */
    char *font;				/* text font */
    int fg;				/* color of the texte */
    int bg;				/* color of background of window */
    int markcolor;			/* color of mark */
    int tabColor[NB_MAX_COLOR];		/* colors to draw */
}         RDataBase;


/**************************************************************** Prototypes */


/******************************************************************** Bodies */
void extractDB(int argc, char *argv[], Display * dpy, char *winTitle, RDataBase * iRDB);

void initRDataBase(Display * dpy, RDataBase * iRDB);

void extractOpts(Display * dpy, char *winTitle, RDataBase * iRDB);

/************************************************************ End Prototypes */

#endif
