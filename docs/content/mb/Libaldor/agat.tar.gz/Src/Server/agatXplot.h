#ifndef AGATXPLOT_H
#define AGATXPLOT_H
#include "agat.h"

/* size of ticks mark */
#define XPLOT_TICKSIZE 6

/* for Y labels */
/* no y label with less than this lenght */
#define YTICKS_NB_CARMIN 8
/* what part of the screen must be covered by y labels */
/* YTICKS_VRATIO == 5 -> 1/5 of screen height is used for label print */
/* YTICKS_HRATIO == 8 -> 1/8 of screen widht is  used for label print */
#define YTICKS_VRATIO 4
#define YTICKS_HRATIO 8

/* for X labels */
/* no x label with less than this lenght */
#define XTICKS_NB_CARMIN 8
/* a kind of default value for number of ticks */
#define NB_X_TICKS 4
/* what part of the screen must be covered by X labels */
#define XTICKS_HRATIO 1.2


/* number of points checked for compression */
#define COMP_QP_NBP 50


typedef struct Plot {
    int type;
    char *name;
    Display *dpy;
    Window win;
    Boolean iconified;
    Boolean killed;
    Boolean ps;
    FILE *fps;
    Pixmap pixmap;
    GC *drawGcs;
    GC backGc;
    GC textGc;
    char *font;
    GC markGc;
    RGB *tabRGB;			/* array of RGB values of the colors
					 * to draw in PS */
    int fontHeight, fontWidth;
    int xsz, ysz;			/* window size */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
    Queue *qv;				/* values plotted */
    int nbpt;				/* nb points */
    double minx, maxx, miny, maxy;	/* values extrema */
    double scalex, scaley;		/* scaling factors */
    double x, y, lx, ly;		/* point coord and last point coord */
    Boolean firstValue;			/* is this the first point ? */
    Boolean onlyPlot;			/* line or onlyplot? */
    void (*draw) ();
    void (*resize) ();
    void (*refresh) ();
    void (*coord) ();
    void (*szoom) ();
    void (*zoom) ();
    void (*pps) ();
    Boolean doAxe;			/* must we do the axes ? */
}    Plot;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
double PlotRealToScreenX(Plot * pp, double x);

double PlotRealToScreenY(Plot * pp, double y);

void *initPlotAxe(HashTable * pht);

void *initPlot(HashTable * pht);

void *initPlotAxeLine(HashTable * pht);

void *initPlotLine(HashTable * pht);

void plot(Plot * pp, Value * vx, Value * vy);

void plotInt(Plot * pp, Value * vx, Value * vy, Value * reInit);

void plotRestart(Plot * pp, Value * vx, Value * vy, Value * reInit);

/************************************************************ End Prototypes */


#endif
