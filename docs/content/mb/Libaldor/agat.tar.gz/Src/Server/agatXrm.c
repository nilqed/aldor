#include "agat.h"

#define FONT "-adobe-helvetica-medium-r-normal-*-18-180-75-75-p-98-iso8859-1"

static char *colorNames[] = {"blue", "magenta", "red", "sienna", "dimGray", "springgreen", "goldenrod", "darkorange", "orangeRed", "maroon", "saddlebrown", "slategrey", "seagreen", "navyblue", "pink"};


static XrmDatabase rDB;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */


void
extractDB(int argc, register char *argv[], Display * dpy, char *winTitle, RDataBase * iRDB)
{
    /* initialize the structure */
    initRDataBase(dpy, iRDB);

    /*
     * get server defaults, program defaults, .Xdefaults, command line, etc.
     * and merge them
     */
    rDB = XtDatabase(dpy);

    /* extract values from database for use */
    extractOpts(dpy, winTitle, iRDB);
}


void
initRDataBase(Display * dpy, RDataBase * iRDB)
{
    int j;

    iRDB->iconic = False;
    iRDB->organized = True;
    iRDB->origx = 15;
    iRDB->origy = 15;
    iRDB->pdx = 10;
    iRDB->pdy = 10;
    iRDB->bg = findColor(dpy, "White", WhitePixel(dpy, DefaultScreen(dpy)));
    iRDB->fg = findColor(dpy, "Black", BlackPixel(dpy, DefaultScreen(dpy)));
    iRDB->xsz = 300;
    iRDB->ysz = 300;
    iRDB->bigx = 600;
    iRDB->bigy = 600;
    iRDB->tinyx = 100;
    iRDB->tinyy = 100;
    iRDB->xm = 5;
    iRDB->ym = 5;
    iRDB->markcolor = findColor(dpy, "Red", BlackPixel(dpy, DefaultScreen(dpy)));
    iRDB->font = (char *) UZalloc(sizeof(char) * strlen(FONT) +1);
    strcpy(iRDB->font, FONT);

    for (j = 0; j < NB_MAX_COLOR; iRDB->tabColor[j++] = 0);
    for (j = 0; j < NB_MAX_COLOR; j++)
	if (j < 15)
	    iRDB->tabColor[j] = findColor(dpy, colorNames[j], BlackPixel(dpy, DefaultScreen(dpy)));
	else
	    iRDB->tabColor[j] = findColor(dpy, "Black", BlackPixel(dpy, DefaultScreen(dpy)));
}

void
extractOpts(Display * dpy, char *winTitle, RDataBase * iRDB)
{
    char *str_type[20];
    char buffer[20];
    char Geostr[256];
    long flags;
    XrmValue value;
    int x, y, width, height;
    XColor screen_def;
    int screen_number;
    Visual *visual;
    int i, j;
    char str1[100], str2[100];
    Colormap colormap;

    /* Set, not to recalculate */
    screen_number = DefaultScreen(dpy);
    visual = DefaultVisual(dpy, screen_number);
    colormap = DefaultColormap(dpy, screen_number);

    /**************/
    /* Get ICONIC */
    /**************/
    sprintf(str1, "agat.%s.iconic", winTitle);
    sprintf(str2, "Agat.%s.Iconic", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	if (strncmp(value.addr, "True", (int) value.size) == 0) {
/*            fprintf(stderr,"iconic\n");*/
	    iRDB->iconic = True;
	}
    }

    /******************/
    /* Get FOREGROUND */
    /******************/
    sprintf(str1, "agat.%s.foreground", winTitle);
    sprintf(str2, "Agat.%s.Foreground", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	strncpy(buffer, value.addr, (int) value.size);
	iRDB->fg = findColor(dpy, buffer, BlackPixel(dpy, DefaultScreen(dpy)));
    }

    /******************/
    /* Get BACKGROUND */
    /******************/
    sprintf(str1, "agat.%s.background", winTitle);
    sprintf(str2, "Agat.%s.Background", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	strncpy(buffer, value.addr, (int) value.size);
	iRDB->bg = findColor(dpy, buffer, WhitePixel(dpy, DefaultScreen(dpy)));
    }

    /* one last check to make sure the colors are different! */
    if (iRDB->bg == iRDB->fg)
	fprintf(stderr, "Warning : background is equal to foreground !");

    /*****************/
    /* Get MARKCOLOR */
    /*****************/
    sprintf(str1, "agat.%s.markcolor", winTitle);
    sprintf(str2, "Agat.%s.Markcolor", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	strncpy(buffer, value.addr, (int) value.size);
	iRDB->markcolor = findColor(dpy, buffer, BlackPixel(dpy, DefaultScreen(dpy)));
    }

    if (iRDB->bg == iRDB->markcolor)
	fprintf(stderr, "Warning : background is equal to mark color !");

    /***********/
    /* Get XSZ */
    /***********/
    sprintf(str1, "agat.%s.xsz", winTitle);
    sprintf(str2, "Agat.%s.Xsz", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->xsz = atoi(value.addr);


    /***********/
    /* Get YSZ */
    /***********/
    sprintf(str1, "agat.%s.ysz", winTitle);
    sprintf(str2, "Agat.%s.Ysz", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->ysz = atoi(value.addr);

    /************/
    /* Get BIGX */
    /************/
    sprintf(str1, "agat.%s.bigx", winTitle);
    sprintf(str2, "Agat.%s.Bigx", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->bigx = atoi(value.addr);


    /************/
    /* Get BIGY */
    /************/
    sprintf(str1, "agat.%s.bigy", winTitle);
    sprintf(str2, "Agat.%s.Bigy", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->bigy = atoi(value.addr);

    /*************/
    /* Get TINYX */
    /*************/
    sprintf(str1, "agat.%s.tinyx", winTitle);
    sprintf(str2, "Agat.%s.Tinyx", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->tinyx = atoi(value.addr);


    /*************/
    /* Get TINYY */
    /*************/
    sprintf(str1, "agat.%s.tinyy", winTitle);
    sprintf(str2, "Agat.%s.Tinyy", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->tinyy = atoi(value.addr);

    /**********/
    /* Get XM */
    /**********/
    sprintf(str1, "agat.%s.xm", winTitle);
    sprintf(str2, "Agat.%s.Xm", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->xm = atoi(value.addr);

    /**********/
    /* Get YM */
    /**********/
    sprintf(str1, "agat.%s.ym", winTitle);
    sprintf(str2, "Agat.%s.Ym", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
	iRDB->ym = atoi(value.addr);

    /************/
    /* Get FONT */
    /************/
    sprintf(str1, "agat.%s.font", winTitle);
    sprintf(str2, "Agat.%s.Font", winTitle);

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	iRDB->font = URealloc(iRDB->font, (int) value.size);
	strncpy(iRDB->font, value.addr, (int) value.size);
    }

    /**************/
    /* Get COLORS */
    /**************/

    for (j = 0; j < NB_MAX_COLOR; j++) {
	sprintf(str1, "agat.%s.color%d", winTitle, j);
	sprintf(str2, "Agat.%s.Color%d", winTitle, j);

	if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	    strncpy(buffer, value.addr, (int) value.size);
	    iRDB->tabColor[j] = findColor(dpy, buffer, BlackPixel(dpy, DefaultScreen(dpy)));
	}
    }

    /*****************************************/
    /* Get ORGANIZED, ORIGX, ORIGY, PDX, PDY */
    /*****************************************/
    sprintf(str1, "agat.organized");
    sprintf(str2, "Agat.Organized");

    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True) {
	if (strncmp(value.addr, "True", (int) value.size) == 0) {
	    iRDB->organized = True;

	    sprintf(str1, "agat.origx");
	    sprintf(str2, "Agat.Origx");
	    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
		iRDB->origx = atoi(value.addr);
	    sprintf(str1, "agat.origy");
	    sprintf(str2, "Agat.Origy");
	    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
		iRDB->origy = atoi(value.addr);
	    sprintf(str1, "agat.pdx");
	    sprintf(str2, "Agat.Pdx");
	    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
		iRDB->pdx = atoi(value.addr);
	    sprintf(str1, "agat.pdy");
	    sprintf(str2, "Agat.Pdy");
	    if (XrmGetResource(rDB, str1, str2, str_type, &value) == True)
		iRDB->pdy = atoi(value.addr);
	}
	else if (strncmp(value.addr, "False", (int) value.size) == 0)
	    iRDB->organized = False;
    }
}
