#include "agat.h"

/* alloc values in block of this size. (avoid to call too frequently malloc) */
#define VALUE_BLOCK_SZ 500

/* store the final evaluation struct for the agat file to process */
Prox **aProx;
int nbProx = 0;

/* to acces a Prox Given a external Stream name  */
/* (to drive inputs stream in entry Proxex)      */
HashTable *htExtStream;

/* used for Value Garbage */
 /* static */ Value *vGarb = NULL;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */

Value *
allocValue(void)
{
    static Value *valueBlock = NULL;
    static int valueBlockSize = 0;
    Value *tmp;

    if (vGarb) {
	tmp = vGarb;
	vGarb = (Value *) vGarb->v.pt;
	return tmp;
    }
    else {
	if (!valueBlockSize) {
	    valueBlock = UZalloc(VALUE_BLOCK_SZ * sizeof(Value));
	    valueBlockSize = VALUE_BLOCK_SZ;
	}
	tmp = valueBlock;
	valueBlock++;
	valueBlockSize--;
	return tmp;
    }
}

void
unAllocValue(Value * pv)
{
    static count = 0;

    if (pv == NULL)
	return;
    pv->v.pt = (void *) vGarb;
    vGarb = pv;
}

void
unAllocValueArray(Value ** av, int nbv)
{
    int i;
    Value *tmp;

    tmp = vGarb;
    for (i = 0; i < nbv; i++) {
	if (av[i] != NULL) {
	    av[i]->v.pt = tmp;
	    tmp = av[i];
	}
    }
    vGarb = tmp;
}


Value *
dupValue(Value * pv)
{
    Value *pnv;

    pnv = allocValue();
    memcpy(pnv, pv, sizeof(Value));
    return pnv;
}




/* search for unbounded Stream name, which are supposed to be */
/* outputs from algorithms */
 /* static */ FADef *
addExternStreamAux(FAName * lf, FADef * lnd)
{
    FADef *pnd = NULL;
    StreamDesc *p;

    while (lf != NULL) {
	if (htSearchKey(htStream, lf->n) == NULL) {
	    pnd = bDef(DT_EXTSTREAM, lf->n, NULL, NULL, NULL);
	    pnd->next = lnd;
	    lnd = pnd;
	    p = (StreamDesc *) UCalloc(1, sizeof(StreamDesc));
	    p->lgn = 0;
	    p->file = NULL;
	    p->name = lf->n;
	    p->pd = pnd;
	    htInsert(htStream, p, False);
	}
	lf = lf->next;
    }
    return lnd;
}


/* add to the list of definition some externals stream                   */
/* these stream are suposed to be the outputs from algorithms to animate */
 /* static */ void
addExternStream(FADef * ld)
{
    FADef *pd;
    FADef *newDef = NULL;

    pd = ld;
    while (pd != NULL) {
	if (pd->t == DT_STREAM)
	    newDef = addExternStreamAux(pd->pc->lf, newDef);
	else if (pd->t == DT_POSTPROC)
	    newDef = addExternStreamAux(pd->lf, newDef);
	if (pd->next == NULL) {		/* add these new definitions to the
					 * end */
	    pd->next = newDef;
	    break;			/* ok, all real definition have been
					 * searched */
	}
	pd = pd->next;
    }
}



 /* static */ void *
keyConstDef(FADef * pd)
{
    return pd->name;
}


List *
findConstEvalOrder(FADef * ldef)
{
    FAName *lnu;
    ConstDesc *pcd;
    OGraph *gdep;
    List *evalOrder;
    int nbcd = 0;
    FADef *ld;

    ld = ldef;
    while (ld != NULL) {
	if (ld->t == DT_CONST)
	    nbcd++;
	ld = ld->next;
    }
    ld = ldef;
    gdep = ogCreate(nbcd, keyConstDef, ordString, nullFunc, hashString, printString);
    while (ld != NULL) {
	if (ld->t == DT_CONST) {
	    pcd = (ConstDesc *) htSearchKey(htConst, ld->name);
	    lnu = pcd->lnu;
	    ogAddNode(gdep, ld);
	    while (lnu != NULL) {
		ogAddArc(gdep, ld, ((ConstDesc *) (htSearchKey(htConst, lnu->n)))->pd);
		lnu = lnu->next;
	    }
	}
	ld = ld->next;
    }
    evalOrder = ogFindOrder(gdep);
    lReverse(evalOrder);
    ogFree(gdep);
    return evalOrder;
}




void
computeConsts(FADef * ldef)
{
    List *lcd;

    lcd = findConstEvalOrder(ldef);
    evalDefConsts(lcd);
}

void *
keyStreamDef(FADef * pd)
{
    return pd->name;
}

 /* static */ void
addArcs(OGraph * gdep, FAName * lf, FADef * pd, HashTable * htStreamDef)
{
    if (lf == NULL)			/* this node is isolated */
	ogAddNode(gdep, pd);
    while (lf != NULL) {
	ogAddArc(gdep, htSearchKey(htStreamDef, lf->n), pd);
	lf = lf->next;
    }
}

List *
orderGraph(FADef * ldef, HashTable * htStreamDef)
{
    OGraph *gdep;
    List *evalOrder;
    FADef *ld;
    int nbcd = 0;

    ld = ldef;
    while (ld != NULL) {
	ld = ld->next;
	nbcd++;
    }
    /* create the dependeny graph */
    ld = ldef;
    gdep = ogCreate(nbcd, keySame, ordVoid, nullFunc, hashVoid, NULL);
    while (ld != NULL) {
	if (ld->t == DT_EXTSTREAM) {
	    /* this is an extern stream node  of course no predecessor ! */
	    ogAddNode(gdep, ld);
	}
	else if (ld->t == DT_STREAM) {
	    addArcs(gdep, ld->pc->lf, ld, htStreamDef);
	}
	else if (ld->t == DT_POSTPROC) {
	    addArcs(gdep, ld->lf, ld, htStreamDef);
	}
	ld = ld->next;
    }
    /* ordering this graph enable to eval stream processing easier */
    evalOrder = ogFindOrder(gdep);

    ogFree(gdep);
    return evalOrder;
}

int
streamNametoNb(char *n, FAName * ln)
{

    int nb = 0;

    while (ln != NULL) {
	if (!strcmp(n, ln->n))
	    return nb;
	nb++;
	ln = ln->next;
    }
    UIError("agat server", "can't find such a stream %s", n);
}

int
regNametoNb(char *n, FAReg * lr)
{
    int nb = 0;

    while (lr != NULL) {
	if (!strcmp(n, lr->regName))
	    return nb;
	nb++;
	lr = lr->next;
    }
    UIError("agat server", "can't find such a register %s", n);
}

int
patNametoNb(char *n, FAPattern * lp)
{
    int nb = 0;

    while (lp != NULL) {
	if ((lp->name != NULL) && (!strcmp(n, lp->name)))
	    return nb;
	nb++;
	lp = lp->next;
    }
    UIError("agat server", "can't find such a pattern %s", n);
}


 /* static */ void
completeVarNode(FAExpNode * pe, FAPattern * lp, FADef * pd)
{
    switch (pe->t) {
	case ENT_VAR:{
	    switch (pe->pvn->t) {
		case VNT_PAT:{
		    pe->pvn->pq = (aProx[pd->aProxInd]->ainput[patNametoNb(pe->varName, lp)]);
		    break;
		}
	    case VNT_REG:{
		    pe->pvn->ppv = &(aProx[pd->aProxInd]->areg[regNametoNb(pe->varName, pd->pc->lr)]);
		    break;
		}
	    case VNT_CST:{
		    pe->pvn->pv = dupValue(((ConstDesc *) htSearchKey(htConst, pe->varName))->pd->pv);
		    break;
		}
	    default:{
		    char tmp[MAX_CHAR_TMP];

		    sprintf(tmp, "Variable %s is unknown.", pe->varName);
		    checkError(pe->file, pe->lgn, tmp);
		}
	    }
	    break;
	}
    case ENT_OP:{
	    int i;

	    for (i = 0; i < pe->po->arity; i++)
		completeVarNode(pe->po->sons[i], lp, pd);
	    break;
	}
    case ENT_VAL:{
	    break;
	}
    }
}



HashTable *
buildHTGraph(FADef * ldef)
{
    int nbfd = 0;
    FADef *ld;

    HashTable *htStreamDef;

    /* how many stream definitions ? */
    ld = ldef;
    while (ld != NULL) {
	if ((ld->t == DT_STREAM) || (ld->t == DT_EXTSTREAM))
	    nbfd++;
	ld = ld->next;
    }
    /* create and fill this hastable for fast acces */
    htStreamDef = htCreate((nbfd / 10) + 1, keyStreamDef, ordString, nullFunc, hashString, printString);
    ld = ldef;
    while (ld != NULL) {
	if ((ld->t == DT_STREAM) || (ld->t == DT_EXTSTREAM))
	    htInsert(htStreamDef, ld, False);
	ld = ld->next;
    }
    return htStreamDef;
}

 /* static */ int
nbReg(FAReg * lr)
{
    int nbr = 0;

    while (lr) {
	nbr++;
	lr = lr->next;
    }
    return nbr;
}

 /* static */ int
nbClause(FAClause * lc)
{
    int nbc = 0;

    while (lc) {
	nbc++;
	lc = lc->next;
    }
    return nbc;
}

 /* static */ void
buildPattern(FAPattern * lp, unsigned char **pap, unsigned char **pam)
{
    int i;
    FAPattern *pp;
    int nbp = 0;

    pp = lp;
    while (pp != NULL) {
	nbp++;
	pp = pp->next;
    }
    *pap = (Byte *) UZalloc(nbp * sizeof(Byte));
    *pam = (Byte *) UZalloc(nbp * sizeof(Byte));
    pp = lp;
    for (i = 0; i < nbp; i++) {
	switch (pp->state) {
	    /* Pattern and mask are prepared to faster test during evaluation */
	case ST_NO_VALUE:{
		(*pap)[i] = PAT_NO_VALUE & ~MASK_NO_VALUE;
		(*pam)[i] = ~MASK_NO_VALUE;
		break;
	    }
	case ST_FIRST_NEW_VALUE:{
		(*pap)[i] = PAT_FIRST_NEW_VALUE & ~MASK_FIRST_NEW_VALUE;
		(*pam)[i] = ~MASK_FIRST_NEW_VALUE;
		break;
	    }
	case ST_NEW_VALUE:{
		(*pap)[i] = PAT_NEW_VALUE & ~MASK_NEW_VALUE;
		(*pam)[i] = ~MASK_NEW_VALUE;
		break;
	    }
	case ST_NO_NEW_VALUE:{
		(*pap)[i] = PAT_NO_NEW_VALUE & ~MASK_NO_NEW_VALUE;
		(*pam)[i] = ~MASK_NO_NEW_VALUE;
		break;
	    }
	case ST_NO_NEW_VALUE_BUT_ONE:{
		(*pap)[i] = PAT_NO_NEW_VALUE_BUT_ONE & ~MASK_NO_NEW_VALUE_BUT_ONE;
		(*pam)[i] = ~MASK_NO_NEW_VALUE_BUT_ONE;
		break;
	    }
	}
	pp = pp->next;
    }
}

Action *
FAAtoA(FAAction * pfaa, FAReg * lr, FAPattern * lp, FADef * pd)
{
    Action *pa;

    if (pfaa == NULL)
	return (Action *) NULL;
    pa = (Action *) UZalloc(sizeof(Action));
    pa->t = pfaa->t;
    pa->file = pfaa->file;
    pa->lgn = pfaa->lgn;
    if (pa->t == ACT_ASGN) {
	pa->preg = &aProx[pd->aProxInd]->areg[regNametoNb(pfaa->regName, lr)];
    }
    pa->e = pfaa->e;
    if (pa->e != NULL)			/* NULL_ACTION */
	completeVarNode(pa->e, lp, pd);
    pa->thenA = buildAAction(pfaa->thenA, lr, lp, pd);
    pa->elseA = buildAAction(pfaa->elseA, lr, lp, pd);
    return pa;
}

 /* static */ Action **
buildAAction(FAAction * lfaa, FAReg * lr, FAPattern * lp, FADef * pd)
{
    FAAction *pfaa;
    int i, nba = 0;
    Action **aa;

    pfaa = lfaa;
    while (pfaa) {
	nba++;
	pfaa = pfaa->next;
    }
    aa = (Action **) UZalloc((nba + 1) * sizeof(Action *));
    aa[nba] = NULL;			/* to mark the end of action array */
    pfaa = lfaa;
    for (i = 0; i < nba; i++) {
	aa[i] = FAAtoA(pfaa, lr, lp, pd);
	pfaa = pfaa->next;
    }
    return aa;
}

 /* static */ void
initStreamProx(FADef * pd, Prox * pp)
{
    FAClause *pcl;
    int i, nbreg;

    nbreg = nbReg(pd->pc->lr);
    pp->areg = (Value **) UZalloc(nbreg * sizeof(Value *));
    for (i = 0; i < nbreg; i++)
	pp->areg[i] = bvInt("0");

    pp->nbpred = pd->pc->nbArg;
    pp->ainput = (Queue **) UZalloc(pp->nbpred * sizeof(Queue *));
    for (i = 0; i < pp->nbpred; i++)
	pp->ainput[i] = qCreate(nullFunc);
    pp->astate = (Byte *) UZalloc(pp->nbpred * sizeof(Byte));
    for (i = 0; i < pp->nbpred; i++)
	pp->astate[i] = ST_NO_STATE;

    pp->nbpat = nbClause(pd->pc->lc);
    pp->apat = (Byte **) UZalloc(pp->nbpat * sizeof(Byte *));
    pp->amask = (Byte **) UZalloc(pp->nbpat * sizeof(Byte *));
    pcl = pd->pc->lc;
    for (i = 0; i < pp->nbpat; i++) {
	buildPattern(pcl->lp, &pp->apat[i], &pp->amask[i]);
	pcl = pcl->next;
    }
    pp->aapact = (Action ***) UZalloc(pp->nbpat * sizeof(Action **));
    pcl = pd->pc->lc;
    for (i = 0; i < pp->nbpat; i++) {
	pp->aapact[i] = buildAAction(pcl->la, pd->pc->lr, pcl->lp, pd);
	pcl = pcl->next;
    }
}

 /* static */ void
initPostProcProx(FADef * pd, Prox * pp)
{
    int i, nba;

    nba = nbFANames(pd->lf);
    for (i = 0; i < postProcsNb; i++) {
	if (!strcmp(postProcs[i].name, pd->name)) {
	    if (postProcs[i].arity == VAR_ARITY)
		break;
	    if (postProcs[i].arity == nba)
		break;
	}
    }
    pp->initDone = False;
    pp->ppp = &postProcs[i];
    pp->cd = NULL;
    pp->nbpred = nba;
    pp->ainput = (Queue **) UZalloc(pp->nbpred * sizeof(Queue *));
    for (i = 0; i < pp->nbpred; i++)
	pp->ainput[i] = qCreate(nullFunc);
    pp->astate = (Byte *) UZalloc(pp->nbpred * sizeof(Byte));
    for (i = 0; i < pp->nbpred; i++)
	pp->astate[i] = ST_NO_STATE;
}

 /* static */ Prox *
buildProx(FADef * pd, int indprox)
{
    Prox *pProx;

    pProx = (Prox *) UCalloc(1, sizeof(Prox));
    aProx[indprox] = pProx;
    pProx->pd = pd;
    pProx->activated = False;

    /* alloc for sucessors datas (asucc,asn) are done later */
    pProx->nbsucc = 0;
    pProx->csucc = 0;
    pProx->asucc = NULL;

    /* noting to do for DT_EXTSTREAM */
    if (pd->t == DT_STREAM) {
	initStreamProx(pd, pProx);
    }
    else if (pd->t == DT_POSTPROC) {
	initPostProcProx(pd, pProx);
    }

    return pProx;
}

 /* static */ void
buildAllProx(FADef * ldef, List * evalOrder, HashTable * htStreamDef)
{
    FADef *pd;
    int i;

    aProx = (Prox **) UZalloc(lNbElts(evalOrder) * sizeof(Prox *));
    for (i = 0; i < lNbElts(evalOrder); i++) {
	pd = (FADef *) lLookNth(evalOrder, i);
	pd->aProxInd = i;
	buildProx(pd, i);
	nbProx++;
    }
}

 /* static */ void
incNbSucc(FAName * pn, HashTable * htStreamDef)
{
    FADef *pd;

    while (pn != NULL) {
	pd = (FADef *) htSearchKey(htStreamDef, pn->n);
	aProx[pd->aProxInd]->nbsucc++;
	pn = pn->next;
    }
}

 /* static */ void
addSuccs(FAName * pn, int succ, HashTable * htStreamDef)
{
    FADef *pd;
    int snb = 0, csucc, predInd;

    while (pn != NULL) {
	pd = (FADef *) htSearchKey(htStreamDef, pn->n);
	predInd = pd->aProxInd;
	csucc = aProx[predInd]->csucc;
	aProx[predInd]->asucc[csucc] = succ;
	aProx[predInd]->asn[csucc] = snb;
	aProx[predInd]->csucc++;
	snb++;
	pn = pn->next;
    }
}

 /* static */ void
fillAllProxSucc(HashTable * htStreamDef)
{
    int i;

    /* count the number of successors for each Prox */
    for (i = 0; i < nbProx; i++) {
	if (aProx[i]->pd->t == DT_STREAM) {
	    incNbSucc(aProx[i]->pd->pc->lf, htStreamDef);
	}
	else if (aProx[i]->pd->t == DT_POSTPROC) {
	    incNbSucc(aProx[i]->pd->lf, htStreamDef);
	}
    }
    /* build and fill asucc & asn for each Prox */
    for (i = 0; i < nbProx; i++) {
	aProx[i]->asucc = (int *) UZalloc(aProx[i]->nbsucc * sizeof(int));
	aProx[i]->asn = (int *) UZalloc(aProx[i]->nbsucc * sizeof(int));

	if (aProx[i]->pd->t == DT_STREAM) {
	    addSuccs(aProx[i]->pd->pc->lf, i, htStreamDef);
	}
	else if (aProx[i]->pd->t == DT_POSTPROC) {
	    addSuccs(aProx[i]->pd->lf, i, htStreamDef);
	}
    }
}

ExtStream *
buildExtStream(char *n, int i)
{
    ExtStream *pes;

    pes = (ExtStream *) UZalloc(sizeof(ExtStream));
    pes->n = n;
    pes->indProx = i;
    return pes;
}

void *
extStreamKey(ExtStream * pes)
{
    return pes->n;
}

HashTable *
buildHTExternStream(void)
{
    int i, nbes = 0;
    HashTable *htExtStream;

    /* how many external streams ? */
    for (i = 0; i < nbProx; i++) {
	if (aProx[i]->pd->t == DT_EXTSTREAM)
	    nbes++;
    }

    /* size, keyFunc, orderFunc, freeFunc, hashFunc, printFunc */
    htExtStream = htCreate((nbes / 10) + 1, extStreamKey, ordString, free, hashString, printString);
    for (i = 0; i < nbProx; i++) {
	if (aProx[i]->pd->t == DT_EXTSTREAM)
	    htInsert(htExtStream, buildExtStream(aProx[i]->pd->name, i), False);
    }
    return htExtStream;
}


/* do all the registers initialisation */
 /* static */ void
initRegisters(void)
{
    FAReg *lr;
    int i, nbr;

    for (i = 0; i < nbProx; i++) {
	if (aProx[i]->pd->t == DT_STREAM) {
	    lr = aProx[i]->pd->pc->lr;
	    nbr = 0;
	    while (lr != NULL) {
		if (lr->pen != NULL) {
		    unAllocValue(aProx[i]->areg[nbr]);
		    aProx[i]->areg[nbr] = evalExpr(lr->pen);
		}
		nbr++;
		lr = lr->next;
	    }
	}
    }
}


/* after this function all must be ready for animation */
void
compileGraph(FADef * ldef)
{
    List *evalOrder;
    HashTable *htStreamDef;

    addExternStream(ldef);
    htStreamDef = buildHTGraph(ldef);
    evalOrder = orderGraph(ldef, htStreamDef);
    buildAllProx(ldef, evalOrder, htStreamDef);
    fillAllProxSucc(htStreamDef);
    htExtStream = buildHTExternStream();
    initRegisters();
    lFree(evalOrder, False);
    htFree(htStreamDef, False);
}


void
compileFile(char *fname)
{
    int end;

    initFirstAnalysis();
    curLgn = 0;
    curFile = "parameter for server ";
    addInclude(fname);
    end = yywrap();
    if (end == 1) {
	fprintf(stderr, "Aborting: nothing to parse\n");
	UExit(1);
    }

    yyparse();
    semaCheck(allDef);
    if (nbError != 0) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp, "Aborting semantic checking: found %d error%c\n",
		nbError, ((nbError == 1) ? ' ' : 's'));
	fprintf(stderr, "%s\n", tmp);
	UExit(1);
    }

    /* displayFADef(allDef); */


    computeConsts(allDef);
    compileGraph(allDef);
    if (nbError != 0) {
	char tmp[MAX_CHAR_TMP];

	sprintf(tmp, "Aborting compilation: found %d error%c\n",
		nbError, ((nbError == 1) ? ' ' : 's'));
	fprintf(stderr, "%s\n", tmp);
	UExit(1);
    }

    endFirstAnalysis();
}
