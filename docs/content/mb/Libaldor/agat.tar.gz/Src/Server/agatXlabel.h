#ifndef AGATXLABEL_H
#define AGATXLABEL_H

/**************************************************************** Prototypes */


void findTicks(double min, double max, int *nbTicks, double **aTicks);

void findLabels(int nbTicks, int nbcar, double *aTicks, char **aLabs);

int buildXTicksLabs(int xsz, int fontWidth, double minx, double maxx, double hRatio, double **aTicks, char ***aLabs);

int buildYTicksLabs(int xsz, int ysz, int fontHeight, int fontWidth, double miny, double maxy, int nbCarMin, int vRatio, int hRatio, int *nbLabCar, double **aTicks, char ***aLabs);

/************************************************************ End Prototypes */


#endif
