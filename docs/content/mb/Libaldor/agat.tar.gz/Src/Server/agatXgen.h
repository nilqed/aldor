#ifndef AGATXGEN_H
#define AGATXGEN_H

#include "agat.h"


#define  NonNull(x,y) (((x)!=0)?(x):(((y)!=0)?(y):0))

typedef struct RGB {
    int xCol;
    double r, g, b;
}   RGB;

typedef struct AnyClassOp {
    int type;				/* Type of window */
    char *name;				/* Name of the window (title) */
    Display *dpy;			/* Display associed to the window */
    Window win;				/* ID of the window */
    Boolean iconified;			/* Is the window iconified ? */
    Boolean killed;			/* Is the window killed ? */
    Boolean ps;				/* Trace in PostScript mode ? */
    FILE *fps;				/* File descriptor for the .ps file */
    Pixmap pixmap;
    GC *drawGcs;			/* array of GC to draw */
    GC backGc;				/* GC for background */
    GC textGc;				/* GC for text */
    char *font;				/* Name of Font */
    GC markGc;				/* GC to display the mark */
    RGB *tabRGB;			/* array of RGB values of the colors
					 * to draw in PS */
    int fontHeight, fontWidth;		/* Height and Width of font */
    int xsz, ysz;			/* size of the window */
    int xm, ym;				/* margin */
    int xusz, yusz;			/* usable size */
}          AnyClassOp;			/* Commun strcut to all the operators */


extern HashTable *htXwin;

/**************************************************************** Prototypes */


/******************************************************************** Bodies */
Display *openDisplayOnlyOne(void);

void appNameClass(Display * dpy, Window win);

void moveWindow(Display * dpy, Window win, RDataBase * RDB);

void createFirstWindow(Display ** pdpy, Window * pwin, Pixmap * ppixmap, int xsz, int ysz, RDataBase * RDB);

void mapWindow(Display * dpy, Window win, RDataBase * RDB);

int findColor(Display * dpy, char *name, int col_dflt);

GC *createGcs(Display * dpy, Window d, int tabCo[], int nbgc);

GC createBackGc(Display * dpy, Window d, int bg);

GC createTextGc(Display * dpy, Window d, char *font, int fg, int *w, int *h);

GC createColorGc(Display * dpy, Window d, char *colName);

GC createXorColorGc(Display * dpy, Window d, int mc);

char *giveStreamTitle(char **an, char *opName);

void addXwin(Display * dpy, Window win, int type, GenericFunc fref, GenericFunc fres, GenericFunc fcoord, GenericFunc fzos, GenericFunc fzoom, GenericFunc fm3d, GenericFunc fpps, void *pe);

void coordDisplay(Display * dpy, XEvent event);

void zoomFunction(Display * dpy, XEvent event);

void moveIn3DView(Display * dpy, XEvent event);

void checkXConfigureEvents(Display * dpy, XEvent event);

void checkXExposeEvents(Display * dpy, XEvent event);

void checkXKeyEvents(Display * dpy, XEvent event);

void checkXMouseEvents(Display * dpy, XEvent event);

void checkXEvents(void);

/************************************************************ End Prototypes */


#endif
