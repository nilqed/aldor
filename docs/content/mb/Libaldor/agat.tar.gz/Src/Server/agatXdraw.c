#include "agat.h"

#define SGN(a)          (((a)<0) ? -1 : 1)

#define HAUT   1
#define BAS    2
#define GAUCHE 4
#define DROITE 8

/**************************************************************** Prototypes */


/******************************************************************** Bodies */

RGB
gc2RGBColor(AnyClassOp * pc, GC gc)
{
    XGCValues val_ret;
    int i;

    XGetGCValues(pc->dpy, gc, GCForeground, &val_ret);
    for (i = 0; ((i < NB_MAX_COLOR + 3) && (pc->tabRGB[i].xCol != val_ret.foreground)); i++);

    return pc->tabRGB[i];
}

void
agatDrawPoint(AnyClassOp * pc, Drawable d, GC gc, int x, int y)
{
    RGB c;

    if (!pc->ps)
	XDrawPoint(pc->dpy, d, gc, x, y);
    else {
	c = gc2RGBColor(pc, gc);
	fprintf(pc->fps, " %d %d %g %g %g plot\n", x, y, c.r, c.g, c.b);
    }
}


void
agatDrawLine(AnyClassOp * pc, Drawable d, GC gc, int x1, int y1, int x2, int y2)
{
    RGB c;

    if (!pc->ps)
	XDrawLine(pc->dpy, d, gc, x1, y1, x2, y2);
    else {
	c = gc2RGBColor(pc, gc);
	fprintf(pc->fps, " %d %d %d %d %g %g %g line\n", x1, y1, x2, y2,
		c.r, c.g, c.b);
    }
}


void
agatDrawString(AnyClassOp * pc, Drawable d, GC gc, int x, int y, char *str, int size)
{
    RGB c;
    char psFont[255];

    if (!pc->ps)
	XDrawString(pc->dpy, d, gc, x, y, str, size);
    else {
	c = gc2RGBColor(pc, gc);
	x2psFont(pc, pc->font, psFont);
	fprintf(pc->fps, "(%s) %s %d %d %g %g %g print\n", str, psFont, x, y,
		c.r, c.g, c.b);
    }
}


void
agatDrawRectangle(AnyClassOp * pc, Drawable d, GC gc, int x, int y, int w, int h)
{
    RGB c;

    if (!pc->ps)
	XDrawRectangle(pc->dpy, d, gc, x, y, w, h);
    else {
	c = gc2RGBColor(pc, gc);
	fprintf(pc->fps, "%d %d %d %d %d %d %d %d %g %g %g rect\n",
		0, -h, w, 0, 0, h, x, y, c.r, c.g, c.b);
    }
}


void
agatFillRectangle(AnyClassOp * pc, Drawable d, GC gc, int x, int y, int w, int h)
{
    RGB c;

    if (!pc->ps)
	XFillRectangle(pc->dpy, d, gc, x, y, w, h);
    else {
	c = gc2RGBColor(pc, gc);
	fprintf(pc->fps, "%d %d %d %d %d %d %d %d %g %g %g rectfill\n",
		0, -h, w, 0, 0, h, x, y, c.r, c.g, c.b);
    }
}


/**************************************************************************/
/* definit l'appartenance aux 4 zones
/* de l'ecran
/*   rux ruy : largeur et hauteur de l'ecran de clipping
/*   x y     : coordonnees du point a tester
/*   p       : octet qui contiendra le code de la zone ou se trouve le point
/*             ex:  p= ox1001 => pt a droite du bord droit
/*                               pt au dessus du haut de l'ecran
*/
void
position(rux, ruy, x, y, p)
    double rux, ruy;
    double x, y;
    int *p;
{
    *p = 0;
    if (x < 0)
	*p |= GAUCHE;
    if (x >= rux)
	*p |= DROITE;
    if (y < 0)
	*p |= HAUT;
    if (y >= ruy)
	*p |= BAS;
}


/*****************************************************************/
/* gestion du clipping    Cohen-Sutherland
/*   rux ruy     : largeur et hauteur de l'ecran de clipping
/*   x1 y1 x2 y2 : coordonnees du segment a clipper
/*   p           : le code de la zone ou se trouve le point x1 y1
/*   xc yc       : les coordonnees apres clipping de x1 y1
*/
int
clipping(rux, ruy, p, x1, y1, x2, y2, xc, yc)
    double rux, ruy;
    int p;
    double x1, y1, x2, y2;
    double *xc, *yc;
{
    if (p & GAUCHE) {			/* le point est a gauche de l'ecran */
	if (x1 != x2) {			/* pas de degenerescence */
	    *yc = y1 - x1 * (y2 - y1) / (x2 - x1);	/* calcul nouvelle
							 * coordonee */
	    if ((*yc >= 0) && (*yc < ruy)) {
		*xc = 0;
		return (0);
	    };
	}
    }
    if (p & DROITE) {
	if (x1 != x2) {
	    *yc = y1 - (x1 - rux + 1) * (y2 - y1) / (x2 - x1);
	    if ((*yc >= 0) && (*yc < ruy)) {
		*xc = rux - 1;
		return (0);
	    };
	}
    }
    if (p & HAUT) {
	if (y1 != y2) {
	    *xc = x1 - y1 * (x2 - x1) / (y2 - y1);
	    if ((*xc >= 0) && (*xc < rux)) {
		*yc = 0;
		return (0);
	    };
	}
    }
    if (p & BAS) {
	if (y1 != y2) {
	    *xc = x1 - (y1 - ruy + 1) * (x2 - x1) / (y2 - y1);
	    if ((*xc >= 0) && (*xc < rux)) {
		*yc = ruy - 1;
		return (0);
	    };
	}
    }
    return (1);
}

/*********************************************************************/
/* affichage d'un segment de droite
/*    dpy, win        : display et window ou ecrire
/*    gc              : graphic context pour le trace
/*    x1,y1,x2,y2     : coordonnees des extremites du segment
/*    dux duy dlx dly : les coordonnees de la fenetre de clipping
/*    clip            : faut il clipper ?
*/
void
agatDrawBasicLine(AnyClassOp * pc, Window win, GC gc, double x1, double y1, double x2, double y2, double dux, double duy, double dlx, double dly)
{
    int pos1, pos2;
    double x1c, y1c, x2c, y2c;
    double rx1, ry1, rx2, ry2;
    double rux, ruy;

    rx1 = x1 - dux;			/* il faut revenir a des coordonnees
					 * dans le repere de    */
    /* la fenetre de clipping pour appliquer Cohen-Sutherland */
    ry1 = y1 - duy;
    rx2 = x2 - dux;
    ry2 = y2 - duy;
    rux = dlx - dux + 1;		/* largeur hauteur de la fenetre de
					 * clip */
    ruy = dly - duy + 1;

    position(rux, ruy, rx1, ry1, &pos1);
    position(rux, ruy, rx2, ry2, &pos2);

    if (pos1 & pos2)
	return;				/* le segment est entierement en
					 * dehors de  */
    /* la fenetre de clip */

    if ((!pos1) && (!pos2)) {		/* entierement dedans */
	agatDrawLine(pc, win, gc, x1, y1, x2, y2);
	return;
    }
    if (pos1) {				/* la il faut clipper x1 y1 */
	if (clipping(rux, ruy, pos1, rx1, ry1, rx2, ry2, &x1c, &y1c))
	    return;
    }
    else {
	x1c = rx1;
	y1c = ry1;
    };
    if (pos2) {				/* la il faut clipper x2 y2 */
	if (clipping(rux, ruy, pos2, rx1, ry1, rx2, ry2, &x2c, &y2c))
	    return;
    }
    else {
	x2c = rx2;
	y2c = ry2;
    };

    x1c += dux;				/* revenir dans les coordonnees de
					 * l'ecran */
    x2c += dux;
    y1c += duy;
    y2c += duy;
    agatDrawLine(pc, win, gc, x1c, y1c, x2c, y2c);	/* tracer la ligne. ouf! */
}
