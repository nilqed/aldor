#ifndef MESG_H
#define MESG_H


#define ER_INTERN "Internal error... :) sorry!"
#define ER_NOMEM "Not enough memory "


#endif /* MESG_H */
