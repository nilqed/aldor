#include "util.h"
#include "math.h"

int tm;

void
testTimeout(char *p)
{
    printf("timeout %s\n", p);
}

void
testTimeoutGremlins(int *p)
{
    printf("timeout gremlins %d\n", *p);
    (*p)++;
    UAddTimeout(tm, testTimeoutGremlins, p);
    UAddTimeout(tm, testTimeoutGremlins, p);
}

int
main(int argc, char **argv)
{
    int             j, i = 0;

    tm = 5000;
    if (argc > 1)
	tm = atoi(argv[1]);
    UAddTimeout(tm, testTimeoutGremlins, &i);

    while (1) {
	for (j = 0; j < 10000; j++)
	    sqrt((double) j);
	printf(".");
	UCallTimeoutedAux();
    }
}
