#include "util.h"

int
main(int argc, char **argv)
{
    int i, j;
    Chrono *pc;

    pc = UChronoCreate();
    for (i = 0; i < atoi(argv[1]); i++) {
	UChronoRestart(pc);
        UUsleep(atoi(argv[2]));
	UChronoPrint(pc);
	printf("\n");
	fflush(stdout);
    }
    return 0;
}
