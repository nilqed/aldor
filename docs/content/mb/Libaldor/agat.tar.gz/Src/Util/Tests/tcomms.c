#include "util.h"


#define EmCheckError(f) {int ECEStatus; if((ECEStatus=(f))){printf("\n%s\n\n",UCommErrCodeToString(ECEStatus));UExit(1);}}


int
EmWaitForNewEvents(int *pIsMsg	/* if not NULL return if there's a message (X
		       or line) */ ,
		   int tms /* timeout */ )
{
    static fd_set   inputFds;
    static int      lastUSMustRebuildFDSet = -1;
    static int      maxSock, xfd, stat;
    struct timeval  timeout;
    fd_set          readfds;

    if ((USMustRebuildFDSet != lastUSMustRebuildFDSet)){
	lastUSMustRebuildFDSet = USMustRebuildFDSet;
	FD_ZERO(&inputFds);
	maxSock = USFillFdAllLines(&inputFds);
    }
    readfds = inputFds;
    /* just check if there's something waiting on these fd */
    timeout.tv_sec = tms / 1000;
    timeout.tv_usec = (tms * 1000) % 1000000;
    if ((stat = URestartSelect(maxSock + 1,
			       (fd_set *) & readfds,
			       (fd_set *) NULL,
			       (fd_set *) NULL,
			       &timeout)) < 0) {
	URetErrno;
    }
    if (pIsMsg)
	*pIsMsg = stat;
    return 0;
}


void
EmProcessExternal(int lSync, int lASync)
{
    int isMsg, lMsg;
    Byte *pMsg;

    while (1) {
	EmCheckError(USCheckPendingMsg(lSync, &isMsg));
	if (!isMsg)
	    break;
	EmCheckError(USGetNextMsg(lSync, &pMsg, &lMsg));
	EmCheckError(USSend(lSync, pMsg, lMsg));
	printf("s");
	fflush(stdout);
    }
    while (1) {
	EmCheckError(USCheckPendingMsg(lASync, &isMsg));
	if (!isMsg)
	    break;
	EmCheckError(USGetNextMsg(lASync, &pMsg, &lMsg));
	printf("a");
	fflush(stdout);
    }
}


int
main(int argc, char **argv)
{
    int isMsg, lSync, lASync;

    EmCheckError(USInit(atoi(argv[1]), "tcomms-server"));
    printf("server waitng for lines\n");
    EmCheckError(USWaitForNewLine(&lSync));
    EmCheckError(USWaitForNewLine(&lASync));
    while (1) {
	while (1) {
	    EmCheckError(EmWaitForNewEvents(&isMsg, 100));
	    if (isMsg)
		break;
	    printf(".");
	    fflush(stdout);
	}
        EmProcessExternal(lSync, lASync);
    }
    return 0;
}
