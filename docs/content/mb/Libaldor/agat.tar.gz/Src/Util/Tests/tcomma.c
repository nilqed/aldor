#include "util.h"


#define EmCheckError(f) {int ECEStatus; if((ECEStatus=(f))){printf("\n%s\n\n",UCommErrCodeToString(ECEStatus));UExit(1);}}



int
main(int argc, char **argv)
{
    int lSync, lASync, lMsg, isMsg;
    char syncMsg[] = "0123456789abcdefghijABCDEFGHIJ";
    char asyncMsg[] = "async";
    Byte *pMsg;

    EmCheckError(UAOpenLine(argv[1], atoi(argv[2]), &lSync));
    EmCheckError(UAOpenLine(argv[1], atoi(argv[2]), &lASync));
    while (1) {
	EmCheckError(UACheckAllLines(&isMsg));
	if (isMsg) {
	    printf("i");
	    fflush(stdout);
	    EmCheckError(UAGetNextMsg(lSync, &pMsg, &lMsg));
	    if (strcmp(pMsg, syncMsg) || (lMsg != (strlen(syncMsg) + 1)))
		UExit(1);
	}
	else {
	    if (rand() % 5 > 2) {
		EmCheckError(UASend(lSync, syncMsg, strlen(syncMsg) + 1));
		printf("s");
		fflush(stdout);
	    }
	    else {
		EmCheckError(UASend(lASync, asyncMsg, strlen(asyncMsg) + 1));
		printf("a");
		fflush(stdout);
	    }
	}
        UUsleep(250);
    }
    return 0;
}
