#ifndef COMPRESS_H
#define COMPRESS_H
#include <stdio.h>


/* chose the right one depending on your preference */
/* gzip is better but you may need to install it ;) */
/*#define COMPRESS*/
#define GZIP

#ifdef GZIP
/* which compressor to use */
#ifndef COMPRESSOR
#define COMPRESSOR "gzip"
#endif /* COMPRESSOR */

#ifndef COMPRESSOR_OPT1
#define COMPRESSOR_OPT1 "-c"
#endif /* COMPRESSOR_OPT1 */

#ifndef COMPRESSOR_SUFFIX
#define COMPRESSOR_SUFFIX "gz"
#endif /* COMPRESSOR_SUFFIX */


/* which uncompressor to use */
#ifndef UNCOMPRESSOR
#define UNCOMPRESSOR "gzip"
#endif /* UNCOMPRESSOR */

#ifndef UNCOMPRESSOR_OPT1
#define UNCOMPRESSOR_OPT1 "-c"
#endif /* UNCOMPRESSOR_OPT1 */

#ifndef UNCOMPRESSOR_OPT2
#define UNCOMPRESSOR_OPT2 "-d"
#endif /* UNCOMPRESSOR_OPT2 */
#endif /* GZIP */

#ifdef COMPRESS
/* which compressor to use */
#ifndef COMPRESSOR
#define COMPRESSOR "compress"
#endif /* COMPRESSOR */

#ifndef COMPRESSOR_OPT1
#define COMPRESSOR_OPT1 "-c"
#endif /* COMPRESSOR_OPT1 */

#ifndef COMPRESSOR_SUFFIX
#define COMPRESSOR_SUFFIX "Z"
#endif /* COMPRESSOR_SUFFIX */


/* which uncompressor to use */
#ifndef UNCOMPRESSOR
#define UNCOMPRESSOR "uncompress"
#endif /* UNCOMPRESSOR */

#ifndef UNCOMPRESSOR_OPT1
#define UNCOMPRESSOR_OPT1 "-c"
#endif /* UNCOMPRESSOR_OPT1 */

#ifndef UNCOMPRESSOR_OPT2
#define UNCOMPRESSOR_OPT2 "-c"	/* fool uncompress give twice option
					 * -c becoz en empty parameter lead
					 * to error */
#endif /* UNCOMPRESSOR_OPT2 */
#endif /* COMPRESS */


/**************************************************************** Prototypes */


/* "w" -> write, "r" -> read */
FILE* UCompressedFOpen ( char *fileName, char *type );

/************************************************************ End Prototypes */

#endif /* COMPRESS_H */
