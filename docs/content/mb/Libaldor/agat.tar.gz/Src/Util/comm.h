#ifndef COMMONMSG_H
#define COMMONMSG_H
#include <errno.h>

#include "util.h"


/* RETurn IF Non Zero */
#define URetIfNz(a) {int URETIF_status;if ((URETIF_status=(a))) return (URETIF_status==EPIPE)?UCOMM_ERR_DISCONNECTED:URETIF_status;}
/* RETurn IF NEGatif */
#define URetIfNeg(a) {int URETIF_status;if ((URETIF_status=(a))<0) return (URETIF_status==EPIPE)?UCOMM_ERR_DISCONNECTED:URETIF_status;}



/* some predefined error */
#define UCOMM_ERR_GETHOSTBYNAME -100
#define UCOMM_ERR_CONNECT -101
#define UCOMM_ERR_DISCONNECTED -102
#define UCOMM_ERR_BADNAME -103

/* maximum size of packets emmited on lines (biger are splitted)*/
#define UCOMM_PACKET_SIZE 4096

typedef struct RcvMsg {
    int msgLen;
    Byte *pMsg;
}

RcvMsg;

typedef struct ConnectionLine {
    int socketNum;		/* number of the socket to use for
					 * this line */
    List *lReceivedMsg;		/* list of messages received(waiting
					 * a read) */
    Byte packToSend[UCOMM_PACKET_SIZE];	/* array of bytes -> will become a
					 * packet */
    int packToSendLen;		/* number of bytes already in packet
					 * (waiting to be send) */
    int nbSendPacket;		/* number of packets send */
    int nbSendMsg;		/* number of messages send */
    int nbReceivedMsg;		/* number of messages received since
					 * line connection */
}

ConnectionLine;


/**************************************************************** Prototypes */


/* Free a struct RcvMsg
 */
void UFreeRcvMsg ( RcvMsg * pm );

/* Print a struct RcvMsg (debug)
 */
void UPrintRcvMsg ( RcvMsg * pm );

/* Print some info on this connectionLine
 * Useful for debug
 */
void UConnPrint ( ConnectionLine * pConn );

/* Add a connectionLine (in a GArray of)
 */
int UAddAConn ( ConnectionLine * pConn, GArray ** paConn );

/* Lenght of data to send */
int USendCommon ( ConnectionLine * pConn, void *pMsg, int len );

/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int UCheckPendingMsgCommon ( ConnectionLine * pConn, int *pNbMsg );

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int UCheckAllLinesCommon ( GArray * aConn, int *pIsMsg );

/* Lenght of returned message */
int UGetNextMsgCommon ( ConnectionLine * pConn, Byte ** ppMsg, int *pLen );

/* Lenght of returned message */
int UPeekNextMsgCommon ( ConnectionLine * pConn, Byte ** ppMsg, int *pLen );

/* max time to watch (or NULL if want a blocking wait */
int UWaitForMsgCommon ( ConnectionLine * pConn, struct timeval *pTimeout );

/* Given a id (and correct array of pConn) find its fd (socket number here)
 * useful when need to do a select
 * return fd number or -1 if no such id
 */
int UIdToFdCommon ( int id, GArray * aConn );

/* Fill a fd_set (eg: for a select) with sockets fd of all given lines.
 * or all stored lines if aLines is NULL
 *
 * Return: max fd stored in *pFdSet
 */
int UFillFdCommon ( GArray * aConn, int *aLines, fd_set * pFdSet );

/* Close a line in aConn.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 *
 * Warning: any pending message on this line will be lost
 */
int UCloseLineCommon ( int id, GArray * aConn );

/* Close all lines in aConn.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 */
int UCloseAllLinesCommon ( GArray * aConn );

/* Convert an error code to a string.
 *
 * Warning: Caller is responsible for freeing the returned string
 */
char * UCommErrCodeToString ( int errCode );

/************************************************************ End Prototypes */


#endif /* COMMONMSG_H */
