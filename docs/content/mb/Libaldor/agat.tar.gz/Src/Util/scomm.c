#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <string.h>
#include <signal.h>

#include "comm.h"
#include "util.h"

/* must rebuil external fd_set? useful for selects...
 * each connect deconect increment it by one
 */
int USMustRebuildFDSet = 1;

static GArray *aServConn = NULL;/* array of connections with apps */
static int sockfd;		/* socket file desciptor */


/**************************************************************** Prototypes */

/* For backward compatibilities and X11R5 */
static void* __gnu_calloc ( size_t __nmemb, size_t __n );
static void* __gnu_malloc ( size_t __n );
/* Close the socket descriptor
 */
static void USCloseSocketFd ( void );
/* See doc for USCheckNewLine or USWaitForNewLine */
static int USWaitNewLineTimeouted ( int *pId, int *pGotLine, struct timeval *timeout );
/* Check if new applications are requesting for lines.
 *
 * Accept the first one and put it's id in pId. Don't block.
 * Use pGetLine (if non NULL) to return if got Line (0 or 1)
 * (should be called until *pGetLine is 0).
 *
 * Return: 0 or error code
 *
 * Warning: this function must be called periodicaly to insure that connection
 * requests aren't ignored
 */
static int USCheckNewLine ( int *pId, int *pGotLine );

/******************************************************************** Bodies */



/* Close the socket descriptor
 */
static void
USCloseSocketFd(void)
{
    close(sockfd);
}

/* Init the server.
 *
 * Must be called before any call to other function of this lib.
 *
 * Return: 0 or error code
 *
 * Warning: this function set the signal handler for SIG_PIPE to SIG_IGN
 */
int
USInit(int portNum, char *serverName)
{
    struct sockaddr_in address;

    if ((sockfd = socket(PF_INET, SOCK_STREAM, 0)) < 0)
	return errno;

    address.sin_family = AF_INET;	/* Using Internet domain */
    address.sin_port = htons(portNum);	/* ?? TODO why htons? */
    address.sin_addr.s_addr = 0;
    if (bind(sockfd, (struct sockaddr *) &address, sizeof(address)) < 0) {
	close(sockfd);
	return errno;
    }

    if (listen(sockfd, 8) < 0) {/* 8 is current limit of backlog */
	close(sockfd);
	return errno;
    }

#ifdef __osf__
    atexit(USCloseSocketFd);	/* force to close socket on exit */
#endif

#ifdef __ultrix__
    atexit(USCloseSocketFd);	/* force to close socket on exit */
#endif

#ifdef __sun__
    on_exit(USCloseSocketFd, NULL);	/* force to close socket on exit */
#endif

    signal(SIGPIPE, SIG_IGN);	/* ignore broken sockets */

    return 0;
}

/* Close the line (id).
 *
 * Return: 0 or error code
 */
int
USCloseLine(int id)
{
    USMustRebuildFDSet++;
    return UCloseLineCommon(id, aServConn);
}

/* See doc for USCheckNewLine or USWaitForNewLine */
static int
USWaitNewLineTimeouted(int *pId, int *pGotLine, struct timeval *timeout)
{
    fd_set readfds, writefds, exceptfds;
    struct sockaddr_in caller;
    int socketNum, dummy;
    ConnectionLine *pConn;

    if (pGotLine)
	*pGotLine = 0;
    /* Looking for new clients */
    FD_ZERO(&readfds);
    FD_ZERO(&writefds);
    FD_ZERO(&exceptfds);
    FD_SET(sockfd, &readfds);
    if (URestartSelect(sockfd + 1, (fd_set *) & readfds, (fd_set *) & writefds,
		       (fd_set *) & exceptfds, timeout) < 0) {
	close(sockfd);
	return errno;
    }
    dummy = sizeof(struct sockaddr_in);

    if (FD_ISSET(sockfd, &readfds)) {	/* New client asking for connection */
	if ((socketNum = accept(sockfd, (struct sockaddr *) &caller, &dummy)) < 0) {	/* accepting connection */
	    return errno;
	}
	pConn = UNew(ConnectionLine);
	pConn->socketNum = socketNum;
	pConn->lReceivedMsg = lCreate(keySame, strcmp, UFreeRcvMsg, UPrintRcvMsg);
	bzero(pConn->packToSend, UCOMM_PACKET_SIZE);
	pConn->packToSendLen = 0;
	pConn->nbSendPacket = 0;
	pConn->nbSendMsg = 0;
	pConn->nbReceivedMsg = 0;
	*pId = UAddAConn(pConn, &aServConn);
	USMustRebuildFDSet++;
	if (pGotLine)
	    *pGotLine = 1;
    }
    return 0;
}

/* Check if new applications are requesting for lines.
 *
 * Accept the first one and put it's id in pId. Don't block.
 * Use pGetLine (if non NULL) to return if got Line (0 or 1)
 * (should be called until *pGetLine is 0).
 *
 * Return: 0 or error code
 *
 * Warning: this function must be called periodicaly to insure that connection
 * requests aren't ignored
 */
static int
USCheckNewLine(int *pId, int *pGotLine)
{
    struct timeval timeout;

    (timeout).tv_sec = 0;
    (timeout).tv_usec = 0;
    return USWaitNewLineTimeouted(pId, pGotLine, &timeout);
}

/* Wait until at least one new application is requesting for connection.
 *
 * Accept the first one and put it's id in pId.
 *
 * Return: 0 or error code
 *
 * Warning: this is a blocking call
 */
int
USWaitForNewLine(int *pId)
{
    int gotLine;

    return USWaitNewLineTimeouted(pId, &gotLine, NULL);
}

/* Send a message (on at least store it in a buffer).
 *
 * Return: 0 or error code
 */
int
USSend(int id /* On which line to send msg */ ,
       void *msg /* Pointer on data to send */ ,
       int len /* Lenght of data to send */ )
{
    return USendCommon((ConnectionLine *) gaLookNth(aServConn, id), msg, len);
}


/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int
USCheckPendingMsg(int id, int *pNbMsg)
{
    return UCheckPendingMsgCommon((ConnectionLine *) gaLookNth(aServConn, id), pNbMsg);
}

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int
USCheckAllLines(int *pIsMsg)
{
    return UCheckAllLinesCommon(aServConn, pIsMsg);
}

/* Get next message.
 *
 * Return: 0 or error code.
 *
 * Warning: It's a blocking call.
 */
int
USGetNextMsg(int id,
	     Byte **ppMsg	/* Pointer on returned message
	     	     	         (caller must free ppMsg after use) */ ,
	     int *pLen /* Lenght of returned message */ )
{
    return UGetNextMsgCommon((ConnectionLine *) gaLookNth(aServConn, id), ppMsg, pLen);
}

/* Peek next message (message is not removed from queue).
 *
 * Return: 0 or error code.
 *
 * Warning:  It's a blocking call.
 */
int
USPeekNextMsg(int id,
	      Byte ** ppMsg	/* Pointer on returned message
					 * (caller must NOT free ppMsg after
	      	      	      	          use) */ ,
	      int *pLen /* Lenght of returned message */ )
{
    return UPeekNextMsgCommon((ConnectionLine *) gaLookNth(aServConn, id), ppMsg, pLen);
}

/* Wait for new messages
 * return if a message is received (or already queued) or if timeout is expired.
 *
 * Return: number of got messages or error code
 */
int
USWaitForMsg(int id /* line to watch */ ,
	      struct timeval *pTimeout /* max time to watch (or NULL if want a blocking wait */ ) {
    return UWaitForMsgCommon((ConnectionLine *) gaLookNth(aServConn, id), pTimeout);
}


/* Fill a fd_set (eg: for a select) with sockets fd of all limes connected
 * to the server.
 *
 * Return: max fd stored in *pFdSet
 */
int
USFillFdAllLines(fd_set * pFdSet)
{
    int maxFd;

    /* fill with all lines fd */
    maxFd = UFillFdCommon(aServConn, NULL, pFdSet);
    /* and add listening socket to detect a connect */
    FD_SET(sockfd, pFdSet);
    return Max(maxFd, sockfd);
}

/* Given a id return its fd (socket number here)
 * useful when need to do a select
 * return fd number or -1 if no such id
 */
int
USIdToFd(int id /* line id */ )
{
    return UIdToFdCommon(id, aServConn);
}



