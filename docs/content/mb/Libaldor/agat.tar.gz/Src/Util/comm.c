#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

#include "comm.h"
#include "util.h"


/**************************************************************** Prototypes */

/* For backward compatibilities and X11R5 */
static void* __gnu_calloc ( size_t __nmemb, size_t __n );
static void* __gnu_malloc ( size_t __n );
/* Read exactly msgLen bytes (do as many read as needed to fill pMsg).
 * Restart if interrupted by signals.
 *
 * Return: number of bytes read (as standard read).
 * or an error code <0 if some error occurs (broken pipe, peer socket...)
 */
static int UReadExactly ( int fd, Byte * pMsg, int msgLen );
/* Read pending packets.
 *
 * Add read messages to the queue.
 * If last message is truncated wait until completion.
 *
 * Return: 0 or error code
 */
static int UReadWaitingPackets ( ConnectionLine * pConn, struct timeval *pTimeout );
/* Send message (or part of)
 * (ie flush actual packet (if needed)).
 *
 * Return: 0 or error code
 */
static int UFlush ( ConnectionLine * pConn );

/******************************************************************** Bodies */


/* Read exactly msgLen bytes (do as many read as needed to fill pMsg).
 * Restart if interrupted by signals.
 *
 * Return: number of bytes read (as standard read).
 * or an error code <0 if some error occurs (broken pipe, peer socket...)
 */
static int
UReadExactly(int fd, Byte * pMsg, int msgLen)
{
    int nbReadBytes, rlen;
    Byte *p;

    rlen = msgLen;
    p = pMsg;
    while (rlen) {
	while (((nbReadBytes = read(fd, p, rlen)) < 0) && (errno == EINTR));	/* empty */
	if (nbReadBytes == 0)
	    return UCOMM_ERR_DISCONNECTED;
	else if (nbReadBytes < 0)
	    URetErrno;
	else {
	    assert(nbReadBytes <= rlen);
	    p += nbReadBytes;
	    rlen -= nbReadBytes;
	}
    }
    return msgLen;
}

/* Read pending packets.
 *
 * Add read messages to the queue.
 * If last message is truncated wait until completion.
 *
 * Return: 0 or error code
 */
static int
UReadWaitingPackets(ConnectionLine * pConn, struct timeval *pTimeout)
{
    fd_set readfds;
    int nbReadBytes, msgLen, msgLenEncoded;
    char *pMsg;
    RcvMsg *pm;

    FD_ZERO(&readfds);
    /* read all pending packets (wait if truncated messages) */
    while (1) {
	FD_SET(pConn->socketNum, &readfds);
	if (URestartSelect(pConn->socketNum + 1,
			   (fd_set *) & readfds,
			   (fd_set *) NULL,
			   (fd_set *) NULL,
			   pTimeout) < 0) {
	    URetErrno;
	}
	if (!FD_ISSET(pConn->socketNum, &readfds)) {
	    return 0;		/* Nothing is waiting to be read */
	}
	/* read length & type of next packet */
	if ((nbReadBytes = UReadExactly(pConn->socketNum, (Byte *) (&msgLenEncoded), sizeof(int))) < 0)
	      return nbReadBytes;	/* that's an error code */
	msgLen = UIntBigEndianDec(msgLenEncoded);
	pMsg = UMalloc(msgLen + 1);

	if (msgLen) {
	    if ((nbReadBytes = UReadExactly(pConn->socketNum, pMsg, msgLen)) < 0)
		return nbReadBytes;	/* that's an error code */
	}
	pMsg[msgLen] = '\0';	/* easier to read for debug ;) */

	/* store this new msg in queue */
	pm = UNew(RcvMsg);
	pm->msgLen = msgLen;
	pm->pMsg = pMsg;
	lAddLast(pConn->lReceivedMsg, pm);
	pConn->nbReceivedMsg++;
	return 0;
	break;
    }
}


/* Free a struct RcvMsg
 */
void
UFreeRcvMsg(RcvMsg * pm)
{
    UFree(pm->pMsg);
    UFree(pm);
}

/* Print a struct RcvMsg (debug)
 */
void
UPrintRcvMsg(RcvMsg * pm)
{
    printf("(len:%d->", pm->msgLen);
    UDumpMem(pm->pMsg, pm->msgLen, UDUMP_ASC_OR_DEC);
    printf("<-)");

}


/* Print some info on this connectionLine
 * Useful for debug
 */
void
UConnPrint(ConnectionLine * pConn)
{
    printf("(socketNum:%d packToSendLen:%d nbReceivedMsg:%d)\n",
	   pConn->socketNum, pConn->packToSendLen, pConn->nbReceivedMsg);
}

/* Add a connectionLine (in a GArray of)
 */
int
UAddAConn(ConnectionLine * pConn, GArray ** paConn)
{
    UTrace(UTRACE_COMM, printf("UAddAConn\n"));
    if (!*paConn) {
	*paConn = gaCreate(UConnPrint);
    }
    return gaAdd(*paConn, pConn);
}

/* Send a message
 *
 * Return: 0 or error code
 */
int
USendCommon(ConnectionLine * pConn /* On which line to send msg */ ,
	    void *pMsg /* Pointer on data to send */ ,
	    int len /* Lenght of data to send */ )
{
    Byte *endPacket, *pTailMsg;
    int tailMsgLen, copyLen, totLen, msgLenEncoded;

    UTrace(UTRACE_COMM, printf("USendCommon\n"));
    totLen = len + sizeof(int);
    /* put len encoded */
    endPacket = pConn->packToSend;
    pConn->packToSendLen = 0;
    msgLenEncoded = UIntBigEndianEnc(len);	/* encode len */
    bcopy(&msgLenEncoded, endPacket, sizeof(msgLenEncoded));
    endPacket += sizeof(msgLenEncoded);
    pConn->packToSendLen += sizeof(msgLenEncoded);

    UTrace(UTRACE_COMM, printf("send(%d) len %d ->%s<-\n", pConn->socketNum, len, UDumpMem(pMsg, len, UDUMP_ASC_OR_DEC)));

    /* put msg */
    pTailMsg = pMsg;
    tailMsgLen = len;
    while (tailMsgLen) {
	copyLen = UMin(tailMsgLen, UCOMM_PACKET_SIZE - pConn->packToSendLen);
	bcopy(pTailMsg, endPacket, copyLen);
	pConn->packToSendLen += copyLen;
	pTailMsg += copyLen;
	tailMsgLen -= copyLen;
	URetIfNz(UFlush(pConn));
        endPacket = pConn->packToSend;
    }
    pConn->nbSendMsg++;
    return 0;
}

/* Send message (or part of)
 * (ie flush actual packet (if needed)).
 *
 * Return: 0 or error code
 */
static int
UFlush(ConnectionLine * pConn)
{
    int nbWBytes;

    if (pConn->packToSendLen) {
        if ((nbWBytes = write(pConn->socketNum, pConn->packToSend, pConn->packToSendLen)) < 0) {
            URetErrno;
        }
        assert(nbWBytes == pConn->packToSendLen);
        bzero(pConn->packToSend, UCOMM_PACKET_SIZE);    /* ?? for debug only */
        pConn->packToSendLen = 0;
        pConn->nbSendPacket++;
    }
    return 0;
}

/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int
UCheckPendingMsgCommon(ConnectionLine * pConn, int *pNbMsg)
{
    struct timeval timeout;

    UTrace(UTRACE_COMM, printf("UCheckPendingMsgCommon\n"));
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;   
    URetIfNz(UReadWaitingPackets(pConn,&timeout));	/* inc waiting packets */
    *pNbMsg = lNbElts(pConn->lReceivedMsg);
    return 0;
}

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int
UCheckAllLinesCommon(GArray * aConn, int *pIsMsg)
{
    int nbe, i, maxSock = 0, fd;
    ConnectionLine *pConn;
    fd_set readfds;
    struct timeval timeout;

    UTrace(UTRACE_COMM, printf("UCheckAllLinesCommon\n"));
    *pIsMsg = 0;
    FD_ZERO(&readfds);
    nbe = gaSize(aConn);
    for (i = 0; i < nbe; i++) {
	pConn = gaLookNth(aConn, i);
	if (pConn) {
	    if (lNbElts(pConn->lReceivedMsg)) {
		/* there's already something in the queue */
		*pIsMsg = 1;
		return 0;
	    }
	    FD_SET(pConn->socketNum, &readfds);
	    maxSock = Max(maxSock, pConn->socketNum);
	}
    }
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;
    if (URestartSelect(maxSock + 1,
		       (fd_set *) & readfds,
		       (fd_set *) NULL,
		       (fd_set *) NULL,
		       &timeout) < 0) {
	URetErrno;
    }
    for (fd = 0; fd < maxSock; fd++) {
	if (FD_ISSET(fd, &readfds)) {
	    /* there's something on one of theconnected lines */
	    *pIsMsg = 1;
	    break;
	}
    }
    return 0;
}


/* Get next message.
 *
 * Return: 0 or error code.
 *
 * Warning: It's a blocking call.
 */
int
UGetNextMsgCommon(ConnectionLine * pConn,
		  Byte ** ppMsg	/* Pointer on returned message
   		  		      (caller must free ppMsg after use) */ ,
		  int *pLen /* Lenght of returned message */ )
{
    RcvMsg *pm;

    UTrace(UTRACE_COMM, printf("UGetNextMsgCommon\n"));
    if (ppMsg)
	*ppMsg = NULL;
    if (pLen)
	*pLen = 0;
    URetIfNeg(UWaitForMsgCommon(pConn, NULL));	/* inc waiting packets */
    if (lNbElts(pConn->lReceivedMsg)) {
	pm = lGetHead(pConn->lReceivedMsg);
	UTrace(UTRACE_COMM, printf("read(%d) len %d ->%s<-\n", pConn->socketNum, pm->msgLen, UDumpMem(pm->pMsg, pm->msgLen, UDUMP_ASC_OR_DEC)));
	if (ppMsg)
	    *ppMsg = pm->pMsg;
	else
	    UFree(pm->pMsg);
	if (pLen)
	    *pLen = pm->msgLen;
	UFree(pm);
    }
    return 0;
}

/* Peek next message (message is not removed from queue).
 *
 * Return: 0 or error code.
 *
 * Warning:  It's a blocking call.
 */
int
UPeekNextMsgCommon(ConnectionLine * pConn,
		   Byte ** ppMsg/* Pointer on returned message
					 * (caller must NOT free ppMsg after
       	       		   		   		       use) */ ,
		   int *pLen /* Lenght of returned message */ )
{
    RcvMsg *pm;

    UTrace(UTRACE_COMM, printf("UPeekNextMsgCommon\n"));
    if (ppMsg)
	*ppMsg = NULL;
    if (pLen)
	*pLen = 0;
    URetIfNeg(UWaitForMsgCommon(pConn, NULL));	/* inc waiting packets */
    if (lNbElts(pConn->lReceivedMsg)) {
	pm = lLookHead(pConn->lReceivedMsg);
	UTrace(UTRACE_COMM, printf("read(%d) len %d ->%s<-\n", pConn->socketNum, pm->msgLen, UDumpMem(pm->pMsg, pm->msgLen, UDUMP_ASC_OR_DEC)));
	if (ppMsg)
	    *ppMsg = pm->pMsg;
	if (pLen)
	    *pLen = pm->msgLen;
    }
    return 0;
}


/* Wait for new messages
 * return if a message is received (or already queued) or if timeout is expired.
 *
 * Return: number of got messages or error code
 */
int
UWaitForMsgCommon(ConnectionLine * pConn /* line to watch */ ,
		    struct timeval *pTimeout /* max time to watch (or NULL if want a blocking wait */ ) {
    int nbm;

    UTrace(UTRACE_COMM, printf("UWaitForMsgCommon\n"));
    if (nbm = lNbElts(pConn->lReceivedMsg))
	return nbm;		/* already a waiting message in queue */
    URetIfNz(UReadWaitingPackets(pConn, pTimeout));
    if (nbm = lNbElts(pConn->lReceivedMsg))
	return nbm;		/* already a waiting message in queue */
    return 0;
}


/* Given a id (and correct array of pConn) find its fd (socket number here)
 * useful when need to do a select
 * return fd number or -1 if no such id
 */
int
UIdToFdCommon(int id, GArray * aConn)
{
    ConnectionLine *pConn;

    UTrace(UTRACE_COMM, printf("ULineToFdCommon\n"));
    if ((pConn = gaLookNth(aConn, id))) {
	return pConn->socketNum;
    }
    return -1;
}


/* Fill a fd_set (eg: for a select) with sockets fd of all given lines.
 * or all stored lines if aLines is NULL
 *
 * Return: max fd stored in *pFdSet
 */
int
UFillFdCommon(GArray * aConn, int *aLines, fd_set * pFdSet)
{
    int nbe, i, maxSock = 0;
    ConnectionLine *pConn;

    UTrace(UTRACE_COMM, printf("UFillFdCommon\n"));

    if (aLines) {
	UNIW;
    }
    nbe = gaSize(aConn);
    for (i = 0; i < nbe; i++) {
	pConn = gaLookNth(aConn, i);
	if (pConn) {
	    FD_SET(pConn->socketNum, pFdSet);
	    maxSock = Max(maxSock, pConn->socketNum);
	}
    }
    return maxSock;
}

/* Close a line in aConn.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 *
 * Warning: any pending message on this line will be lost
 */
int
UCloseLineCommon(int id, GArray * aConn)
{
    ConnectionLine *pConn;

    UTrace(UTRACE_COMM, printf("UCloseLineCommon\n"));
    pConn = gaLookNth(aConn, id);
    close(pConn->socketNum);
    if (pConn) {
	gaDelNth(aConn, id, False);
	lFree(pConn->lReceivedMsg, True);
	UFree(pConn);
    }
    return 0;
}

/* Close all lines in aConn.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 */
int
UCloseAllLinesCommon(GArray * aConn)
{
    int i, nbc;

    UTrace(UTRACE_COMM, printf("UCloseAllLinesCommon\n"));
    nbc = gaSize(aConn);
    for (i = 0; i < nbc; i++) {
	UCloseLineCommon(i, aConn);
    }
    return 0;
}

/* Convert an error code to a string.
 *
 * Warning: Caller is responsible for freeing the returned string
 */
char *
UCommErrCodeToString(int errCode)
{
    char tmp[MAX_CHAR_TMP];
    extern char *sys_errlist[];

    if (errCode > 0) {
	sprintf(tmp, "Error: (%d) %s ", errCode, sys_errlist[errCode]);
    }
    else {
	switch (errCode) {
	case UCOMM_ERR_GETHOSTBYNAME:
	    sprintf(tmp, "Error: (%d) bad hostname ", errCode);
	    break;
	case UCOMM_ERR_CONNECT:
	    sprintf(tmp, "Error: (%d) can't connect ", errCode);
	    break;
	case UCOMM_ERR_DISCONNECTED:
	    sprintf(tmp, "Error: (%d) line disconnected (other line-end probably dead) ", errCode);
	    break;
	default:
	    UIError("UErrCodeToErrString", "Error: ?? unknown errCode (%d)", errCode);
	}
    }
    return UStrDup(tmp);
}

