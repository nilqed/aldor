#ifndef MYSTRUCT_H
#define MYSTRUCT_H


/* these defines are used in reallocation for variable size array  */
/* a number of N meens that a reallocation is done each time N new */
/* elements are added to the array                                 */
/* number of sons in a tree */
#define TREESA_CHKSZ 5
/* number of stack elements */
#define STACK_CHKSZ  20
/* number of successor for a Node in an oriented graph */
#define OGNSUCC_CHKSZ 5


/* these defines are used in reallocation of variable size array              */
/* STARTSZ is the START SiZe ie the number of elements after first allocation */
/* CHKMULT is the MULTiplicator (for SiZe) applied at each reallocation (>1)  */
#define QUEUE_STARTSZ 10
#define QUEUE_MULTSZ 1.5

#define GARRAY_STARTSZ 10
#define GARRAY_MULTSZ 1.5

/* flag used to mark an element as to be sweeped */
#define LIST_FLAG_SWEEP -1



/**************************************************************** Prototypes */


/* Do nothing... usefull when a function pointer is needed */
void nullFunc ( void );

/* ODOT...
 */
int hashStringFast ( char *str, int sz );

/* ODOT...
 */
int hashString ( char *str, int sz );

/* ODOT...
 */
int hashInt ( int *i, int sz );

/* ODOT...
 */
int hashVoid ( void *p, int sz );

/* ODOT...
 */
int hashPtr ( void *p, int sz );

/* ODOT...
 */
int ordString ( char *s1, char *s2 );

/* ODOT...
 */
int ordInt ( int *a, int *b );

/* ODOT...
 */
int ordVoid ( void *a, void *b );

/* ODOT...
 */
int ordPtr ( void *a, void *b );

/* ODOT...
 */
void printString ( char *pe );

/* ODOT...
 */
void printInt ( int *pe );

/* ODOT...
 */
void printVoid ( void *pe );

/* ODOT...
 */
void printPtr ( void *pe );

/* ODOT...
 */
void * keySame ( void *pe );

/* ODOT...
 */
void * keyVoid ( void *pe );

/************************************************************ End Prototypes */

#endif /* STRUCT_H */
