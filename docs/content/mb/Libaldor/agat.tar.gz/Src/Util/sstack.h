#ifndef SSTACK_H
#define SSTACK_H


/* Stack */

typedef struct Stack {
    int number;			/* a kind of id... useful for debug */
    int nbe;			/* NumBer of Elements */
    int sz;			/* Stack Size */
    void **ea;			/* Element Array */
    void (*printFunc) ();	/* to print user element */
}

Stack;



/**************************************************************** Prototypes */


/* ODOT...
 */
Stack * sCreate ( void (*printFunc) () );

/* ODOT...
 */
void sFree ( Stack * ps );

/* ODOT...
 */
void sPrint ( Stack * ps );

/* ODOT...
 */
Bools sIsEmpty ( Stack * ps );

/* ODOT...
 */
void * sPop ( Stack * ps );

/* ODOT...
 */
void sPush ( Stack * ps, void *pe );

/* ODOT...
 */
void * sLook ( Stack * ps );

/************************************************************ End Prototypes */



#endif /* SSTACK_H */
