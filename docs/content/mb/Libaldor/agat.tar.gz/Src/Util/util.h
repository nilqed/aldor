#ifndef UTIL_H
#define UTIL_H


/* if UDEBUG is defined UTrace are activated */
#define UDEBUG

/* if these UDEBG_* are defined corresponding UTRACE are done */
/* even if level is not set */
/*#define UDEBUG_COMM*/


/* use an alloc counter (useful for debug) */
#define UALLOC_COUNTER


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

extern int errno;

#include "mesg.h"
#include "macro.h"
#include "types.h"

#include "struct.h"
#include "slist.h"
#include "shasht.h"
#include "squeue.h"
#include "sstack.h"
#include "sstringl.h"
#include "sassoct.h"
#include "sgrowa.h"
#include "stree.h"
#include "sograph.h"

#include "math2D.h"
#include "math3D.h"
#include "defproto.h"
#include "alloc.h"
#include "compress.h"
#include "error.h"
#include "misc.h"
#include "xmisc.h"
#include "strings.h"
#include "timer.h"
#include "scomm.h"
#include "acomm.h"
#include "agatsend.h"

#endif /* UTIL_H */
