#ifndef SSTRINGL_H
#define SSTRINGL_H

/* List of Strings */

typedef struct LString {
    char *s;
    struct LString *next;
} LString;



/**************************************************************** Prototypes */


/********************************************/
/* a very frequently used list: string list */
LString * lsAdd ( LString * ls, char *s );

Bools lsIn ( LString * ls, char *s );

void lsFree ( LString * ls, unsigned char freeElt );

/************************************************************ End Prototypes */



#endif /* SSTRINGL_H */
