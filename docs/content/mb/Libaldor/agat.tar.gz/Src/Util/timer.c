#include "util.h"
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>

typedef struct Timeout {
    int id;			/* ident of this timeout request */
    int otms;			/* requested time for timeout in ms */
    int rtms;			/* remaining time before timeout in ms ...*/
    /* ... (after preceding timeout has expired) */
    UTimerFunc pf;		/* function to call when timeout expire */
    void *pc;			/* closure (given to pf as parameter) */
}
Timeout;

static List *lTimeout = NULL;
static int UPendingSignal = 0;

int UCurTimeout = 0;

/**************************************************************** Prototypes */

/* Function called when a timeout occurs. Dispatch the timeout to corresponding
 * function
 */
static void UTimeout ( void );
/* Up a flag used to avoid race condition in UAddTimeout or UCallTimeoutedAux
 */
static void UPendTimeout ( void );
/* Print a Timeout structure
 */
static void UPrintTimeout ( Timeout * pt );

/******************************************************************** Bodies */

/* Function called when a timeout occurs. Dispatch the timeout to corresponding
 * function
 */
static void
UTimeout(void)
{
    struct itimerval tickLenght, dummy;
    Timeout *pt;

    /* flag this timeout as expired */
    /* registred handler will be called during next call to UCallTimeouted */
    UCurTimeout++;
    /* arm next timeout */
    if (pt = lLookNth(lTimeout, UCurTimeout)) {
	tickLenght.it_value.tv_sec = pt->rtms / 1000;
	tickLenght.it_value.tv_usec = (pt->rtms * 1000) % 1000000;
	timerclear(&(tickLenght.it_interval));
	setitimer(ITIMER_REAL, &tickLenght, &dummy);
    }
}

/* Up a flag used to avoid race condition in UAddTimeout or UCallTimeoutedAux
 */
static void
UPendTimeout(void)
{
    UPendingSignal = 1;
}

/* Print a Timeout structure
 */
static void
UPrintTimeout(Timeout * pt)
{
    printf("    (id: %d otms:%d rtms:%d pf:%x pc:%x)\n", pt->id, pt->otms, pt->rtms, pt->pf, pt->pc);
}

/* Call all timeouted requests (preferably use macro UCallTimeouted)
 */
void
UCallTimeoutedAux(void)
{
    Timeout *pt;

    signal(SIGALRM, (void (*)(int)) UPendTimeout);
    while (UCurTimeout) {
	UCurTimeout--;
	/* beware this must be done before calling handler */
	/* (it may call UAddTimeout) */
	pt = lGetHead(lTimeout);
	pt->pf(pt->pc);
	UFree(pt);
    }
    /* check for pending signal */
    while (UPendingSignal) {
	UPendingSignal = 0;
	UTimeout();
    }
    signal(SIGALRM, (void (*)(int)) UTimeout);
}



/* Add a timeout. Return: time before next timeout.
 */
int
UAddTimeout(int tms /* time in ms before timeout */ ,
	    UTimerFunc pf /* function to call when timeout expire */ ,
	    void *closure /* closure (given as param to pf) */ )
{
    static id = 0;
    struct itimerval tickLenght, dummy;
    Timeout *pt, *pnt, *pbt, *pct;
    int rtms, nbt, n, ret;

    if (!lTimeout) {
	lTimeout = lCreate(keySame, ordInt, nullFunc, UPrintTimeout);
    }
    pt = UNew(Timeout);
    pt->id = id++;
    pt->otms = tms;
    pt->pf = pf;
    pt->pc = closure;

    signal(SIGALRM, (void (*)(int)) UPendTimeout);	/* protect */
    if (UCurTimeout == lNbElts(lTimeout)) {
	/* there's only timeouted requests (or no request) so arm sequence */
	lAddLast(lTimeout, pt);
	pt->rtms = UMax(1, tms);
	tickLenght.it_value.tv_sec = tms / 1000;
	tickLenght.it_value.tv_usec = (tms * 1000) % 1000000;
	timerclear(&(tickLenght.it_interval));
	setitimer(ITIMER_REAL, &tickLenght, &dummy);
	ret = tms;
    }
    else {
	pnt = pct = lLookNth(lTimeout, UCurTimeout);
	getitimer(ITIMER_REAL, &tickLenght);
	rtms = tms - (tickLenght.it_value.tv_usec / 1000) +
	    (tickLenght.it_value.tv_sec * 1000);
	ret = tickLenght.it_value.tv_usec;
	if (rtms < 0) {
	    /* current timeout would have expired after this new one */
	    /* so decrease it */
	    pnt->rtms = -rtms;
	    lAdd(lTimeout, pt);
	    pt->rtms = UMax(1, tms);
	    /* rearm for a shorter laps */
	    tickLenght.it_value.tv_sec = tms / 1000;
	    tickLenght.it_value.tv_usec = (tms * 1000) % 1000000;
	    timerclear(&(tickLenght.it_interval));
	    setitimer(ITIMER_REAL, &tickLenght, &dummy);
	    /* forget if delayed timeout has expired during this part of */
	    /* code. it will be rearmed soon */
	    UPendingSignal = 0;
	    ret = tms;
	}
	else {
	    /* search where this timeout must be inserted in list */
	    n = UCurTimeout + 1;
	    while (1) {
		if (pnt = lLookNth(lTimeout, n)) {
		    if ((rtms - pnt->rtms) < 0) {
			lAddNth(lTimeout, pt, n);
			pt->rtms = UMax(1, rtms);
			pnt->rtms -= rtms;
			break;
		    }
		    n++;
		    rtms -= pnt->rtms;
		}
		else {
		    /* end of timeout queue */
		    pt->rtms = UMax(1, rtms);
		    lAddLast(lTimeout, pt);
		    break;
		}
	    }
	}
    }
    signal(SIGALRM, (void (*)(int)) UTimeout);
    return ret;
}
