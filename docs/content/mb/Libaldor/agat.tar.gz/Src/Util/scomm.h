#ifndef SCOMM_H
#define SCOMM_H

/* must rebuil external fd_set? useful for selects...
 * each connect deconect increment it by one
 */
extern int USMustRebuildFDSet;


/**************************************************************** Prototypes */


/* <asm/byteorder.h> contains the htonl type stuff.. */
extern __inline__ unsigned long int __ntohl ( unsigned long int x );

extern __inline__ unsigned short int __ntohs ( unsigned short int x );

/* Init the server.
 *
 * Must be called before any call to other function of this lib.
 *
 * Return: 0 or error code
 *
 * Warning: this function set the signal handler for SIG_PIPE to SIG_IGN
 */
int USInit ( int portNum, char *serverName );

/* Close the line (id).
 *
 * Return: 0 or error code
 */
int USCloseLine ( int id );

/* Wait until at least one new application is requesting for connection.
 *
 * Accept the first one and put it's id in pId.
 *
 * Return: 0 or error code
 *
 * Warning: this is a blocking call
 */
int USWaitForNewLine ( int *pId );

/* Lenght of data to send */
int USSend ( int id, void *msg, int len );

/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int USCheckPendingMsg ( int id, int *pNbMsg );

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int USCheckAllLines ( int *pIsMsg );

/* Lenght of returned message */
int USGetNextMsg ( int id, Byte **ppMsg, int *pLen );

/* Lenght of returned message */
int USPeekNextMsg ( int id, Byte ** ppMsg, int *pLen );

/* max time to watch (or NULL if want a blocking wait */
int USWaitForMsg ( int id, struct timeval *pTimeout );

/* Fill a fd_set (eg: for a select) with sockets fd of all limes connected
 * to the server.
 *
 * Return: max fd stored in *pFdSet
 */
int USFillFdAllLines ( fd_set * pFdSet );

/* line id */
int USIdToFd ( int id );

/************************************************************ End Prototypes */


#endif /* SCOMM_H */
