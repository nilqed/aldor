#ifndef ERROR_H
#define ERROR_H

#define NO_EXIT

extern unsigned long UTraceLevel;

#define UTRACE_ALWAYS 1L
#define UTRACE_RESERVED 1L<<8

#ifdef UDEBUG_COMM
#define UTRACE_COMM UTRACE_ALWAYS
#else
#define UTRACE_COMM 1L<<1
#endif


#ifdef UDEBUG
#define UTraceSetLevel(Level) UTraceLevel|=(Level)
#define UTraceUnsetLevel(Level) UTraceLevel&=~Level;
#define UTraceNothing(Level) UtraceLevel=0;
#define UTraceAll() UTraceLevel=ULONG_MAX;
#define UTrace(Level,Args) if(UTraceLevel&(Level)){Args;}
#else
#define UTraceSetLevel(Level)
#define UTraceUnsetLevel(Level)
#define UTraceNothing(Level)
#define UTraceAll()
#define UTrace(Level,Args)
#endif


/**************************************************************** Prototypes */


/* A wrapper for exit.
 * If NO_EXIT is defined any call to UExit is fatal...
 * segmentation fault (core dumped)!!
 * Useful when debuging.
 */
void UExit ( int status );

/* Example:  UIWarning should be called like:
 * UIWarning(function_name, format, arg1, arg2...);
 * the format string is like this used by printf
 * UIWarning("CheckedMalloc", "can't allocate %d bytes, %d allocated"
 *           ,size, allocatedSize);
 */
void UIWarning ( char *funcName, char *format, ... );

/* Like UIWarning but only if UDEBUG is defined
 */
void UIDebugWarning ( char *funcName, char *format, ... );

/* Example: UIError should be called like:
 * UIError(function_name, format, arg1, arg2...);
 * the format string is like this used by printf
 * UIError("CheckedMalloc", "can't allocate %d bytes, %d allocated"
 *         ,size, allocatedSize);
 */
void UIError ( char *funcName, char *format, ... );

/* Like UIError but only if UDEBUG is defined
 */
void UIDebugError ( char *funcName, char *format, ... );

/* Given a open-file-error-number build the error message string
 */
char * UOpenError ( int err, char *f );

/************************************************************ End Prototypes */

#endif /* ERROR_H */
