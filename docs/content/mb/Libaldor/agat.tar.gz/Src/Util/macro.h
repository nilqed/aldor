#ifndef MACRO_H
#define MACRO_H

/* maximum size of tmp strings used in these modules */
#define MAX_CHAR_TMP 1024

/* maximum lenght of a file name in characters */
#define MAX_FILE_LEN 256


#define KILO 1024
#define MEGA (KILO*KILO)
#define GIGA (KILO*MEGA)
#define TERA (KILO*GIGA)


/* return errno, or make core for debug */
#define URetErrno return errno
/*#define URetErrno MAKECORE*/


/* if including Xlib.h comment this to avoid redefinition for True and False */
/*#define DEFINE_BOOL*/
#ifdef DEFINE_BOOL
#ifndef True
#define True ((Bools) 1)
#endif
#ifndef False
#define False ((Bools) 0)
#endif
#endif
#define BoolsNot(X) (((X)==True)?False:True)

#define Ok 1
#define Err 0


/* for 's' in strings like theres 2 byte's' and 1 word'' */
#define NBTOCS(N) (((N)>1)?'s':' ')
#define NBTOSS(N) (((N)>1)?"s":"")
/* for 'is' or 'are' */
#define NBTOSBE(N) (((N)>1)?" are":"'s")


/* to make a nice core dump */
#define MAKECORE {char*p=NULL; *p=1;}


/* when you build a new function and forget to fill it ;) think to put at least UNI (U Not Implemented) */

#define UNI    (UIError("__FILE__:__LINE__","not implemented"))
#define UNIW   (UIWarning("__FILE__:__LINE__","not implemented"))

/* bcopy, bzero and Co are non portable calls so replace them by mem family */
#ifndef bcopy
#define bcopy(Source, Dest, Count) memcpy(Dest, Source, Count)
#endif /* bcopy */

#ifndef bzero
#define bzero(Dest, Count) memset(Dest, 0, Count)
#endif /* bzero */

#ifndef bcmp
#define bcmp(Source, Dest, Count) memcmp(Source, Dest, Count)
#endif /* bcmp */


#ifndef Min
#define Min(A,B) (((A)>(B))?(B):(A))
#endif
#ifndef Max
#define Max(A,B) (((A)<(B))?(B):(A))
#endif
#ifndef Abs
#define Abs(A)   (((A)>=0)?(A):-(A))
#endif


/* useful personnal macros */

#define UMin(A,B) Min((A),(B))
#define UMax(A,B) Max((A),(B))
#define UAbs(A)   Abs(A)
#define UForceNonZero(A,Subst) (((A)!=0)?(A):(Subst))

/* uh it seems to be a swap. isn't it? ;) */
/* eg: USwap(a,b,int) or Swap(v1,v2,vectorType) */
#define USwap(A,B,Type) {Type tmp; tmp=(A);(A)=(B);(B)=tmp;}

/* more compact notation */
/* eg: pv=UNew(vector*) is equal to pv=(vector*)malloc(sizeof(vector*)) */
#define UNew(Type) ((Type*) UMalloc(sizeof(Type)))

#endif /* MACRO_H */
