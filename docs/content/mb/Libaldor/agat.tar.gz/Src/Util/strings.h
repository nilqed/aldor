#ifndef STRINGS_H
#define STRINGS_H
/**************************************************************** Prototypes */


/* ODOT...
 */
void UGetSuffix ( char *fileName, char *suffix );

/* ODOT...
 */
void UExtractSuffix ( char *fileName, char *suffix );

/* ODOT...
 */
void UAddSuffix ( char *fileName, char *suffix );

/* if success allocated and filled
					 * with the parameter argc and argv
					 * are modified due to the match
					           found */
int UGetStringParam ( int *pargc, char ***pargv, char **string );

/* Print (s) but show all non ascii characters using \ and their ascii values
 */
void UPrintAll ( char *s );

/************************************************************ End Prototypes */


#endif /* STRINGS_H */
