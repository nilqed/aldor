#ifndef AGATSEND_H
#define AGATSEND_H
#define AgtTop(F)  agatSendInt((F),1)
#define AgtSI(F,V) agatSendInt((F),(V))
#define AgtSL(F,V) agatSendLong((F),(V))
#define AgtSF(F,V) agatSendFloat((F),(V))
#define AgtSD(F,V) agatSendDouble((F),(V))


/* if DONT_USE_AGAT is defined call to agatSend are really extruded from the
 * source.
 * BEWARE! this require a new compilation with this symbol undefined
 * if you want to animate your code again.
 * so defining this symbol is only useful if you want to produce the most
 * efficient version of your code (ie: without the cost of an empty function
 * call at each agatSend)
 *
 * read the manual for more explanation, and remember that a code compiled with
 * call to agatSend may run without the 'agat' server
 */

#ifdef DONT_USE_AGAT
#define agatSendShortPtr(F,V)		
#define agatSendShort(F,V)		
#define agatSendIntPtr(F,V)		
#define agatSendInt(F,V)		
#define agatSendLongPtr(F,V)		
#define agatSendLong(F,V)		
#define agatSendFloatPtr(F,V)		
#define agatSendFloat(F,V)		
#define agatSendDoublePtr(F,V)		
#define agatSendDouble(F,V)		

#else /* DONT_USE_AGAT */
/**************************************************************** Prototypes */

void agatSendIntPtr(char *f, int *v);
void agatSendInt(char *f, int v);

void agatSendLongPtr(char *f, long *v);
void agatSendLong(char *f, long v);

void agatSendFloatPtr(char *f, float *v);
void agatSendFloat(char *f, float v);

void agatSendDoublePtr(char *f, double *v);
void agatSendDouble(char *f, double v);

/************************************************************ End Prototypes */
#endif  /* DONT_USE_AGAT */

#endif /* AGATSEND_H */ 
