#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <string.h>
#include <signal.h>

#include "comm.h"
#include "util.h"


static GArray *aAppConn = NULL;	/* array of ConnectionLines */


/**************************************************************** Prototypes */

/* For backward compatibilities and X11R5 */
static void* __gnu_calloc ( size_t __nmemb, size_t __n );
static void* __gnu_malloc ( size_t __n );

/******************************************************************** Bodies */


/* Opens a line of connection from this application to a server.
 *
 * The server is defined by it's address and a port number.
 * An Id is returned which identify this line. So message communications on
 * this line must use this Id.
 *
 * Return: 0 or an error code
 *
 * Warning: this function set the signal handler for SIG_PIPE to SIG_IGN
 */
int
UAOpenLine(char *serverAdress, int portNum, int *pId)
{
    static Bools handlerSet = False;
    struct hostent *adress;
    struct sockaddr_in server;
    int socketNum;
    ConnectionLine *pConn;

    if (!handlerSet) {
	handlerSet = True;
	signal(SIGPIPE, SIG_IGN);
    }
    if ((socketNum = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	return errno;

    if ((adress = gethostbyname(serverAdress)) == NULL) {	/* get server adress */
	return UCOMM_ERR_GETHOSTBYNAME;
    }

    server.sin_family = AF_INET;/* Using Internet domain */
    server.sin_port = htons(portNum);
    bcopy((char *) adress->h_addr, (char *) &server.sin_addr, adress->h_length);

    if ((connect(socketNum, (struct sockaddr *) &server, sizeof(server))) < 0) {
	close(socketNum);	/* The server is not connected */
	return UCOMM_ERR_CONNECT;
    }

    /* it seem's ok so add this new line in ConnectionLines array aAppConns */
    pConn = UNew(ConnectionLine);
    pConn->socketNum = socketNum;
    pConn->lReceivedMsg = lCreate(keySame, strcmp, UFreeRcvMsg, UPrintRcvMsg);
    bzero(pConn->packToSend, UCOMM_PACKET_SIZE);
    pConn->packToSendLen = 0;
    pConn->nbSendPacket = 0;
    pConn->nbSendMsg = 0;
    pConn->nbReceivedMsg = 0;
    *pId = UAddAConn(pConn, &aAppConn);
    return 0;
}

/* Close a line.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 *
 * Warning: any pending message on this line will be lost
 */
int
UACloseLine(int id)
{
    return UCloseLineCommon(id, aAppConn);
}

/* Close all lines.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 */
int
UACloseAllLines(void)
{
    return UCloseAllLinesCommon(aAppConn);
}

/* Send a message (on at least store it in a buffer).
 *
 * Return: 0 or error code
 */
int
UASend(int id /* On which line to send msg */ ,
       void *msg /* Pointer on data to send */ ,
       int len /* Lenght of data to send */ )
{
    return USendCommon((ConnectionLine *) gaLookNth(aAppConn, id), msg, len);
}


/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int
UACheckPendingMsg(int id, int *pNbMsg)
{
    return UCheckPendingMsgCommon((ConnectionLine *) gaLookNth(aAppConn, id), pNbMsg);
}

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int
UACheckAllLines(int *pIsMsg)
{
    return UCheckAllLinesCommon(aAppConn, pIsMsg);
}

/* Get next message.
 *
 * Return: 0 or error code.
 *
 * Warning: It's a blocking call.
 */
int
UAGetNextMsg(int id,
	     Byte **ppMsg	/* Pointer on returned message
					 * (caller must free ppMsg after
	     	     	         use). */ ,
	     int *pLen /* Lenght of returned message. */ )
{
    return UGetNextMsgCommon((ConnectionLine *) gaLookNth(aAppConn, id), ppMsg, pLen);
}


/* Peek next message (message is not removed from queue).
 *
 * Return: 0 or error code.
 *
 * Warning:  It's a blocking call.
 */
int
UAPeekNextMsg(int id,
	      Byte **ppMsg	/* Pointer on returned message
					 * (caller must NOT free ppMsg after
	      	      	          use). */ ,
	      int *pLen /* Lenght of returned message */ )
{
    return UPeekNextMsgCommon((ConnectionLine *) gaLookNth(aAppConn, id), ppMsg, pLen);
}

/* Wait for new messages
 * return if a message is received (or already queued) or if timeout is expired.
 *
 * Return: number of got messages or error code
 */
int
UAWaitForMsg(int id /* line to watch */ ,
	      struct timeval *pTimeout /* max time to watch (or NULL if want a blocking wait */ ) {
    return UWaitForMsgCommon((ConnectionLine *) gaLookNth(aAppConn, id), pTimeout);
}

/* Given a id return its fd (socket number here)
 * useful when need to do a select
 * return fd number or -1 if no such id
 */
int
UAIdToFd(int id /* line id */ )
{
    return UIdToFdCommon(id, aAppConn);
}

