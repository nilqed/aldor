#ifndef TIMER_H
#define TIMER_H


extern int UCurTimeout;

#define UCallTimeouted() if(UCurTimeout)UCallTimeoutedAux()

typedef void (*UTimerFunc) (void *p);


/**************************************************************** Prototypes */


/* Call all timeouted requests (preferably use macro UCallTimeouted)
 */
void UCallTimeoutedAux ( void );

/* closure (given as param to pf) */
int UAddTimeout ( int tms, UTimerFunc pf, void *closure );

/************************************************************ End Prototypes */



#endif /* TIMER_H */
