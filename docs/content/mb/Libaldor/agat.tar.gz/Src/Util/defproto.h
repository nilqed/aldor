#ifndef DEFPROTO_H
#define DEFPROTO_H

extern double drand48();

#endif /* DEFPROTO_H */
