#ifndef MATH2D_H
#define MATH2D_H



typedef struct v2D {
    double x, y;
}

v2D;

typedef v2D p2D;


/**************************************************************** Prototypes */


/* ODOT...
 */
double norm2D ( v2D * pv );

/* ODOT...
 */
v2D p2v2D ( p2D * pa, p2D * pb );

/* ODOT...
 */
double crossProd2D ( v2D * pu, v2D * pv );

/* ODOT...
 */
v2D normalized2D ( v2D * pv );

/* ODOT...
 */
void normalize2D ( v2D * pv );

/* ODOT...
 */
v2D add2D ( v2D * p1, v2D * p2 );

/* ODOT...
 */
v2D mul2D ( double k, v2D * p1 );

/* ODOT...
 */
v2D interp2D ( double k1, double k2, v2D * p1, v2D * p2 );

/************************************************************ End Prototypes */



#endif /* MATH2D_H */
