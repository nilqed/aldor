#ifndef AGATGEN_H
#define AGATGEN_H

#define DEFAULT_PORT 7654

#define AGAT_ENV "AGAT"
#define PLAYBACKEXE "agatreplay"
#define DUMPSERVER  "agatdump"

#define ER_ENVVARNOTDEF "Can't find environment variable : "
#define ERS_UNKNOWN_VTYP "Unknown value type : "


#define VTYP_INT      ((ValueType)3)
#define VTYP_LONG     ((ValueType)4)
#define VTYP_FLOAT    ((ValueType)9)
#define VTYP_DOUBLE   ((ValueType)10)

/* kind of Strean ID */
typedef int Sid;

/* int is too much but that's better for padding thsn a char */
typedef int ValueType;

typedef struct MsgHeader {
    Sid sid;
    ValueType type;
}         MsgHeader;

#endif
