#ifndef ACOMM_H
#define ACOMM_H

/**************************************************************** Prototypes */


/* <asm/byteorder.h> contains the htonl type stuff.. */
extern __inline__ unsigned long int __ntohl ( unsigned long int x );

extern __inline__ unsigned short int __ntohs ( unsigned short int x );

/* Opens a line of connection from this application to a server.
 *
 * The server is defined by it's address and a port number.
 * An Id is returned which identify this line. So message communications on
 * this line must use this Id.
 *
 * Return: 0 or an error code
 *
 * Warning: this function set the signal handler for SIG_PIPE to SIG_IGN
 */
int UAOpenLine ( char *serverAdress, int portNum, int *pId );

/* Close a line.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 *
 * Warning: any pending message on this line will be lost
 */
int UACloseLine ( int id );

/* Close all lines.
 *
 * Remember to close all lines before end of
 * application or sockets won't be freed until some minutes
 */
int UACloseAllLines ( void );

/* Lenght of data to send */
int UASend ( int id, void *msg, int len );

/* How many messages are waiting for a read.
 * Incorporate waiting mesages and return immediatly (ie no round trip)
 */
int UACheckPendingMsg ( int id, int *pNbMsg );

/* Checks if there is something waiting for a read on all connected lines.
 *
 * Do the check as fast as possible (only one select)
 * nether blocks
 */
int UACheckAllLines ( int *pIsMsg );

/* Lenght of returned message. */
int UAGetNextMsg ( int id, Byte **ppMsg, int *pLen );

/* Lenght of returned message */
int UAPeekNextMsg ( int id, Byte **ppMsg, int *pLen );

/* max time to watch (or NULL if want a blocking wait */
int UAWaitForMsg ( int id, struct timeval *pTimeout );

/* line id */
int UAIdToFd ( int id );

/************************************************************ End Prototypes */

#endif /* ACOMM_H */
