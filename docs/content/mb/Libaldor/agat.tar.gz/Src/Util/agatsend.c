#include <sys/time.h>
#include <sys/resource.h>

#include "util.h"
#include "agatGen.h"
#include "agatsend.h"


#define ER_NOTHINGTODO          "No server to play animation and no dump file to store animation? There's nothing to do!"
#define ER_SERVERNOTFOUND       "Can't find server : "
#define ER_SERVERNOTCONNECTED   "Can't connect to server : "
#define ER_CANTOPENDF           "Can't open dumpfile : "
#define HASHT_SZ 50
#define RM_CHKZ_MSGHEADER 20



/* cells in the hash-lists */
typedef struct SidName {
    Sid sid;
    char *name;
    struct SidName *next;
}       SidName;


/* name and FILE* of the dump file to use */
static char *dumpFileName = (char *) NULL;
static FILE *dumpFile;

/* vars used for communication */
static int portNum;
static int lineToServer;

/* has the initialisation been done? */
static Bools initDone = False;

/* what's to do? Create a dump-file or (and) play an anim */
static Bools dump = False;
static Bools play = False;
static Bools run = False;

/* hash table for stream-name-storage (to retrive Sid from stream-name) */
static SidName *tHashSidName[HASHT_SZ];

/* to find user and system time used between two send */
static long lastTime = 0;


/**************************************************************** Prototypes */

/* */
static void getEnvParams(void);
static void checkError(int errCode, char *errMsg);
static void acceptConnect(void);
static void openDumpFile(char *dumpFileName);
static Sid searchListName(char *name, SidName * list);
static Sid addName(char *name, ValueType type);
static int hashName(char *name);
static long dTime(void);
static void init(void);

/******************************************************************** Bodies */





/* */
static void
getEnvParams(void)
{
    char tmp[MAX_CHAR_TMP];
    char *s;

    sprintf(tmp, "%s%s", AGAT_ENV, "play");
    s = getenv(tmp);
    if ((s != NULL) && (strlen(s) != 0)) {
	play = True;
    }

    sprintf(tmp, "%s%s", AGAT_ENV, "dump");
    dumpFileName = getenv(tmp);
    if ((dumpFileName != NULL) && (strlen(dumpFileName) != 0)) {
	dump = True;
    }

    sprintf(tmp, "%s%s", AGAT_ENV, "running");
    s = getenv(tmp);
    if ((s != NULL) && (strlen(s) != 0)) {
	run = True;
    }

    sprintf(tmp, "%s%s", AGAT_ENV, "port");
    s = getenv(tmp);
    if (s != NULL) {
	portNum = atoi(s);
    }
}

static void
checkError(int errCode, char *errMsg)
{
    if (errCode) {
	UIError("algorithm: ", "%s", errMsg);
	UExit(errCode);
    }
}



static void
acceptConnect(void)
{
    checkError(UAOpenLine("localhost", portNum, &lineToServer),
	       "Connect failed\n");
    initDone = True;
}




static void
openDumpFile(char *dumpFileName)
{
    struct rusage rusage;

    dump = True;
    dumpFile = UCompressedFOpen(dumpFileName, "w");
    if (dumpFile == NULL) {
	UIError("agat server", "%s %s", ER_CANTOPENDF, dumpFileName);
    }
    getrusage(RUSAGE_SELF, &rusage);
    lastTime = rusage.ru_utime.tv_sec * 1000 + rusage.ru_utime.tv_usec * 1e-3 +
	rusage.ru_stime.tv_sec * 1000 + rusage.ru_stime.tv_usec * 1e-3;
}



static Sid
searchListName(char *name, SidName * list)
{
    while (list != (SidName *) NULL) {
	if (strcmp(list->name, name) == 0)
	    return list->sid;
	else
	    list = list->next;
    }
    return 0;
}

static Sid
addName(char *name, ValueType type)
{
    static nbStream = 0;
    int hind, msgLen;			/* hash index */
    SidName *nc;			/* new cell */
    struct msg {
	Sid sid;
	ValueType type;
	char name[1];			/* in fact this is the head of he
					 * real string */
    }  *pMsg;

    /* create and fill a new cell in the Hash list */
    hind = hashName(name);
    nc = (SidName *) UMalloc(sizeof(SidName));
    nc->next = tHashSidName[hind];
    nc->name = UStrDup(name);

    nbStream++;				/* to avoid using sid ==0 */
    nc->sid = nbStream;
    tHashSidName[hind] = nc;

    /* send this name to server with its sid */
    msgLen = sizeof(struct msg) + strlen(name);
    pMsg = UMalloc(msgLen);
    pMsg->sid = 0;			/* warn server for a new stream */
    pMsg->type = type;
    strcpy(pMsg->name, name);
    checkError(UASend(lineToServer, pMsg, msgLen),
	       "record of a new stream failed\n");
    return nbStream;
}

static int
hashName(char *name)
{
    char *p;
    int s = 0;

    for (p = name; *p; p++) {
	s += *p;
    }
    return s % HASHT_SZ;
}

static Sid
nameToSid(char *name, ValueType type)
{
    static char *lastName = (char *) NULL;
    static int lastSid = 0;

    if ((lastName != (char *) NULL) && (strcmp(lastName, name) == 0)) {
	return lastSid;
    }
    else {
	if (lastName != (char *) NULL)
	    free(lastName);
	lastName = UStrDup(name);
	lastSid = searchListName(name, tHashSidName[hashName(name)]);
	if (lastSid == 0)
	    lastSid = addName(name, type);
	return lastSid;
    }
}



static long
dTime(void)
{
    long dif;
    long newTime;
    struct rusage newRusage;

    getrusage(RUSAGE_SELF, &newRusage);
    newTime = newRusage.ru_utime.tv_sec * 1000 + newRusage.ru_utime.tv_usec * 1e-3 +
	newRusage.ru_stime.tv_sec * 1000 + newRusage.ru_stime.tv_usec * 1e-3;
    dif = newTime - lastTime;
    lastTime = newTime;
    if (dif == 0)
	return 1;
    return dif;
}


static void
init(void)
{
    getEnvParams();
    if (run != True)
	return;
    if (play == True)
	acceptConnect();
    if (dump == True)
	openDumpFile(dumpFileName);
    initDone = True;
}



/******************************************************** exported functions */



/* */
void
agatSendIntPtr(char *f, int *v)
{
  agatSendInt(f,*v);
}


/* */
void
agatSendInt(char *f, int v)
{
    struct {
	Sid sid;
	ValueType type;
	int v;
    }
           msg;

    if (initDone == False)
	init();
    if (run != True)
	return;
    if (dump == True) {
	fprintf(dumpFile, "%s %d %d %d\n", f, VTYP_INT, v, dTime());
    }
    if (play == True) {
	msg.sid = nameToSid(f, VTYP_INT);
	msg.type = VTYP_INT;
	msg.v = v;
	checkError(UASend(lineToServer, &msg, sizeof(msg)),
		   "send failed\n");
    }
}



/* */
void
agatSendLongPtr(char *f, long *v)
{
  agatSendLong(f, *v);
}


/* */
void
agatSendLong(char *f, long v)
{
    struct {
	Sid sid;
	ValueType type;
	long v;
    }
           msg;

    if (initDone == False)
	init();
    if (run != True)
	return;
    if (dump == True) {
	fprintf(dumpFile, "%s %d %d %d\n", f, VTYP_LONG, v, dTime());
    }
    if (play == True) {
	msg.sid = nameToSid(f, VTYP_LONG);
	msg.type = VTYP_LONG;
	msg.v = v;
	checkError(UASend(lineToServer, &msg, sizeof(msg)),
		   "send failed\n");
    }
}



/* */
void
agatSendFloatPtr(char *f, float *v)
{
  agatSendFloat(f,*v);
}


/* */
void
agatSendFloat(char *f, float v)
{
    struct msg {
	Sid sid;
	ValueType type;
	float v;
    }   msg;

    if (initDone == False)
	init();
    if (run != True)
	return;
    if (dump == True) {
	fprintf(dumpFile, "%s %d %d %d\n", f, VTYP_FLOAT, v, dTime());
    }
    if (play == True) {
	msg.sid = nameToSid(f, VTYP_FLOAT);
	msg.type = VTYP_FLOAT;
	msg.v = v;
	checkError(UASend(lineToServer, &msg, sizeof(msg)),
		   "send failed\n");
    }
}


/* */
void
agatSendDoublePtr(char *f, double *v)
{
  agatSendDouble(f, *v);
}


/* */
void
agatSendDouble(char *f, double v)
{
    struct {
	Sid sid;
	ValueType type;
	double v;
    }
           msg;

    if (initDone == False)
	init();
    if (run != True)
	return;
    if (dump == True) {
	fprintf(dumpFile, "%s %d %d %d\n", f, VTYP_DOUBLE, v, dTime());
    }
    if (play == True) {
	msg.sid = nameToSid(f, VTYP_DOUBLE);
	msg.type = VTYP_DOUBLE;
	msg.v = v;
	checkError(UASend(lineToServer, &msg, sizeof(msg)),
		   "send failed\n");
    }
}



