#ifndef TYPES_H
#define TYPES_H

typedef unsigned char Bools;
typedef unsigned char Byte;
typedef void (*GenericFunc) ();

#endif /* TYPES_H */
