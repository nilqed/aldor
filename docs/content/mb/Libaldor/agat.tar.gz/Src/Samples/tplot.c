#include <stdio.h>
#include <math.h>
#include "libAGAT.h"



int
main(argc, argv)
    int argc;
    char **argv;
{
    int i, j;
    int nbn;

    if (argc != 2)
	nbn = 1000;
    else
	nbn = atoi(argv[1]);
    agatSendInt("nb", nbn);
    for (i = 1; i <= nbn; i++) {
	if (i % 100 == 0) {
	    agatSendInt("reinit", 1);
	}
	else
	    agatSendInt("reinit", 0);
	agatSendInt("i", i);
    }

}
