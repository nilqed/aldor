#include <stdio.h>
#include <math.h>
#include "libAGAT.h"



double drand48(void);



int 
main(argc, argv)
    int argc;
    char **argv;
{
    int i, j;
    int nbn, aleat;

    if (argc < 3) {
	nbn = 1000;
	aleat = 1;
    }
    else {
	nbn = atoi(argv[1]);
	aleat = atoi(argv[2]);
    }
    switch (aleat) {
    case 1:{
	    for (i = 1; i <= nbn; i++) {
		agatSendDouble("i", (double) (drand48()));
	    }
	    break;
	}
    case 2:{
	    for (i = 1; i <= nbn; i++) {
		agatSendInt("i", rand());
	    }
	    break;
	}
    case 3:{
	    for (i = 1; i <= nbn; i++) {
		agatSendInt("i", random());
	    }
	    break;
	}
    case 4:{
	    for (i = 1; i <= nbn; i++) {
		agatSendInt("i", abs(i * 3718237 % 100));
	    }
	    break;
	}
    case 5:{
	    int n = 12687123;

	    for (i = 1; i <= nbn; i++) {
		agatSendInt("i", n = abs(n * 3718237 % 101));
	    }
	    break;
	}
    case 6:{
	    int n;

	    n = atoi(argv[3]);
	    for (i = 1; i <= nbn; i++) {
		n = n * n + 10000;
		n = abs(n / 1000 - ((n / 1000000) * 1000000));
		agatSendDouble("i", (double) n / 100000);
	    }
	    break;
	}
    case 7:{
	    int m, tmp;
	    int x = 5000, y = 4000;

	    /* int x=12978,y=28391; */
	    m = atoi(argv[3]);
	    for (i = 1; i <= nbn; i++) {
		tmp = x;
		x = (x + y) % m;
		y = tmp;
		agatSendInt("i", x);
	    }
	    break;
	}
    }
}
