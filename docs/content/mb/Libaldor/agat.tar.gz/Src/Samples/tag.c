#include <stdio.h>
#include <math.h>
#include "libAGAT.h"



double drand48(void);

int 
main(argc, argv)
    int argc;
    char **argv;
{
    int i, j;
    int nbn;

    nbn = atoi(argv[1]);
    for (i = 1; i <= nbn; i++) {
	agatSendDouble("i", (double) (drand48()));
    }

}
